// FluentX — ai-practice-chat Edge Function
//
// Two actions, one function:
//  - { action: 'reply', session_id, user_message }  → conversational turn
//  - { action: 'summarize', session_id }              → end-of-session scoring
//
// Deploy: supabase functions deploy ai-practice-chat
// Set secret: supabase secrets set OPENAI_API_KEY=sk-...

import { createClient } from 'jsr:@supabase/supabase-js@2';

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

type TranscriptTurn = { role: 'user' | 'assistant'; text: string };

async function callOpenAi(messages: Array<{ role: string; content: string }>) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages,
      response_format: { type: 'json_object' },
      temperature: 0.4,
    }),
  });
  if (!res.ok) {
    console.error('OpenAI error:', await res.text());
    throw new Error('AI request failed');
  }
  const completion = await res.json();
  return JSON.parse(completion.choices[0].message.content);
}

Deno.serve(async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });

  if (!OPENAI_API_KEY || !SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return json({ error: 'Server misconfigured: missing required secrets.' }, 500);
  }

  const body = await req.json();
  const { action, session_id: sessionId } = body;

  const authHeader = req.headers.get('Authorization');
  if (!authHeader?.startsWith('Bearer ')) return json({ error: 'Unauthorized' }, 401);

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const token = authHeader.slice('Bearer '.length);
  const { data: authData, error: authError } = await supabase.auth.getUser(token);
  const user = authData.user;
  if (authError || !user) return json({ error: 'Unauthorized' }, 401);

  const { data: session, error: sessionError } = await supabase
    .from('ai_practice_sessions')
    .select('id, transcript, ai_practice_scenarios(system_prompt)')
    .eq('id', sessionId)
    .eq('user_id', user.id)
    .single();

  if (sessionError || !session) {
    return json({ error: 'Session not found' }, 404);
  }

  const scenario = session.ai_practice_scenarios as { system_prompt: string };
  const transcript: TranscriptTurn[] = session.transcript ?? [];

  if (action === 'reply') {
    const userMessage: string = body.user_message;
    if (!userMessage) return json({ error: 'user_message is required' }, 400);

    const systemPrompt = `${scenario.system_prompt}

Additionally, check the user's last message for any clear grammar or word-choice
error. Respond with ONLY valid JSON, no markdown:
{"reply": string, "correction": string | null}
"correction" should be a short, encouraging one-line fix (e.g. "Try: 'I have been working here for two years' instead of 'I am working here since two years'") or null if there's nothing worth flagging.`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...transcript.map((t) => ({
        role: t.role === 'user' ? 'user' : 'assistant',
        content: t.text,
      })),
      { role: 'user', content: userMessage },
    ];

    const parsed = await callOpenAi(messages);

    const updatedTranscript: TranscriptTurn[] = [
      ...transcript,
      { role: 'user', text: userMessage },
      { role: 'assistant', text: parsed.reply },
    ];

    await supabase
      .from('ai_practice_sessions')
      .update({ transcript: updatedTranscript })
      .eq('id', sessionId)
      .eq('user_id', user.id);

    return json({ reply: parsed.reply, correction: parsed.correction ?? null }, 200);
  }

  if (action === 'summarize') {
    const userTurns = transcript.filter((t) => t.role === 'user').map((t) => t.text);

    const systemPrompt = `You are scoring an English speaking practice session for an
Indian professional. Based on the user's turns below, respond with ONLY valid JSON:
{"accuracy_score": number (0-100), "fluency_notes": string (2-3 encouraging, specific sentences),
"corrected_sentences": [{"original": string, "corrected": string}]}
Include at most 3 corrected_sentences, only for turns with a real error. If there are
no user turns, use accuracy_score 0 and note that no speech was recorded.`;

    const parsed = await callOpenAi([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: JSON.stringify(userTurns) },
    ]);

    const { data: updated, error: updateError } = await supabase
      .from('ai_practice_sessions')
      .update({
        accuracy_score: parsed.accuracy_score,
        fluency_notes: parsed.fluency_notes,
        corrected_sentences: parsed.corrected_sentences ?? [],
        ended_at: new Date().toISOString(),
      })
      .eq('id', sessionId)
      .eq('user_id', user.id)
      .select('accuracy_score, fluency_notes, corrected_sentences')
      .single();

    if (updateError || !updated) return json({ error: 'Failed to save summary' }, 500);

    return json(updated, 200);
  }

  return json({ error: `Unknown action: ${action}` }, 400);
});

function json(data: unknown, status: number) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

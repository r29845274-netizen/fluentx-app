// FluentX — score-writing Edge Function
//
// Runs server-side with the service role key (never exposed to the
// client) and the OPENAI_API_KEY secret. Called by the client via
// `supabase.functions.invoke('score-writing', { body: { submission_id } })`
// AFTER the client has already inserted a row into `writing_submissions`
// (see WritingRemoteDataSourceImpl.submitDraft).
//
// Deploy: supabase functions deploy score-writing
// Set secret: supabase secrets set OPENAI_API_KEY=sk-...

import { createClient } from 'jsr:@supabase/supabase-js@2';

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

interface ScorePayload {
  grammar_score: number;
  clarity_score: number;
  structure_score: number;
  tone_score: number;
  feedback: string;
}

Deno.serve(async (req: Request) => {
  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  if (!OPENAI_API_KEY || !SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return new Response(
      JSON.stringify({ error: 'Server misconfigured: missing required secrets.' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } },
    );
  }

  const { submission_id: submissionId } = await req.json();
  if (!submissionId) {
    return new Response(JSON.stringify({ error: 'submission_id is required' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // Service-role client performs the trusted score write, but the
  // caller is still authenticated and ownership is enforced explicitly.
  const authHeader = req.headers.get('Authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { 'Content-Type': 'application/json' },
    });
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const token = authHeader.slice('Bearer '.length);
  const { data: authData, error: authError } = await supabase.auth.getUser(token);
  const user = authData.user;
  if (authError || !user) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { 'Content-Type': 'application/json' },
    });
  }

  const { data: submission, error: fetchError } = await supabase
    .from('writing_submissions')
    .select('id, content, prompt_id, writing_prompts(title, category, instructions)')
    .eq('id', submissionId)
    .eq('user_id', user.id)
    .single();

  if (fetchError || !submission) {
    return new Response(JSON.stringify({ error: 'Submission not found' }), {
      status: 404,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const prompt = submission.writing_prompts as {
    title: string;
    category: string;
    instructions: string;
  };

  const systemPrompt = `You are a writing coach for FluentX, an app that helps
Indian professionals and students improve their business English.
Score the user's ${prompt.category} submission for the prompt "${prompt.title}"
on four dimensions, each 0-100: grammar, clarity, structure, tone.
Also give 2-3 sentences of specific, encouraging, actionable feedback.
Respond with ONLY valid JSON matching this shape, no markdown, no prose outside it:
{"grammar_score": number, "clarity_score": number, "structure_score": number, "tone_score": number, "feedback": string}`;

  const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: submission.content },
      ],
      response_format: { type: 'json_object' },
      temperature: 0.3,
    }),
  });

  if (!openaiResponse.ok) {
    const errText = await openaiResponse.text();
    console.error('OpenAI error:', errText);
    return new Response(JSON.stringify({ error: 'AI scoring failed. Please try again.' }), {
      status: 502,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const completion = await openaiResponse.json();
  const parsed: ScorePayload = JSON.parse(completion.choices[0].message.content);

  const { data: updated, error: updateError } = await supabase
    .from('writing_submissions')
    .update({
      grammar_score: parsed.grammar_score,
      clarity_score: parsed.clarity_score,
      structure_score: parsed.structure_score,
      tone_score: parsed.tone_score,
      ai_feedback: parsed.feedback,
      scored_at: new Date().toISOString(),
    })
    .eq('id', submissionId)
    .eq('user_id', user.id)
    .select()
    .single();

  if (updateError || !updated) {
    return new Response(JSON.stringify({ error: 'Failed to save scores' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  return new Response(JSON.stringify(updated), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  });
});

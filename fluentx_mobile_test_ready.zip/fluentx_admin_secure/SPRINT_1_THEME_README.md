# FluentX — Sprint 1, Part 1: Theme System

## Files delivered

```
lib/core/constants/app_spacing.dart
lib/core/constants/app_radius.dart
lib/core/constants/app_durations.dart
lib/core/theme/app_colors.dart
lib/core/theme/app_typography.dart
lib/core/theme/app_theme.dart
lib/core/theme/theme_mode_provider.dart
pubspec.yaml
```

## Setup steps

1. Copy the `lib/core/` folder into your Flutter project's `lib/` directory.
2. Merge `pubspec.yaml` dependencies into your project (or use this file
   as your starting `pubspec.yaml` if this is a fresh project).
3. Run:
   ```bash
   flutter pub get
   ```
4. Initialize Hive **before** `runApp` in `main.dart`:

   ```dart
   import 'package:flutter/material.dart';
   import 'package:flutter_riverpod/flutter_riverpod.dart';
   import 'package:hive_flutter/hive_flutter.dart';
   import 'core/theme/theme_mode_provider.dart';

   Future<void> main() async {
     WidgetsFlutterBinding.ensureInitialized();
     await Hive.initFlutter();
     await Hive.openBox(kSettingsBoxName);

     runApp(const ProviderScope(child: FluentXApp()));
   }
   ```

5. Wire the theme into `MaterialApp.router` (GoRouter comes in the next
   part of Sprint 1, so for now a plain `MaterialApp` reference is shown):

   ```dart
   class FluentXApp extends ConsumerWidget {
     const FluentXApp({super.key});

     @override
     Widget build(BuildContext context, WidgetRef ref) {
       final themeMode = ref.watch(themeModeProvider);

       return MaterialApp(
         title: 'FluentX',
         debugShowCheckedModeBanner: false,
         theme: AppTheme.light,
         darkTheme: AppTheme.dark,
         themeMode: themeMode,
         home: const Placeholder(), // replaced by GoRouter in next part
       );
     }
   }
   ```

## What's intentionally NOT here yet

- Component library (buttons, text fields, cards, etc.) — next part of
  Sprint 1, waiting on your confirmation.
- GoRouter navigation shell — same.
- `riverpod_generator` codegen (`.g.dart` files) is not used for
  `ThemeModeNotifier` — it's written as a plain `Notifier` subclass
  since it needs no code generation to stay production-clean. Codegen
  will be used for feature-level providers with async data (Sprint 2+)
  where it meaningfully reduces boilerplate.

## Design rules this file set enforces

- No raw hex colors, spacing numbers, or radius values are ever
  written directly in a widget — everything routes through
  `AppColors` → `Theme.of(context).colorScheme` / `context.colors`,
  `AppSpacing`, and `AppRadius`.
- Dark mode is a first-class citizen, not an afterthought — every
  component theme (buttons, inputs, cards, sheets, nav bar) has an
  explicit dark variant tuned for contrast rather than a naive color
  inversion.
- `AppSemanticColors` (a `ThemeExtension`) carries `success`/`warning`
  colors that Material's `ColorScheme` doesn't have built-in roles for.

---

**Next step:** confirm this part, then I'll generate Sprint 1 Part 2 —
the shared Component Library (`PrimaryButton`, `AppTextField`,
`SearchBar`, `ProgressRing`, `AppCard`, `BottomNavBar`, `AppDialog`,
`AppBottomSheet`, `LoadingWidget`, `ErrorStateWidget`, `EmptyStateWidget`).

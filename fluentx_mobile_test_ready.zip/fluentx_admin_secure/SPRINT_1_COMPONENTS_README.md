# FluentX — Sprint 1, Part 2: Component Library

## Files delivered

```
lib/shared/widgets/
  buttons/primary_button.dart
  buttons/secondary_button.dart
  inputs/app_text_field.dart
  inputs/app_search_bar.dart
  indicators/progress_ring.dart
  cards/app_card.dart
  navigation/app_bottom_nav_bar.dart
  overlays/app_dialog.dart
  overlays/app_bottom_sheet.dart
  states/loading_widget.dart       (LoadingWidget, ShimmerBox, LoadingCardSkeleton)
  states/error_state_widget.dart
  states/empty_state_widget.dart
  widgets.dart                      (barrel export)
```

Merge this into the `fluentx_sprint1_theme.zip` project from Part 1 —
these widgets depend on `core/constants/` and `core/theme/`.

## Quick usage reference

```dart
import 'package:fluentx/shared/widgets/widgets.dart';

// Primary action
PrimaryButton(
  label: 'Start Practice',
  icon: LucideIcons.mic,
  isLoading: state.isSubmitting,
  onPressed: () => controller.startSession(),
),

// Text input
AppTextField(
  label: 'Email',
  hint: 'you@example.com',
  keyboardType: TextInputType.emailAddress,
  validator: Validators.email,
),

// Confirmation
final confirmed = await AppDialog.confirm(
  context,
  title: 'End session?',
  message: 'Your progress in this session will be saved.',
);

// Bottom sheet
await AppBottomSheet.show(
  context,
  title: 'Filter by level',
  child: const FilterOptionsList(),
);

// List loading state
if (state.isLoading) return const LoadingCardSkeleton();
if (state.hasError) return ErrorStateWidget(onRetry: controller.reload);
if (state.items.isEmpty) {
  return EmptyStateWidget(
    title: 'No words reviewed yet',
    message: 'Start your first vocabulary session to see it here.',
    actionLabel: 'Start reviewing',
    onAction: () => context.push('/vocabulary'),
  );
}
```

## Design notes

- `PrimaryButton` / `SecondaryButton` self-manage their loading/disabled
  visuals — never wrap them in an extra `if (isLoading)` branch at the
  call site.
- `ShimmerBox` / `LoadingCardSkeleton` are dependency-free (no `shimmer`
  pub package) — built on `ShaderMask` + `AnimationController`, kept
  lightweight on purpose.
- `AppCard` includes a subtle press-scale (0.98) animation on tap for
  tactile feedback — matches the "smooth 200–250ms" motion spec.
- `ErrorStateWidget` and `EmptyStateWidget` intentionally do NOT ship
  default generic copy like "Oops!" — every call site should pass a
  specific, human message relevant to that screen.

---

**Next step:** confirm this part, then I'll generate **Sprint 1, Part 3
— Navigation (GoRouter shell + route definitions)**, followed by
**Part 4 — Authentication** to close out Sprint 1.

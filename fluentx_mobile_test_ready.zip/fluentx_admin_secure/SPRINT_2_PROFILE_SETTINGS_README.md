# FluentX — Sprint 2, Part 2: Profile + Settings (Sprint 2 complete)

## Files delivered

```
lib/features/profile/
  domain/level_progress.dart                  (pure XP→level calculator)
  presentation/screens/profile_screen.dart      (replaces stub)
  presentation/widgets/profile_header.dart
  presentation/widgets/profile_menu_tile.dart

lib/features/settings/
  presentation/screens/settings_screen.dart      (replaces stub)
```

## Key decisions (fast-tracked, flagged honestly)

- **Profile has no new repository/table.** It reuses `authStateChangesProvider`
  (name/email/avatar) + `homeSummaryProvider` (XP) — level is a pure
  function of XP (`LevelProgress.fromTotalXp`), so a third data source
  would just be duplicated state, not "more real."
- **Premium status is hardcoded `false`** — wires to RevenueCat in
  Sprint 6. Not faked as a working subscription check.
- **Theme selector in Settings is fully real** — reuses the
  `themeModeProvider` built in Sprint 1 Part 1, Hive-persisted.
- **Sign out is fully real** — calls `AuthController.signOut()`;
  router redirect handles navigation back to `/login` automatically.
- **Not-yet-buildable items are honest, not faked:** Achievements, My
  Plan detail, Daily Goals, Help & Support, Notifications toggle,
  Delete Account, Privacy/Terms pages all show a "coming soon"
  snackbar naming the real reason (e.g. "Account deletion" needs a
  Supabase Edge Function since the client can't delete an `auth.users`
  row directly) — instead of silently doing nothing or pretending to
  work.

## Testing

Run `dart run build_runner build --delete-conflicting-outputs` if you
haven't already (no new Freezed classes this part, but harmless to
re-run). Then: Profile shows your name/email/level/0 XP → tap Settings
→ toggle Light/Dark/Auto (should apply instantly, persist across
restart) → tap Log Out → confirms → redirects to Login.

---

## 🎉 Sprint 2 complete (Home + Profile + Settings)

Next up per the roadmap: **Sprint 3 — Vocabulary, Grammar**. Say the
word when ready.

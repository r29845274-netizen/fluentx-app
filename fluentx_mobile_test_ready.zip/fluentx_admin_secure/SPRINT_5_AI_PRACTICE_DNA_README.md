# FluentX — Sprint 5: AI Practice + Communication DNA™ (complete)

## Files delivered

```
supabase/migrations/0006_ai_practice.sql
supabase/migrations/0007_communication_dna.sql   (weighted aggregation RPC)
supabase/functions/ai-practice-chat/index.ts        (NEW — real Edge Function)

lib/features/ai_practice/          (domain/data/application/presentation, full Clean Architecture)
lib/features/communication_dna/    (domain/data/application/presentation, full Clean Architecture)
lib/shared/widgets/charts/communication_dna_radar_chart.dart   (custom-painted, no chart library dependency)

lib/features/progress/presentation/screens/progress_screen.dart  (now real — links to DNA)

pubspec.yaml  (added speech_to_text: ^7.0.0)
```

## ⚠️ Required steps

1. Run `0006_ai_practice.sql` then `0007_communication_dna.sql` in Supabase SQL Editor.
2. `flutter pub get` (new dependency: `speech_to_text`).
3. `dart run build_runner build --delete-conflicting-outputs`
   (new Freezed files: `PracticeScenario`/`PracticeMessage`/etc.,
   `CommunicationDna`).
4. **Deploy the Edge Function:**
   ```bash
   supabase functions deploy ai-practice-chat
   # OPENAI_API_KEY secret already set in Sprint 4 covers this too
   ```
5. **Platform permissions** (required for `speech_to_text`):
   - Android `AndroidManifest.xml`: `<uses-permission android:name="android.permission.RECORD_AUDIO" />`
   - iOS `Info.plist`: `NSMicrophoneUsageDescription` and
     `NSSpeechRecognitionUsageDescription` keys with a user-facing reason string.

## Key engineering decisions — flagged honestly

- **Speech-to-text is on-device** (`speech_to_text` package — wraps
  Android's `SpeechRecognizer` / iOS's `Speech` framework), not Google
  Cloud STT. No server key needed, works offline-capable, zero
  per-request cost. This is the same pragmatic pattern as Listening's
  TTS in Sprint 4 — swappable for a cloud STT provider later without
  changing the UI layer (only `PracticeMicButton`'s internals would
  change).
- **AI conversation + scoring is REAL**, via `ai-practice-chat` — one
  Edge Function, two actions (`reply` during the conversation,
  `summarize` at session end), both calling OpenAI server-side. The
  scenario's `system_prompt` is never selected by the Flutter client —
  only this function reads it, keeping prompt engineering server-side.
- **Communication DNA is a real weighted aggregate**, computed in a
  single Postgres function (`get_communication_dna`) rather than
  duplicated client-side math — one source of truth if a second screen
  needs it later. The v1 formula is honestly a set of **heuristics**
  (documented in the migration's comment block) since true phoneme-level
  pronunciation scoring (Azure) isn't wired up yet — Grammar comes from
  mistake volume, Pronunciation approximates from listening-quiz +
  AI-session scores, Confidence from practice frequency. Upgradeable
  per-component without changing the client, since the client only
  consumes the function's output shape.
- **Radar chart is custom-painted** (`CustomPainter`, zero chart-library
  dependency) — matches the "flagship differentiator, not a generic
  progress bar" instruction from the original spec.
- **No new routes for AI Practice's 3 states** (scenario list /
  conversation / summary) — handled as local widget state within
  `AiPracticeHubScreen`, same "don't touch the router unless truly
  needed" discipline as Grammar/Listening/Writing.

## Testing

1. Run both migrations, deploy the Edge Function, set platform mic permissions.
2. Practice tab → pick a scenario → tap mic → speak → AI replies (spoken
   aloud via TTS) with an occasional inline correction bubble.
3. Tap "End Session" → should show accuracy score, fluency notes, and
   any corrected sentences.
4. Progress tab → Communication DNA card should show a real (if modest,
   for a fresh account) score → tap through to the full radar chart screen.

---

Next per roadmap: **Sprint 6 — Payments, Notifications, Testing** (final
sprint). Say the word.

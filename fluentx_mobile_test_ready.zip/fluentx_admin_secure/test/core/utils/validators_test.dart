import 'package:flutter_test/flutter_test.dart';
import 'package:fluentx/core/utils/validators.dart';

void main() {
  group('Validators.email', () {
    test('rejects empty input', () {
      expect(Validators.email(''), isNotNull);
    });

    test('rejects a malformed address', () {
      expect(Validators.email('not-an-email'), isNotNull);
    });

    test('accepts a well-formed address', () {
      expect(Validators.email('rahul@example.com'), isNull);
    });
  });

  group('Validators.password', () {
    test('rejects short passwords', () {
      expect(Validators.password('Ab1'), isNotNull);
    });

    test('rejects passwords with no uppercase letter', () {
      expect(Validators.password('lowercase1'), isNotNull);
    });

    test('rejects passwords with no digit', () {
      expect(Validators.password('NoDigitsHere'), isNotNull);
    });

    test('accepts a compliant password', () {
      expect(Validators.password('Fluent123'), isNull);
    });
  });

  group('Validators.matches', () {
    test('flags mismatched confirmation', () {
      final validator = Validators.matches(() => 'Fluent123');
      expect(validator('Different1'), isNotNull);
    });

    test('passes when values match', () {
      final validator = Validators.matches(() => 'Fluent123');
      expect(validator('Fluent123'), isNull);
    });
  });
}

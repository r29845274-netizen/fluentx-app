import 'package:flutter_test/flutter_test.dart';
import 'package:fluentx/features/profile/domain/level_progress.dart';

void main() {
  group('LevelProgress.fromTotalXp', () {
    test('0 XP is level 1 with 0 progress', () {
      final level = LevelProgress.fromTotalXp(0);
      expect(level.level, 1);
      expect(level.currentLevelXp, 0);
    });

    test('999 XP is still level 1, just short of leveling up', () {
      final level = LevelProgress.fromTotalXp(999);
      expect(level.level, 1);
      expect(level.currentLevelXp, 999);
    });

    test('1000 XP rolls over to level 2', () {
      final level = LevelProgress.fromTotalXp(1000);
      expect(level.level, 2);
      expect(level.currentLevelXp, 0);
    });

    test('8200 XP matches level 9 (reference design example)', () {
      final level = LevelProgress.fromTotalXp(8200);
      expect(level.level, 9);
      expect(level.currentLevelXp, 200);
    });

    test('progress is clamped between 0 and 1', () {
      final level = LevelProgress.fromTotalXp(500);
      expect(level.progress, inInclusiveRange(0.0, 1.0));
    });
  });
}

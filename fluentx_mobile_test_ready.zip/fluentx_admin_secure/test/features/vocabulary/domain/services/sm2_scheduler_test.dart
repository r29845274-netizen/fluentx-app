import 'package:flutter_test/flutter_test.dart';
import 'package:fluentx/features/vocabulary/domain/entities/due_word.dart';
import 'package:fluentx/features/vocabulary/domain/services/sm2_scheduler.dart';

void main() {
  group('Sm2Scheduler', () {
    test('a brand-new word rated "again" resets to a 1-day interval', () {
      final result = Sm2Scheduler.schedule(
        currentRepetition: 0,
        currentEaseFactor: 2.5,
        quality: ReviewQuality.again,
        reviewedAt: DateTime(2026, 1, 1),
      );

      expect(result.repetition, 0);
      expect(result.intervalDays, 1);
      expect(result.dueDate, DateTime(2026, 1, 2));
    });

    test('first successful review schedules a 1-day interval', () {
      final result = Sm2Scheduler.schedule(
        currentRepetition: 0,
        currentEaseFactor: 2.5,
        quality: ReviewQuality.good,
        reviewedAt: DateTime(2026, 1, 1),
      );

      expect(result.repetition, 1);
      expect(result.intervalDays, 1);
    });

    test('second successful review schedules a 6-day interval', () {
      final result = Sm2Scheduler.schedule(
        currentRepetition: 1,
        currentEaseFactor: 2.5,
        quality: ReviewQuality.good,
        reviewedAt: DateTime(2026, 1, 1),
      );

      expect(result.repetition, 2);
      expect(result.intervalDays, 6);
    });

    test('ease factor never drops below the 1.3 floor', () {
      var repetition = 0;
      var easeFactor = 1.3;

      for (var i = 0; i < 5; i++) {
        final result = Sm2Scheduler.schedule(
          currentRepetition: repetition,
          currentEaseFactor: easeFactor,
          quality: ReviewQuality.hard,
          reviewedAt: DateTime(2026, 1, 1),
        );
        repetition = result.repetition;
        easeFactor = result.easeFactor;
      }

      expect(easeFactor, greaterThanOrEqualTo(1.3));
    });

    test('rating "easy" grows the ease factor', () {
      final result = Sm2Scheduler.schedule(
        currentRepetition: 2,
        currentEaseFactor: 2.5,
        quality: ReviewQuality.easy,
        reviewedAt: DateTime(2026, 1, 1),
      );

      expect(result.easeFactor, greaterThan(2.5));
    });
  });
}

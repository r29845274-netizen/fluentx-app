import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fluentx/core/theme/app_theme.dart';
import 'package:fluentx/shared/widgets/buttons/primary_button.dart';

void main() {
  Widget wrap(Widget child) {
    return MaterialApp(theme: AppTheme.light, home: Scaffold(body: Center(child: child)));
  }

  testWidgets('shows label and responds to tap when enabled', (tester) async {
    var tapped = false;

    await tester.pumpWidget(
      wrap(PrimaryButton(label: 'Continue', onPressed: () => tapped = true)),
    );

    expect(find.text('Continue'), findsOneWidget);
    await tester.tap(find.byType(PrimaryButton));
    expect(tapped, isTrue);
  });

  testWidgets('shows a spinner instead of the label when loading', (tester) async {
    await tester.pumpWidget(
      wrap(PrimaryButton(label: 'Continue', isLoading: true, onPressed: () {})),
    );

    expect(find.text('Continue'), findsNothing);
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('does not invoke onPressed when disabled', (tester) async {
    var tapped = false;

    await tester.pumpWidget(
      wrap(PrimaryButton(label: 'Continue', isEnabled: false, onPressed: () => tapped = true)),
    );

    await tester.tap(find.byType(PrimaryButton), warnIfMissed: false);
    expect(tapped, isFalse);
  });
}

# FluentX Mobile Test APK

Codemagic workflow included: `fluentx-mobile-test-apk` / **FluentX — Mobile Test APK**.

This workflow:
1. Runs source preflight.
2. Bootstraps Android platform (`io.fluentx.app`).
3. Installs Flutter dependencies.
4. Generates Freezed/Riverpod code.
5. Runs analyze + tests.
6. Builds a debug APK.
7. Publishes the APK as a Codemagic artifact.

No Android signing or RevenueCat key is required for this debug APK. Supabase test configuration is already present in the app configuration. Firebase Android config is bundled and copied during bootstrap.

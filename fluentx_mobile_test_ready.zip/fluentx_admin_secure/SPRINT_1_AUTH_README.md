# FluentX — Sprint 1, Part 4: Authentication (Sprint 1 complete)

## Files delivered

```
lib/core/error/failures.dart                 (Freezed — needs codegen, see below)
lib/core/error/exceptions.dart
lib/core/config/env_config.dart
lib/core/network/supabase_provider.dart
lib/core/utils/validators.dart
lib/core/router/auth_status.dart              (updated — now REAL, not a stub)
lib/main.dart                                  (updated — Supabase.initialize)

lib/features/authentication/
  domain/entities/app_user.dart                 (Freezed — needs codegen)
  domain/repositories/auth_repository.dart
  domain/usecases/*.dart                          (6 use cases)
  data/models/app_user_model.dart
  data/datasources/auth_remote_datasource.dart
  data/repositories/auth_repository_impl.dart
  application/providers/auth_providers.dart
  application/providers/auth_controller.dart
  presentation/screens/login_screen.dart          (replaces stub)
  presentation/screens/signup_screen.dart          (replaces stub)
  presentation/screens/forgot_password_screen.dart  (replaces stub)
  presentation/widgets/social_sign_in_button.dart
```

## ⚠️ Required step 1: run code generation

`Failure` and `AppUser` are Freezed classes — Freezed generates their
`.freezed.dart` parts (equality, `copyWith`, the `.when`/switch
support) at build time. I can't run this myself (no Dart SDK in this
sandbox), so after copying these files into your project:

```bash
flutter pub get
dart run build_runner build --delete-conflicting-outputs
```

This is a normal, expected step for any Freezed-based Flutter project
— not something unfinished. Re-run it any time you add/edit a
`@freezed` class in later sprints.

## ⚠️ Required step 2: Supabase project setup

1. Create a Supabase project (if you haven't) at supabase.com.
2. **Auth → Providers**: enable **Email**, **Google**, and **Apple**.
   - Google: needs an OAuth Client ID/Secret from Google Cloud Console.
   - Apple: needs a Services ID + private key from Apple Developer.
   (Both are standard Supabase OAuth setup — their dashboard has
   step-by-step guides linked on each provider's config screen.)
3. **Auth → URL Configuration**: add this redirect URL:
   ```
   io.fluentx.app://login-callback
   ```

## ⚠️ Required step 3: platform deep-link config

**Android** — add inside `<activity>` in `android/app/src/main/AndroidManifest.xml`:
```xml
<intent-filter>
  <action android:name="android.intent.action.VIEW" />
  <category android:name="android.intent.category.DEFAULT" />
  <category android:name="android.intent.category.BROWSABLE" />
  <data android:scheme="io.fluentx.app" android:host="login-callback" />
</intent-filter>
```

**iOS** — add to `ios/Runner/Info.plist`:
```xml
<key>CFBundleURLTypes</key>
<array>
  <dict>
    <key>CFBundleURLSchemes</key>
    <array><string>io.fluentx.app</string></array>
  </dict>
</array>
```

## ⚠️ Required step 4: assets

`SocialSignInButton` references two image assets that don't exist yet:
```
assets/icons/google_logo.png
assets/icons/apple_logo.png
```
Add official Google/Apple brand-guideline logo files at these paths
(both companies publish exact usage guidelines/assets — don't
freehand these, brand-mark compliance matters for App Store/Play
Store review).

## Running the app

```bash
flutter run \
  --dart-define=SUPABASE_URL=https://your-project.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=your-anon-key
```

`main.dart` asserts these are present — the app intentionally fails
fast in debug mode rather than silently running against no backend.

## Architecture notes

- **Why OAuth methods return `Unit`, not `AppUser`:** Supabase's mobile
  OAuth flow is redirect-based — `signInWithOAuth` launches a browser
  and returns once that's *launched*, not once the user is signed in.
  The actual session arrives later via `onAuthStateChange` (a deep
  link brings the user back into the app). `AuthController` reflects
  this correctly: after calling `signInWithGoogle()`, don't expect a
  user object back — watch `authStateChangesProvider` (or just trust
  the router, which already does this for you).
- **Navigation on success is NOT handled by the controller.** Sign-in
  success doesn't call `context.go('/home')` anywhere in this code —
  the router's `redirect` (Part 3) reacts to `authStatusProvider`
  changing and moves the user forward automatically. This is the
  single source of truth for "where should the user be right now",
  and keeping it in one place avoids the two systems disagreeing.
- **Error handling path:** datasource throws typed exceptions →
  repository catches and maps to `Failure` → controller puts it in
  `AsyncError` → screen's `ref.listen` shows `failure.uiMessage` in a
  snackbar. No layer above the repository ever sees a raw Supabase
  exception.
- **Password validation** requires 8+ chars, 1 uppercase, 1 number —
  adjust `core/utils/validators.dart` if your product requirements
  differ (e.g. add a symbol requirement).

## Testing this part

With Supabase configured:
1. Sign up with email → check your Supabase dashboard's Auth → Users
   table for the new row → app should auto-navigate to `/onboarding`
   (the stub from Part 3) once the session resolves.
2. Sign out (no UI for this yet — Settings ships later; for now you
   can temporarily call `ref.read(authControllerProvider.notifier).signOut()`
   from a debug button) → app should redirect back to `/login`.
3. Try invalid credentials → snackbar should show the Supabase-provided
   error message.

---

## 🎉 Sprint 1 complete

Theme system, component library, navigation, and authentication are
all done and wired together end-to-end. **Next up is Sprint 2: Home,
Profile, Settings** — say the word when you're ready to start it.

# FluentX — Sprint 1, Part 3: Navigation (GoRouter Shell)

## Files delivered

```
lib/main.dart                                    (updated — Hive init + ProviderScope)
lib/app/app.dart                                   (MaterialApp.router wiring)
lib/routes/route_paths.dart
lib/routes/app_router.dart
lib/core/router/auth_status.dart                    (⚠️ temporary stub — see below)
lib/core/router/onboarding_status_provider.dart
lib/core/router/router_notifier.dart
lib/core/router/page_transitions.dart
lib/core/router/bootstrap_screen.dart
lib/shared/widgets/navigation/app_shell.dart

lib/features/splash/presentation/screens/splash_screen.dart        (real)
lib/features/onboarding/.../onboarding_screen.dart                 (stub)
lib/features/authentication/.../login_screen.dart                  (stub)
lib/features/authentication/.../signup_screen.dart                 (stub)
lib/features/authentication/.../forgot_password_screen.dart        (stub)
lib/features/home/.../home_screen.dart                             (stub)
lib/features/ai_practice/.../ai_practice_hub_screen.dart           (stub)
lib/features/vocabulary/.../vocabulary_screen.dart                 (stub)
lib/features/grammar/.../grammar_screen.dart                       (stub)
lib/features/listening/.../listening_screen.dart                   (stub)
lib/features/writing/.../writing_screen.dart                       (stub)
lib/features/interview_prep/.../interview_prep_screen.dart         (stub)
lib/features/progress/.../progress_screen.dart                     (stub)
lib/features/communication_dna/.../communication_dna_screen.dart   (stub)
lib/features/profile/.../profile_screen.dart                       (stub)
lib/features/premium/.../premium_screen.dart                       (stub)
lib/features/settings/.../settings_screen.dart                     (stub)
```

## Information Architecture decision (flagging per your rules)

**Bottom nav = 4 tabs only: Home, AI Practice, Progress, Profile.**

Vocabulary, Grammar, Listening, Writing, Interview Prep, Communication
DNA, Premium, and Settings are NOT tabs — they're pushed as full-screen
routes (accessed via cards/buttons from Home, the AI Practice hub, or
Profile). Reasoning:

- Apple/Linear/Notion-style IA avoids cramming 8+ destinations into a
  bottom bar — that reads as cluttered, which directly violates your
  "No clutter" design requirement.
- Communication DNA is a cross-cutting insight (it pulls from every
  module), so it lives inside Progress rather than owning its own tab.
- Settings/Premium are typically one level under Profile in premium
  apps, not primary nav destinations.

**If you'd prefer a different tab structure** (e.g. 5 tabs with
Vocabulary promoted to top-level), tell me and I'll adjust
`app_shell.dart` + `app_router.dart` — it's a contained change.

## How the redirect logic works

`app_router.dart`'s `redirect` callback runs on every navigation and
enforces, in order:

1. `AuthStatus.unknown` (session still resolving) → stay on `/splash`
2. `AuthStatus.unauthenticated` + protected route → `/login`
3. Authenticated but `onboardingComplete == false` → `/onboarding`
4. Authenticated + onboarded but sitting on a pre-auth screen → `/home`

`RouterNotifier` (a `ChangeNotifier`) listens to both
`authStatusProvider` and `onboardingCompleteProvider` via Riverpod and
calls `notifyListeners()` on change — this is wired as GoRouter's
`refreshListenable`, so e.g. a session expiring mid-use immediately
re-triggers the redirect check without waiting for the user's next tap.

## ⚠️ Temporary stub — will be replaced in Part 4

`lib/core/router/auth_status.dart` currently exposes:

```dart
final authStatusProvider = StateProvider<AuthStatus>((ref) => AuthStatus.unauthenticated);
```

This is a placeholder so the redirect logic is testable right now. In
**Sprint 1 Part 4 (Authentication)**, this single file will be replaced
with a `StreamProvider` mapping Supabase's `onAuthStateChange` into
`AuthStatus` (including the `unknown` state while the persisted session
loads). Nothing else changes — `app_router.dart` and `router_notifier.dart`
only depend on the `AuthStatus` enum shape, not this file's internals.

## Bootstrap screens

Every feature not yet built (everything except Splash) renders a
`BootstrapScreen` — a real, on-brand widget (not fake logic) that shows
the feature name + which sprint will implement it. When that feature's
sprint arrives, its screen file's contents get replaced; the route path
and file location stay identical, so nothing else in the app needs to
change.

## Testing this part

Even with only Splash "real", you can already verify the whole redirect
graph works: run the app → lands on Splash → immediately redirects to
`/login` (since the stub defaults to `unauthenticated`) → the Login
stub renders. Flip `authStatusProvider`'s default to `authenticated` and
`onboardingComplete` to `true` temporarily to confirm it lands on
`/home` with the 4-tab bar working (tab switching preserves each tab's
stack).

---

**Next step:** confirm this part (and the 4-tab IA decision), then I'll
generate **Sprint 1, Part 4 — Authentication** (Supabase email/password +
Google + Apple Sign-In, the real `authStatusProvider`, forms wired to
`AppTextField`/`PrimaryButton`, and Clean Architecture data/domain/application
layers for the auth feature) — closing out Sprint 1.

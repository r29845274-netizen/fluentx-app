# FluentX — Sprint 6: Payments, Notifications, Testing (complete)

## 🎉 This is the final sprint — all 6 development-order sprints are now done.

## Files delivered

```
supabase/migrations/0008_fcm_token.sql

lib/features/premium/         (domain/data/application/presentation, full Clean Architecture)
lib/core/services/notification_service.dart, notification_service_provider.dart
lib/main.dart                  (updated — Firebase, Crashlytics, timezone, RevenueCat init)
lib/app/app.dart                (updated — syncs RevenueCat identity with Supabase auth)
lib/features/profile/...        (updated — real isPremium instead of hardcoded false)
lib/features/settings/...        (updated — real notification toggle)

analysis_options.yaml           (NEW — strict lint rules)
codemagic.yaml                   (NEW — CI/CD: analyze, test, build, publish to Play internal track)

test/features/vocabulary/domain/services/sm2_scheduler_test.dart
test/features/profile/domain/level_progress_test.dart
test/core/utils/validators_test.dart
test/shared/widgets/buttons/primary_button_test.dart
```

## ⚠️ Required steps

1. Run `0008_fcm_token.sql` in Supabase SQL Editor.
2. `flutter pub get` (new dependency: `timezone`).
3. `dart run build_runner build --delete-conflicting-outputs`
   (new Freezed files: `SubscriptionStatus`, `PremiumPackage`).
4. **RevenueCat dashboard setup:**
   - Create an entitlement with identifier exactly `premium` (matches
     `PurchaseRemoteDataSourceImpl._entitlementId`).
   - Create monthly/yearly products and attach them to an Offering
     named `current` (RevenueCat's default).
   - Get your public API key, pass it via `--dart-define=REVENUECAT_API_KEY=...`.
5. **Firebase setup:**
   - Create a Firebase project, add Android/iOS apps.
   - Download `google-services.json` → `android/app/`.
   - Download `GoogleService-Info.plist` → `ios/Runner/`.
   - (`Firebase.initializeApp()` in `main.dart` is wrapped in a
     try/catch so local dev without these files won't crash — but
     push/analytics/crash reporting won't work until they're added.)
6. **Android notification icon:** add a monochrome icon at
   `android/app/src/main/res/drawable/ic_launcher` referenced by
   `notification_service.dart` (`@mipmap/ic_launcher` works as a
   placeholder but a dedicated small monochrome icon looks better in
   the status bar per Android design guidelines).
7. Run the full test suite: `flutter test`.

## Key engineering decisions — flagged honestly

- **Payments are fully real** — RevenueCat SDK integration (offerings,
  purchase, restore), synced to Supabase auth identity via
  `Purchases.logIn`/`logOut`. No mock purchase flow.
- **Notifications: FCM registration + local reminder are real.**
  Sending an actual push campaign (e.g. "your streak is about to
  expire") needs a server-side scheduler calling the FCM Admin API —
  that's infrastructure outside a Flutter client's scope, flagged in
  the migration comment rather than faked with a client-side "push".
- **Account deletion remains a "coming soon"** (from Sprint 2) — still
  correctly requires a Supabase Edge Function with the service role,
  not shipped this sprint to keep scope focused on Payments/Notifications/Testing.
- **Test coverage is a real starting point, not exhaustive** — covers
  the two most business-critical pure-logic units (SM-2 scheduler,
  level calculator), the validators, and one widget test as a pattern
  example. Expand coverage per-feature as the codebase matures;
  `codemagic.yaml`'s test workflow will run whatever's added here.
- **CI/CD**: `codemagic.yaml` defines two workflows — a fast
  analyze+test loop for every push, and a full Android internal-track
  build+publish gated to `main`. You'll need to add the referenced
  Codemagic environment group (`fluentx_secrets`) and Android signing
  keystore in the Codemagic dashboard — these are account-level
  secrets that can't be committed to the repo.

## Full production checklist (what's still needed beyond this codebase)

- Legal: Privacy Policy + Terms of Service pages (Settings already links to them, content TBD)
- Play Store listing: screenshots, description, content rating questionnaire
- iOS: Apple Developer account, App Store Connect setup, Apple Sign-In already scaffolded
- Real device testing across a range of Android OEMs (speech_to_text and flutter_tts quality varies by manufacturer)

---

## Full sprint recap

1. **Theme, Components, Navigation, Authentication** ✅
2. **Home, Profile, Settings** ✅
3. **Vocabulary (SM-2), Grammar (quiz + mistake tracking)** ✅
4. **Listening (on-device TTS), Writing (real AI scoring)** ✅
5. **AI Practice (voice conversation), Communication DNA™ (radar chart)** ✅
6. **Payments (RevenueCat), Notifications (FCM), Testing, CI/CD** ✅

FluentX's full codebase — 5 SQL migrations for content, 3 Edge
Functions for AI, and a complete Clean Architecture Flutter app — is
now ready for the setup steps above, then Play Store submission.

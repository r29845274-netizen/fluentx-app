# FluentX — Supabase connection ready

- Project: FluentX
- Region: ap-south-1 (Mumbai)
- Project URL: https://ampcghxowbeocfqqnnvk.supabase.co
- Client key type: Supabase publishable key
- The Flutter client has safe default values for the Supabase URL and publishable key.
- Build-time `--dart-define` values can still override these defaults in CI.
- Server-side OpenAI access remains in the Supabase `OPENAI_API_KEY` secret and is not embedded in the app.
- Email OTP template/configuration is expected to be enabled in Supabase Auth.

Next production integrations: Firebase/FCM and RevenueCat/Google Play billing, then release build + real-device test.

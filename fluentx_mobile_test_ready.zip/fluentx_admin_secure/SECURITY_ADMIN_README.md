# FluentX Security + Admin Console

Implemented on the production Supabase project:

- RLS enabled on application data.
- Anonymous Data API access removed from FluentX application tables.
- Server-side-only admin allowlist (`admin_users`).
- Server-side-only append-style admin audit log (`admin_audit_log`).
- Admin Edge Function uses a server-only service credential; no privileged key is shipped in Flutter.
- Admin access requires a valid user JWT **and AAL2 TOTP MFA**.
- Roles: `owner`, `admin`, `support`.
- Sensitive learning content requires `owner`/`admin`, a written access reason, and creates an audit entry.
- Passwords, OTPs, refresh tokens, API keys and authentication secrets are never returned by the admin API.
- AI scenario system prompts are blocked from normal client reads with column privileges.
- New public tables are auto-RLS protected; default client grants are deny-by-default.
- Supabase Security Advisor currently reports zero security lints.

## Owner activation

No FluentX Auth user exists yet in the Supabase project. After the owner signs up/logs in once, add that exact Auth user ID to `public.admin_users` with role `owner`. Do not create an owner role based only on an arbitrary client-supplied email.

## Privacy boundary

The Admin Console does not send admin/user records to third-party analytics. AI Practice/Writing necessarily sends the user's requested AI content to the configured OpenAI server-side API; payments and push notifications use their configured providers. Document these processors in the Privacy Policy before production launch.

# FluentX — Reference Image Match (gap closure)

## What was added

```
supabase/migrations/0009_onboarding_goal.sql
supabase/migrations/0010_achievements.sql        (real aggregation RPC)

lib/features/onboarding/    (was a stub — now real: welcome → goal
                              selection → 3-question diagnostic → done)
lib/features/achievements/  (NEW feature — 6 badges matching the
                              reference image, unlock status driven by
                              real progress data)

lib/routes/route_paths.dart, app_router.dart   (added /achievements route)
lib/features/profile/...                        (Achievements tile now navigates for real)
lib/features/progress/...                        (added Achievements quick-link card)
```

## Onboarding — now matches the reference image's screen 2

- **Welcome page**: icon, tagline, "Get Started" — matches the mockup's phone frame #2.
- **Goal selection**: 5 cards (Interview Prep / Daily English / Business
  English / Exam Prep / General Fluency), single-select, "Skip for now" available.
- **3-question diagnostic**: hardcoded grammar MCQs (kept separate from
  Grammar's real Supabase-backed question bank — this is a one-time
  first-impression touch, not spaced-repetition content).
- On completion: saves the goal to `user_home_stats.learning_goal`,
  marks onboarding complete (the Hive flag from Sprint 1), router
  redirects to Home automatically.
- **Honest limitation**: the diagnostic score is shown for encouragement
  only — it does NOT yet feed into Communication DNA's Grammar score.
  Flagged in code comments as a reasonable future enhancement, not
  silently dropped.

## Achievements — new feature, matches the reference image's badge grid

6 badges, exactly matching the reference: First Steps, 7 Day Streak,
30 Day Streak, AI Conversation, 1000 Minutes, Vocabulary Hero.

Unlock thresholds are **computed from real data**, not hand-toggled:
- First Steps → onboarding completed (local flag)
- 7/30 Day Streak → `user_home_stats.streak_days`
- AI Conversation → completed `ai_practice_sessions` count ≥ 10
- 1000 Minutes → summed `ai_practice_sessions` duration ≥ 1000 min
- Vocabulary Hero → words with `repetition >= 2` in
  `user_vocabulary_progress` ≥ 500

All aggregated server-side by `get_achievement_stats` (same pattern as
Communication DNA's RPC) so the client never re-derives thresholds
inconsistently across screens.

## ⚠️ Required steps

1. Run `0009_onboarding_goal.sql` then `0010_achievements.sql`.
2. `dart run build_runner build --delete-conflicting-outputs`
   (new Freezed file: `AchievementStats`).

## What was intentionally NOT built (and why)

The reference image is a **pitch/marketing graphic**, not a pure UI
spec — several elements in it are presentation art, not app screens:

- The dark-navy hero panel with the 3D character illustration
  ("Your Personal AI Communication Coach") — that's cover art for the
  graphic itself, not a real screen in the 7-screen "APP STRUCTURE &
  UI FLOW" row.
- "Idioms & Phrases" and "Business English" as separate Learn tiles —
  not in the original 14-feature spec; their content already exists as
  category tags within Vocabulary/Grammar (e.g. Business-category
  words). Adding decorative tiles that route nowhere distinct would be
  the fake-UI pattern I've been avoiding all along — better to extend
  Vocabulary/Grammar's category filtering in a later sprint if you want
  these as first-class entry points.
- Splash screen illustration — the reference splash is simple branding
  (logo + "FluentX" + loading bar), which is what Sprint 1's version
  already has; no meaningful gap there.

If you want the Learn hub's category-filtered tiles (Idioms & Phrases,
Business English as real filtered views) built next, say so and I'll
add category-parameterized routes to Vocabulary/Grammar rather than
decorative dead-end tiles.

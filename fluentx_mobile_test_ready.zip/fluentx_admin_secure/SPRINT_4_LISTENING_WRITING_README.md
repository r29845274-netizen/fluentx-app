# FluentX — Sprint 4: Listening + Writing (complete)

## Files delivered

```
supabase/migrations/0004_listening.sql
supabase/migrations/0005_writing.sql
supabase/functions/score-writing/index.ts   (NEW — real Edge Function, needs deploy)

lib/features/listening/   (domain/data/application/presentation, full Clean Architecture)
lib/features/writing/     (domain/data/application/presentation, full Clean Architecture)

pubspec.yaml  (added flutter_tts: ^4.0.2)
```

## ⚠️ Required steps

1. Run `0004_listening.sql` and `0005_writing.sql` in Supabase SQL Editor.
2. `flutter pub get` (new dependency: `flutter_tts`).
3. `dart run build_runner build --delete-conflicting-outputs`
   (new Freezed files: `ListeningClip`/`ListeningQuestion`,
   `WritingPrompt`/`WritingSubmission`).
4. **Deploy the Edge Function** (Writing won't score without this):
   ```bash
   supabase functions deploy score-writing
   supabase secrets set OPENAI_API_KEY=sk-...
   ```

## Key engineering decisions — flagged honestly

- **Listening uses on-device TTS (`flutter_tts`), not hosted audio
  files.** No CDN/storage bucket exists yet, and I won't fabricate
  broken audio URLs. Speech rate (0.5 normal / 0.32 slow) covers
  "native-speed + slowed variants" from the spec entirely offline and
  free. This is upgradeable later — swap in a real `audio_url` column
  and prefer it when present — without touching the schema.
- **Writing's AI scoring is REAL, not mocked** — `score-writing` is
  actual, deployable Deno/TypeScript code that calls OpenAI
  (`gpt-4o-mini`) and writes scores back via the service role (bypassing
  RLS, which is why the RLS policies on `writing_submissions`
  deliberately don't allow the client to set score columns itself —
  see the SQL comment). Until you deploy it and set the
  `OPENAI_API_KEY` secret, submitting a draft will show a real error
  via `ErrorStateWidget`, not a fake score — honest failure over fake
  success.
- **No new routes added** — Listening clips and Writing prompts both
  open via `AppBottomSheet` (same pattern as Grammar's quiz in Sprint
  3), keeping velocity high without touching the router again this
  sprint.
- **Listening progress and Writing submissions are both persisted**
  (`user_listening_progress`, `writing_submissions`) — real data,
  ready to feed Communication DNA in Sprint 5.

## Testing

1. Run both migrations, deploy the Edge Function, set the OpenAI secret.
2. Learn → Listening → tap a clip → Play (TTS reads the transcript) →
   toggle Slow → Take Comprehension Quiz → score saves to
   `user_listening_progress`.
3. Learn → Writing → tap a prompt → write 10+ words → Submit for AI
   Feedback → should show 4 real AI-generated scores + written
   feedback after a few seconds.

---

Next per roadmap: **Sprint 5 — AI Practice, Communication DNA™**.
Say the word.

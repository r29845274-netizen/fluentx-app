# FluentX — Sprint 3: Vocabulary + Grammar (complete)

## Files delivered

```
supabase/migrations/0002_vocabulary.sql   (tables + RPC + 16 seed words)
supabase/migrations/0003_grammar.sql       (tables + RPC + 3 lessons/6 questions)

lib/features/vocabulary/
  domain/entities/due_word.dart                (Freezed — needs codegen)
  domain/services/sm2_scheduler.dart              (pure SM-2 algorithm, unit-testable)
  domain/repositories/vocabulary_repository.dart
  domain/usecases/get_due_vocabulary.dart, submit_word_review.dart
  data/models/due_word_model.dart
  data/datasources/vocabulary_remote_datasource.dart
  data/repositories/vocabulary_repository_impl.dart
  application/providers/vocabulary_providers.dart
  presentation/screens/vocabulary_screen.dart      (replaces stub)
  presentation/widgets/vocabulary_flashcard.dart, review_rating_buttons.dart

lib/features/grammar/
  domain/entities/grammar_lesson.dart            (Freezed — needs codegen)
  domain/repositories/grammar_repository.dart
  domain/usecases/*.dart                            (3 use cases)
  data/models/grammar_lesson_model.dart
  data/datasources/grammar_remote_datasource.dart
  data/repositories/grammar_repository_impl.dart
  application/providers/grammar_providers.dart
  presentation/screens/grammar_screen.dart          (replaces stub)
  presentation/widgets/grammar_quiz_sheet.dart

lib/features/learn/presentation/screens/learn_hub_screen.dart  (now real, not a stub)
```

## ⚠️ Required steps

1. Run **both** new migrations in Supabase SQL Editor, in order:
   `0002_vocabulary.sql` then `0003_grammar.sql`.
2. `dart run build_runner build --delete-conflicting-outputs`
   (2 new Freezed files: `DueWord`, `GrammarLesson`/`GrammarQuestion`).

## How each feature works

**Vocabulary (spaced repetition):**
- `get_due_vocabulary_words` Postgres function returns words that are
  either brand-new (no progress row) or whose SM-2 `due_date` has
  arrived — computed server-side so the client never has to reason
  about "new vs. due" itself.
- Rating a card (Again/Hard/Good/Easy) runs the real SM-2 algorithm
  (`Sm2Scheduler`, pure Dart, zero dependencies — easy to unit test)
  and upserts the result. Wrong ("Again") resets the streak and
  reschedules for tomorrow; correct answers grow the interval using
  the standard SM-2 ease-factor curve.

**Grammar (lessons + quiz + mistake tracking):**
- Lessons list → tap opens a bottom-sheet quiz (keeps the single
  `/grammar` route from Sprint 1 rather than adding new routes for
  every lesson — faster to ship, same user experience).
- Every wrong answer calls `increment_grammar_mistake` (a Postgres
  upsert-or-increment function, avoiding a client-side
  read-then-write race). This `user_grammar_mistakes` table is exactly
  what Communication DNA's Grammar Accuracy score will read from in
  Sprint 5.

**Learn hub** now genuinely links to all 4 modules — Vocabulary and
Grammar work end-to-end; Listening and Writing still open their Sprint
4 placeholder screens.

## Testing

1. Run migrations + codegen.
2. Open Learn tab → Vocabulary → flip cards, rate them → ratings
   persist (check `user_vocabulary_progress` in Supabase).
3. Learn tab → Grammar → tap a lesson → answer questions → wrong
   answers should increment `user_grammar_mistakes` for that lesson's
   category.

---

Next per roadmap: **Sprint 4 — Listening, Writing**. Say the word.

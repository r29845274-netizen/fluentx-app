from pathlib import Path
import re
import shutil

root = Path(__file__).resolve().parents[1]
android = root / 'android'
if not android.exists():
    raise SystemExit('android/ does not exist. Run flutter create first.')

GOOGLE_SERVICES_PLUGIN = '4.5.0'
CRASHLYTICS_PLUGIN = '3.0.7'
PACKAGE_NAME = 'io.fluentx.app'


def ensure_kts_plugin(text: str, plugin_id: str, version: str | None = None, apply_false: bool = False) -> str:
    if f'id("{plugin_id}")' in text:
        return text
    blocks = list(re.finditer(r'plugins\s*\{', text))
    if not blocks:
        return text
    pos = blocks[0].end()
    suffix = f' version "{version}"' if version else ''
    suffix += ' apply false' if apply_false else ''
    return text[:pos] + f'\n    id("{plugin_id}"){suffix}' + text[pos:]


def ensure_groovy_plugin(text: str, plugin_id: str, version: str | None = None, apply_false: bool = False) -> str:
    if f"id '{plugin_id}'" in text or f'id "{plugin_id}"' in text:
        return text
    blocks = list(re.finditer(r'plugins\s*\{', text))
    if not blocks:
        return text
    pos = blocks[0].end()
    suffix = f" version '{version}'" if version else ''
    suffix += ' apply false' if apply_false else ''
    return text[:pos] + f"\n    id '{plugin_id}'{suffix}" + text[pos:]


# Current Flutter templates declare plugin versions in settings.gradle.kts.
settings_kts = android / 'settings.gradle.kts'
if settings_kts.exists():
    text = settings_kts.read_text()
    text = ensure_kts_plugin(text, 'com.google.gms.google-services', GOOGLE_SERVICES_PLUGIN, True)
    text = ensure_kts_plugin(text, 'com.google.firebase.crashlytics', CRASHLYTICS_PLUGIN, True)
    settings_kts.write_text(text)

settings_groovy = android / 'settings.gradle'
if settings_groovy.exists():
    text = settings_groovy.read_text()
    text = ensure_groovy_plugin(text, 'com.google.gms.google-services', GOOGLE_SERVICES_PLUGIN, True)
    text = ensure_groovy_plugin(text, 'com.google.firebase.crashlytics', CRASHLYTICS_PLUGIN, True)
    settings_groovy.write_text(text)

# Some layouts keep plugin versions at the Android project root.
root_kts = android / 'build.gradle.kts'
if root_kts.exists() and 'plugins {' in root_kts.read_text():
    text = root_kts.read_text()
    text = ensure_kts_plugin(text, 'com.google.gms.google-services', GOOGLE_SERVICES_PLUGIN, True)
    text = ensure_kts_plugin(text, 'com.google.firebase.crashlytics', CRASHLYTICS_PLUGIN, True)
    root_kts.write_text(text)

root_groovy = android / 'build.gradle'
if root_groovy.exists() and 'plugins {' in root_groovy.read_text():
    text = root_groovy.read_text()
    text = ensure_groovy_plugin(text, 'com.google.gms.google-services', GOOGLE_SERVICES_PLUGIN, True)
    text = ensure_groovy_plugin(text, 'com.google.firebase.crashlytics', CRASHLYTICS_PLUGIN, True)
    root_groovy.write_text(text)

# Kotlin DSL app module.
kts = android / 'app' / 'build.gradle.kts'
if kts.exists():
    text = kts.read_text()
    text = ensure_kts_plugin(text, 'com.google.gms.google-services')
    text = ensure_kts_plugin(text, 'com.google.firebase.crashlytics')
    text = re.sub(r'namespace\s*=\s*"[^"]+"', f'namespace = "{PACKAGE_NAME}"', text)
    text = re.sub(r'applicationId\s*=\s*"[^"]+"', f'applicationId = "{PACKAGE_NAME}"', text)
    text = text.replace('minSdk = flutter.minSdkVersion', 'minSdk = 24')
    text = text.replace('targetSdk = flutter.targetSdkVersion', 'targetSdk = 36')
    text = text.replace('compileSdk = flutter.compileSdkVersion', 'compileSdk = 36')
    kts.write_text(text)

# Groovy app-module fallback.
groovy = android / 'app' / 'build.gradle'
if groovy.exists():
    text = groovy.read_text()
    text = ensure_groovy_plugin(text, 'com.google.gms.google-services')
    text = ensure_groovy_plugin(text, 'com.google.firebase.crashlytics')
    text = re.sub(r'namespace\s+["\'][^"\']+["\']', f'namespace "{PACKAGE_NAME}"', text)
    text = re.sub(r'applicationId\s+["\'][^"\']+["\']', f'applicationId "{PACKAGE_NAME}"', text)
    text = re.sub(r'minSdk(?:Version)?\s+flutter\.minSdkVersion', 'minSdkVersion 24', text)
    text = re.sub(r'targetSdk(?:Version)?\s+flutter\.targetSdkVersion', 'targetSdkVersion 36', text)
    text = re.sub(r'compileSdk(?:Version)?\s+flutter\.compileSdkVersion', 'compileSdkVersion 36', text)
    groovy.write_text(text)

# Copy Firebase config after android/ exists.
source_google_services = root / 'config' / 'firebase' / 'google-services.json'
if not source_google_services.exists():
    raise SystemExit('Missing config/firebase/google-services.json')
app_google_services = android / 'app' / 'google-services.json'
app_google_services.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(source_google_services, app_google_services)

# Keep MainActivity package aligned with application id.
for main_activity in android.glob('app/src/main/kotlin/**/MainActivity.kt'):
    text = main_activity.read_text()
    text = re.sub(r'^package\s+[^\n]+', f'package {PACKAGE_NAME}', text, count=1, flags=re.M)
    main_activity.write_text(text)

manifest = android / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
if manifest.exists():
    text = manifest.read_text()
    permissions = [
        '<uses-permission android:name="android.permission.INTERNET" />',
        '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
        '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    ]
    app_pos = text.find('<application')
    if app_pos != -1:
        prefix = text[:app_pos]
        suffix = text[app_pos:]
        for permission in permissions:
            if permission not in text:
                prefix += f'    {permission}\n'
        text = prefix + suffix

    callback = '''
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="io.fluentx.app" android:host="login-callback" />
            </intent-filter>'''
    if 'android:scheme="io.fluentx.app"' not in text:
        activity_close = text.find('</activity>')
        if activity_close != -1:
            text = text[:activity_close] + callback + '\n        ' + text[activity_close:]
    manifest.write_text(text)

print('Android Firebase patch complete:')
print(f' - package: {PACKAGE_NAME}')
print(' - google-services.json -> android/app/google-services.json')
print(f' - Google Services plugin: {GOOGLE_SERVICES_PLUGIN}')
print(f' - Crashlytics plugin: {CRASHLYTICS_PLUGIN}')
print(' - compileSdk/targetSdk: 36')

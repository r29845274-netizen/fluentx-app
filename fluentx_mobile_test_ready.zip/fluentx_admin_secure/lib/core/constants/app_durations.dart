import 'package:flutter/animation.dart';

/// Animation duration and curve constants.
///
/// FluentX's premium feel depends heavily on consistent, subtle motion.
/// All transitions in the app should pull from this file rather than
/// using ad-hoc Duration values scattered across widgets.
abstract final class AppDurations {
  const AppDurations._();

  /// 150ms — micro-interactions (button press scale, ripple)
  static const Duration fast = Duration(milliseconds: 150);

  /// 200ms — standard UI transitions (hover, toggle, expand)
  static const Duration standard = Duration(milliseconds: 200);

  /// 250ms — page-level and larger surface transitions
  static const Duration medium = Duration(milliseconds: 250);

  /// 400ms — deliberate, larger motion (onboarding illustrations, DNA chart)
  static const Duration slow = Duration(milliseconds: 400);

  /// Default easing curve used across the app for a smooth, premium feel.
  static const Curve standardCurve = Curves.easeOutCubic;

  /// Used for elements entering the screen (fade/slide in).
  static const Curve enterCurve = Curves.easeOut;

  /// Used for elements leaving the screen.
  static const Curve exitCurve = Curves.easeIn;
}

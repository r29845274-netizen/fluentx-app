/// Spacing constants based on an 8pt grid system.
///
/// Never hardcode raw spacing numbers inside widgets — always reference
/// these constants so the entire app stays visually consistent and
/// easy to re-tune from a single source of truth.
abstract final class AppSpacing {
  const AppSpacing._();

  /// 4.0 — micro spacing (icon-to-label gaps, tight chips)
  static const double xs = 4;

  /// 8.0 — base unit (compact element spacing)
  static const double sm = 8;

  /// 12.0 — small component internal padding
  static const double md = 12;

  /// 16.0 — default screen padding, standard gaps
  static const double base = 16;

  /// 24.0 — section spacing
  static const double lg = 24;

  /// 32.0 — large section breaks
  static const double xl = 32;

  /// 48.0 — screen-level vertical rhythm
  static const double xxl = 48;

  /// 64.0 — hero/empty-state spacing
  static const double xxxl = 64;
}

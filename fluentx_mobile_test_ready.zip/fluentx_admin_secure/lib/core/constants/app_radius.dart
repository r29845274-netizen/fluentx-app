import 'package:flutter/widgets.dart';

/// Border radius constants used across every component in the app.
///
/// Keeping radii centralized prevents visual drift between screens
/// (e.g. one card at 16 and another at 20) that makes an app feel
/// inconsistent and unpolished.
abstract final class AppRadius {
  const AppRadius._();

  /// 10.0 — small elements: chips, tags, badges
  static const double sm = 10;

  /// 14.0 — buttons, input fields
  static const double md = 14;

  /// 20.0 — cards, containers, dialogs
  static const double lg = 20;

  /// 28.0 — bottom sheets (top corners only)
  static const double xl = 28;

  /// 100.0 — fully pill-shaped elements (filter chips, tags)
  static const double full = 100;

  // ---- Pre-built BorderRadius helpers ----

  static final BorderRadius smAll = BorderRadius.circular(sm);
  static final BorderRadius mdAll = BorderRadius.circular(md);
  static final BorderRadius lgAll = BorderRadius.circular(lg);
  static final BorderRadius fullAll = BorderRadius.circular(full);

  /// Bottom sheets only round the top corners.
  static final BorderRadius bottomSheetTop = BorderRadius.only(
    topLeft: Radius.circular(xl),
    topRight: Radius.circular(xl),
  );
}

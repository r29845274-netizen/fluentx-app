import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timezone/timezone.dart' as tz;

import '../theme/theme_mode_provider.dart' show kSettingsBoxName;

const String _kNotificationsEnabledKey = 'notifications_enabled';
const int _kDailyReminderNotificationId = 1001;

/// Wraps push (FCM) registration and the local daily-practice-reminder
/// notification. A single service class rather than spreading
/// FCM/local-notification calls across screens keeps the platform
/// channel setup (which has real footguns — timezone data, Android
/// notification channels, iOS permission timing) in one tested place.
class NotificationService {
  NotificationService(this._supabase);

  final SupabaseClient _supabase;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  Box<dynamic> get _settingsBox => Hive.box(kSettingsBoxName);

  bool get isEnabled => _settingsBox.get(_kNotificationsEnabledKey, defaultValue: false) as bool;

  Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    await _localNotifications.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
    );
  }

  /// Requests both push and local notification permission, and if
  /// granted: registers the FCM token against the signed-in user and
  /// schedules the daily reminder. Returns whether permission was
  /// granted.
  Future<bool> enable({required int reminderHour, required int reminderMinute}) async {
    final settings = await FirebaseMessaging.instance.requestPermission();
    final granted = settings.authorizationStatus == AuthorizationStatus.authorized ||
        settings.authorizationStatus == AuthorizationStatus.provisional;

    if (!granted) {
      await _settingsBox.put(_kNotificationsEnabledKey, false);
      return false;
    }

    await _settingsBox.put(_kNotificationsEnabledKey, true);
    await _registerFcmToken();
    await scheduleDailyReminder(hour: reminderHour, minute: reminderMinute);
    return true;
  }

  Future<void> disable() async {
    await _settingsBox.put(_kNotificationsEnabledKey, false);
    await _localNotifications.cancel(_kDailyReminderNotificationId);
  }

  Future<void> _registerFcmToken() async {
    final token = await FirebaseMessaging.instance.getToken();
    final userId = _supabase.auth.currentUser?.id;
    if (token == null || userId == null) return;

    await _supabase.from('user_home_stats').upsert({'user_id': userId, 'fcm_token': token});
  }

  Future<void> scheduleDailyReminder({required int hour, required int minute}) async {
    await _localNotifications.zonedSchedule(
      _kDailyReminderNotificationId,
      'Time to practice! 🎯',
      "You haven't hit your daily goal yet — even 5 minutes counts.",
      _nextInstanceOf(hour, minute),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'daily_reminder',
          'Daily Practice Reminder',
          channelDescription: 'Reminds you to complete your daily speaking goal',
          importance: Importance.defaultImportance,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  tz.TZDateTime _nextInstanceOf(int hour, int minute) {
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    return scheduled;
  }
}

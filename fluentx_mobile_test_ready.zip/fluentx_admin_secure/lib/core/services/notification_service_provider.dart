import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../network/supabase_provider.dart';
import 'notification_service.dart';

final notificationServiceProvider = Provider<NotificationService>((ref) {
  return NotificationService(ref.watch(supabaseClientProvider));
});

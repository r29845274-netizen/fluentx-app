import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/authentication/application/providers/auth_providers.dart';

/// Coarse-grained authentication state consumed by the router's
/// redirect logic.
enum AuthStatus {
  /// Session check in progress (e.g. reading persisted Supabase
  /// session on cold start, or waiting for `onAuthStateChange`'s first
  /// event). Router keeps the user on splash.
  unknown,

  authenticated,
  unauthenticated,
}

/// Derives [AuthStatus] from the authentication feature's
/// `authStateChangesProvider` (Supabase's `onAuthStateChange` stream).
///
/// This file is intentionally the router's ONLY window into auth —
/// `app_router.dart` and `router_notifier.dart` depend on this
/// provider and the [AuthStatus] enum, never on the authentication
/// feature's internals directly. That keeps the router decoupled from
/// how auth is implemented.
final authStatusProvider = Provider<AuthStatus>((ref) {
  final authState = ref.watch(authStateChangesProvider);

  return authState.when(
    data: (user) => user != null ? AuthStatus.authenticated : AuthStatus.unauthenticated,
    loading: () => AuthStatus.unknown,
    // A stream error (e.g. malformed persisted session) shouldn't trap
    // the user on splash forever — fall back to unauthenticated so
    // they can at least reach the login screen and retry.
    error: (_, __) => AuthStatus.unauthenticated,
  );
});

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../constants/app_durations.dart';

/// Builds a [CustomTransitionPage] with FluentX's standard fade-through
/// transition (200-250ms, easeOutCubic) so every route push in the app
/// feels consistent — GoRouter's platform default (Cupertino slide on
/// iOS, nothing on Android) reads as inconsistent across platforms.
CustomTransitionPage<T> buildPageWithTransition<T>({
  required BuildContext context,
  required GoRouterState state,
  required Widget child,
}) {
  return CustomTransitionPage<T>(
    key: state.pageKey,
    child: child,
    transitionDuration: AppDurations.medium,
    reverseTransitionDuration: AppDurations.medium,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      final fadeIn = CurvedAnimation(
        parent: animation,
        curve: AppDurations.standardCurve,
      );
      final fadeOut = CurvedAnimation(
        parent: secondaryAnimation,
        curve: AppDurations.standardCurve,
      );

      return FadeTransition(
        opacity: fadeIn,
        child: FadeTransition(
          opacity: Tween<double>(begin: 1, end: 0).animate(fadeOut),
          child: child,
        ),
      );
    },
  );
}

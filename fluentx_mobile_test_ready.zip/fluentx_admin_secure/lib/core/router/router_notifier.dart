import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'auth_status.dart';
import 'onboarding_status_provider.dart';

/// Bridges Riverpod state into GoRouter's `refreshListenable`.
///
/// GoRouter's redirect logic is pull-based (it calls `redirect` on
/// navigation), but auth/onboarding state can change *without* a
/// navigation event (e.g. a session expiring in the background). This
/// notifier listens to the relevant providers and calls
/// [notifyListeners] on change, which makes GoRouter re-evaluate
/// `redirect` immediately — e.g. auto-kicking a user to `/login` the
/// moment their session drops, without waiting for their next tap.
class RouterNotifier extends ChangeNotifier {
  RouterNotifier(this._ref) {
    _ref
      ..listen(authStatusProvider, (_, __) => notifyListeners())
      ..listen(onboardingCompleteProvider, (_, __) => notifyListeners());
  }

  final Ref _ref;

  AuthStatus get authStatus => _ref.read(authStatusProvider);

  bool get isOnboardingComplete => _ref.read(onboardingCompleteProvider);
}

final routerNotifierProvider = Provider<RouterNotifier>((ref) {
  return RouterNotifier(ref);
});

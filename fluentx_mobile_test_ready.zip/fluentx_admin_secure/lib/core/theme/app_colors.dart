import 'package:flutter/material.dart';

/// Raw color tokens for FluentX — light and dark palettes.
///
/// IMPORTANT: Widgets should almost never reference [AppColors] directly.
/// Instead, use `Theme.of(context).colorScheme` or the `context.colors`
/// extension (see [AppColorSchemeExtension] below), so the correct
/// light/dark value is always resolved automatically. [AppColors] exists
/// only as the single source of truth consumed by [AppTheme] when
/// building each [ColorScheme].
abstract final class AppColors {
  const AppColors._();

  // ---------------- LIGHT ----------------
  static const Color lightPrimary = Color(0xFF2563EB);
  static const Color lightPrimaryPressed = Color(0xFF1D4ED8);
  static const Color lightOnPrimary = Color(0xFFFFFFFF);

  static const Color lightBackground = Color(0xFFF8FAFC);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightSurfaceAlt = Color(0xFFF1F5F9);
  static const Color lightBorder = Color(0xFFE2E8F0);

  static const Color lightTextPrimary = Color(0xFF0F172A);
  static const Color lightTextSecondary = Color(0xFF64748B);
  static const Color lightTextDisabled = Color(0xFFCBD5E1);

  static const Color lightSuccess = Color(0xFF16A34A);
  static const Color lightError = Color(0xFFDC2626);
  static const Color lightWarning = Color(0xFFD97706);

  // ---------------- DARK ----------------
  static const Color darkPrimary = Color(0xFF3B82F6);
  static const Color darkPrimaryPressed = Color(0xFF60A5FA);
  static const Color darkOnPrimary = Color(0xFF0B0F19);

  static const Color darkBackground = Color(0xFF0B0F19);
  static const Color darkSurface = Color(0xFF151B28);
  static const Color darkSurfaceAlt = Color(0xFF1B2333);
  static const Color darkBorder = Color(0xFF1F2937);

  static const Color darkTextPrimary = Color(0xFFF1F5F9);
  static const Color darkTextSecondary = Color(0xFF94A3B8);
  static const Color darkTextDisabled = Color(0xFF475569);

  static const Color darkSuccess = Color(0xFF22C55E);
  static const Color darkError = Color(0xFFEF4444);
  static const Color darkWarning = Color(0xFFF59E0B);
}

/// Extra semantic colors that don't map cleanly onto Material's
/// [ColorScheme] roles (e.g. success/warning). Attached to [ThemeData]
/// via [ThemeExtension] so they participate in theme animation and
/// remain accessible through `Theme.of(context).extension<AppSemanticColors>()`.
@immutable
class AppSemanticColors extends ThemeExtension<AppSemanticColors> {
  const AppSemanticColors({
    required this.success,
    required this.warning,
    required this.surfaceAlt,
    required this.pressed,
  });

  final Color success;
  final Color warning;
  final Color surfaceAlt;
  final Color pressed;

  static const light = AppSemanticColors(
    success: AppColors.lightSuccess,
    warning: AppColors.lightWarning,
    surfaceAlt: AppColors.lightSurfaceAlt,
    pressed: AppColors.lightPrimaryPressed,
  );

  static const dark = AppSemanticColors(
    success: AppColors.darkSuccess,
    warning: AppColors.darkWarning,
    surfaceAlt: AppColors.darkSurfaceAlt,
    pressed: AppColors.darkPrimaryPressed,
  );

  @override
  AppSemanticColors copyWith({
    Color? success,
    Color? warning,
    Color? surfaceAlt,
    Color? pressed,
  }) {
    return AppSemanticColors(
      success: success ?? this.success,
      warning: warning ?? this.warning,
      surfaceAlt: surfaceAlt ?? this.surfaceAlt,
      pressed: pressed ?? this.pressed,
    );
  }

  @override
  AppSemanticColors lerp(ThemeExtension<AppSemanticColors>? other, double t) {
    if (other is! AppSemanticColors) return this;
    return AppSemanticColors(
      success: Color.lerp(success, other.success, t)!,
      warning: Color.lerp(warning, other.warning, t)!,
      surfaceAlt: Color.lerp(surfaceAlt, other.surfaceAlt, t)!,
      pressed: Color.lerp(pressed, other.pressed, t)!,
    );
  }
}

/// Convenience accessor so call sites can write `context.colors.success`
/// instead of the more verbose `Theme.of(context).extension<...>()`.
extension AppColorSchemeExtension on BuildContext {
  ColorScheme get colors => Theme.of(this).colorScheme;

  AppSemanticColors get semanticColors =>
      Theme.of(this).extension<AppSemanticColors>() ?? AppSemanticColors.light;
}

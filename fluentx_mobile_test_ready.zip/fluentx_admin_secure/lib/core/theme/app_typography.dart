import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Builds FluentX's Manrope-based [TextTheme] for both light and dark
/// modes. Sizes/weights follow the design system scale:
///
/// Display (32/700) · H1 (28/700) · H2 (24/700) · H3 (20/600) ·
/// Body Large (16/500) · Body Medium (14/500) · Body Small (13/400) ·
/// Caption (12/400) · Button (15/600)
abstract final class AppTypography {
  const AppTypography._();

  static TextTheme _buildTextTheme(Color primaryText, Color secondaryText) {
    final base = GoogleFonts.manropeTextTheme();

    return base.copyWith(
      // Display → onboarding heroes, splash
      displayLarge: GoogleFonts.manrope(
        fontSize: 32,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.5,
        height: 1.2,
        color: primaryText,
      ),
      // H1 → screen titles
      headlineLarge: GoogleFonts.manrope(
        fontSize: 28,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.3,
        height: 1.25,
        color: primaryText,
      ),
      // H2 → section titles
      headlineMedium: GoogleFonts.manrope(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        height: 1.3,
        color: primaryText,
      ),
      // H3 → card headers, dialog titles
      headlineSmall: GoogleFonts.manrope(
        fontSize: 20,
        fontWeight: FontWeight.w600,
        height: 1.3,
        color: primaryText,
      ),
      // Body Large
      bodyLarge: GoogleFonts.manrope(
        fontSize: 16,
        fontWeight: FontWeight.w500,
        height: 1.5,
        color: primaryText,
      ),
      // Body Medium → default body text
      bodyMedium: GoogleFonts.manrope(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        height: 1.5,
        color: primaryText,
      ),
      // Body Small
      bodySmall: GoogleFonts.manrope(
        fontSize: 13,
        fontWeight: FontWeight.w400,
        height: 1.4,
        color: secondaryText,
      ),
      // Caption
      labelSmall: GoogleFonts.manrope(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        height: 1.3,
        color: secondaryText,
      ),
      // Button text
      labelLarge: GoogleFonts.manrope(
        fontSize: 15,
        fontWeight: FontWeight.w600,
        height: 1.2,
        letterSpacing: 0.1,
        color: primaryText,
      ),
    );
  }

  static TextTheme light(Color primaryText, Color secondaryText) =>
      _buildTextTheme(primaryText, secondaryText);

  static TextTheme dark(Color primaryText, Color secondaryText) =>
      _buildTextTheme(primaryText, secondaryText);
}

import 'package:freezed_annotation/freezed_annotation.dart';

part 'failures.freezed.dart';

/// Sealed set of domain-layer failures.
///
/// Repositories return `Either<Failure, T>` (via `fpdart`) instead of
/// throwing, so every use case and controller handles errors
/// explicitly and exhaustively via pattern matching (`.when(...)`)
/// rather than relying on try/catch scattered through the UI layer.
@freezed
sealed class Failure with _$Failure {
  const factory Failure.server({required String message}) = ServerFailure;

  const factory Failure.network({
    @Default('No internet connection. Please check your network.') String message,
  }) = NetworkFailure;

  const factory Failure.auth({required String message}) = AuthFailure;

  const factory Failure.cache({required String message}) = CacheFailure;

  const factory Failure.unexpected({
    @Default('Something went wrong. Please try again.') String message,
  }) = UnexpectedFailure;
}

/// Uniform access to the human-readable message regardless of which
/// [Failure] variant occurred — lets the UI layer show `failure.uiMessage`
/// without a `.when(...)` at every call site.
extension FailureUiMessage on Failure {
  String get uiMessage => switch (this) {
        ServerFailure(:final message) => message,
        NetworkFailure(:final message) => message,
        AuthFailure(:final message) => message,
        CacheFailure(:final message) => message,
        UnexpectedFailure(:final message) => message,
      };
}

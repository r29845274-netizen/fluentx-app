/// Exceptions thrown by datasources (data layer only).
///
/// These never escape the repository — `AuthRepositoryImpl` catches
/// them and converts to a [Failure] before returning to the domain
/// layer, so use cases and the UI never need to know about
/// Supabase-specific or Dio-specific exception types.
class ServerException implements Exception {
  const ServerException(this.message);
  final String message;
}

class AuthException implements Exception {
  const AuthException(this.message);
  final String message;
}

class NetworkException implements Exception {
  const NetworkException(this.message);
  final String message;
}

class CacheException implements Exception {
  const CacheException(this.message);
  final String message;
}

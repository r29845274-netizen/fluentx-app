import 'package:fpdart/fpdart.dart';

import '../../../../core/error/exceptions.dart';
import '../../../../core/error/failures.dart';
import '../../domain/entities/subscription_status.dart';
import '../../domain/repositories/purchase_repository.dart';
import '../datasources/purchase_remote_datasource.dart';

class PurchaseRepositoryImpl implements PurchaseRepository {
  PurchaseRepositoryImpl(this._remoteDataSource);
  final PurchaseRemoteDataSource _remoteDataSource;

  @override
  Stream<SubscriptionStatus> get subscriptionStatusChanges =>
      _remoteDataSource.subscriptionStatusChanges;

  @override
  Future<Either<Failure, List<PremiumPackage>>> getPackages() async {
    try {
      return right(await _remoteDataSource.getPackages());
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }

  @override
  Future<Either<Failure, SubscriptionStatus>> purchase(String packageIdentifier) async {
    try {
      return right(await _remoteDataSource.purchase(packageIdentifier));
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }

  @override
  Future<Either<Failure, SubscriptionStatus>> restorePurchases() async {
    try {
      return right(await _remoteDataSource.restorePurchases());
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }
}

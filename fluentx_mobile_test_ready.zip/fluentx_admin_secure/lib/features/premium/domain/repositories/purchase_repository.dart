import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/subscription_status.dart';

abstract class PurchaseRepository {
  Stream<SubscriptionStatus> get subscriptionStatusChanges;

  Future<Either<Failure, List<PremiumPackage>>> getPackages();

  Future<Either<Failure, SubscriptionStatus>> purchase(String packageIdentifier);

  Future<Either<Failure, SubscriptionStatus>> restorePurchases();
}

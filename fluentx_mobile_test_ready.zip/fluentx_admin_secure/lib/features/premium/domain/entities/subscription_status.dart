import 'package:freezed_annotation/freezed_annotation.dart';

part 'subscription_status.freezed.dart';

@freezed
class SubscriptionStatus with _$SubscriptionStatus {
  const factory SubscriptionStatus({
    required bool isPremium,
    String? productIdentifier,
    DateTime? expirationDate,
    required bool willRenew,
  }) = _SubscriptionStatus;

  static const free = SubscriptionStatus(isPremium: false, willRenew: false);
}

/// A purchasable package (monthly/yearly) surfaced from RevenueCat's
/// current offering — never hardcode prices, always read from what
/// RevenueCat resolves for the user's store/region.
@freezed
class PremiumPackage with _$PremiumPackage {
  const factory PremiumPackage({
    required String identifier,
    required String title,
    required String priceString,
    required String period, // 'monthly' | 'yearly'
  }) = _PremiumPackage;
}

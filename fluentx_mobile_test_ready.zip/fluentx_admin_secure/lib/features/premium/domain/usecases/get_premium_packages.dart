import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/subscription_status.dart';
import '../repositories/purchase_repository.dart';

class GetPremiumPackages {
  const GetPremiumPackages(this._repository);
  final PurchaseRepository _repository;

  Future<Either<Failure, List<PremiumPackage>>> call() => _repository.getPackages();
}

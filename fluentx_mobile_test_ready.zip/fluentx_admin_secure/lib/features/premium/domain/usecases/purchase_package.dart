import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/subscription_status.dart';
import '../repositories/purchase_repository.dart';

class PurchasePackage {
  const PurchasePackage(this._repository);
  final PurchaseRepository _repository;

  Future<Either<Failure, SubscriptionStatus>> call(String packageIdentifier) {
    return _repository.purchase(packageIdentifier);
  }
}

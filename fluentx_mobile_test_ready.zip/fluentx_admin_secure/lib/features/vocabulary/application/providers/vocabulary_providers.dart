import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/supabase_provider.dart';
import '../../../authentication/application/providers/auth_providers.dart';
import '../../data/datasources/vocabulary_remote_datasource.dart';
import '../../data/repositories/vocabulary_repository_impl.dart';
import '../../domain/entities/due_word.dart';
import '../../domain/repositories/vocabulary_repository.dart';
import '../../domain/usecases/get_due_vocabulary.dart';
import '../../domain/usecases/submit_word_review.dart';

final vocabularyRemoteDataSourceProvider = Provider<VocabularyRemoteDataSource>((ref) {
  return VocabularyRemoteDataSourceImpl(ref.watch(supabaseClientProvider));
});

final vocabularyRepositoryProvider = Provider<VocabularyRepository>((ref) {
  return VocabularyRepositoryImpl(ref.watch(vocabularyRemoteDataSourceProvider));
});

final getDueVocabularyUseCaseProvider = Provider<GetDueVocabulary>((ref) {
  return GetDueVocabulary(ref.watch(vocabularyRepositoryProvider));
});

final submitWordReviewUseCaseProvider = Provider<SubmitWordReview>((ref) {
  return SubmitWordReview(ref.watch(vocabularyRepositoryProvider));
});

/// Today's review deck. `autoDispose` so leaving the screen and coming
/// back later refetches (picking up newly-due words) instead of
/// serving a stale cached deck.
final dueWordsProvider = FutureProvider.autoDispose<List<DueWord>>((ref) async {
  final user = ref.watch(authStateChangesProvider).value;
  if (user == null) return const [];

  final result = await ref.watch(getDueVocabularyUseCaseProvider).call(user.id);
  return result.match((failure) => throw failure, (words) => words);
});

/// Drives the flashcard review session: current card index, and
/// submitting a rating advances to the next card.
class VocabularyReviewController extends AutoDisposeNotifier<int> {
  @override
  int build() => 0;

  Future<void> submitAndAdvance(DueWord word, ReviewQuality quality) async {
    final user = ref.read(authStateChangesProvider).value;
    if (user == null) return;

    await ref
        .read(submitWordReviewUseCaseProvider)
        .call(userId: user.id, word: word, quality: quality);

    state = state + 1;
  }
}

final vocabularyReviewControllerProvider =
    AutoDisposeNotifierProvider<VocabularyReviewController, int>(
  VocabularyReviewController.new,
);

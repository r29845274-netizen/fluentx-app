import 'package:flutter/material.dart';

import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../domain/entities/due_word.dart';

class _RatingButtonSpec {
  const _RatingButtonSpec(this.quality, this.label, this.color);
  final ReviewQuality quality;
  final String label;
  final Color color;
}

/// The 4 SM-2 rating buttons shown once a flashcard is revealed.
class ReviewRatingButtons extends StatelessWidget {
  const ReviewRatingButtons({required this.onRated, super.key});

  final ValueChanged<ReviewQuality> onRated;

  static const _specs = [
    _RatingButtonSpec(ReviewQuality.again, 'Again', Color(0xFFDC2626)),
    _RatingButtonSpec(ReviewQuality.hard, 'Hard', Color(0xFFD97706)),
    _RatingButtonSpec(ReviewQuality.good, 'Good', Color(0xFF2563EB)),
    _RatingButtonSpec(ReviewQuality.easy, 'Easy', Color(0xFF16A34A)),
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        for (final spec in _specs) ...[
          if (spec != _specs.first) const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: OutlinedButton(
              onPressed: () => onRated(spec.quality),
              style: OutlinedButton.styleFrom(
                foregroundColor: spec.color,
                side: BorderSide(color: spec.color, width: 1.5),
                shape: RoundedRectangleBorder(borderRadius: AppRadius.mdAll),
                padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
              ),
              child: Text(spec.label),
            ),
          ),
        ],
      ],
    );
  }
}

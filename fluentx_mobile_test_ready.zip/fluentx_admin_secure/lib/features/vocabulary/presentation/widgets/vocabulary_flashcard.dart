import 'package:flutter/material.dart';

import '../../../../core/constants/app_durations.dart';
import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../domain/entities/due_word.dart';

/// A single flip-to-reveal flashcard. Front shows the word + category;
/// tapping flips to definition + example sentence.
class VocabularyFlashcard extends StatefulWidget {
  const VocabularyFlashcard({required this.word, super.key});

  final DueWord word;

  @override
  State<VocabularyFlashcard> createState() => _VocabularyFlashcardState();
}

class _VocabularyFlashcardState extends State<VocabularyFlashcard> {
  bool _revealed = false;

  @override
  void didUpdateWidget(covariant VocabularyFlashcard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.word.wordId != widget.word.wordId) {
      setState(() => _revealed = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return GestureDetector(
      onTap: () => setState(() => _revealed = !_revealed),
      child: AnimatedSwitcher(
        duration: AppDurations.medium,
        transitionBuilder: (child, animation) =>
            FadeTransition(opacity: animation, child: child),
        child: Container(
          key: ValueKey(_revealed),
          width: double.infinity,
          constraints: const BoxConstraints(minHeight: 320),
          padding: const EdgeInsets.all(AppSpacing.xl),
          decoration: BoxDecoration(
            color: colorScheme.surface,
            borderRadius: AppRadius.lgAll,
            border: Border.all(color: colorScheme.outline),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: 4),
                decoration: BoxDecoration(
                  color: colorScheme.primary.withValues(alpha: 0.1),
                  borderRadius: AppRadius.fullAll,
                ),
                child: Text(
                  widget.word.category,
                  style: textTheme.labelSmall?.copyWith(color: colorScheme.primary),
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              if (!_revealed) ...[
                Text(
                  widget.word.word,
                  style: textTheme.displayLarge,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: AppSpacing.lg),
                Text(
                  'Tap to reveal meaning',
                  style: textTheme.bodySmall?.copyWith(color: colorScheme.onSurfaceVariant),
                ),
              ] else ...[
                Text(
                  widget.word.word,
                  style: textTheme.headlineSmall,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: AppSpacing.base),
                Text(
                  widget.word.definition,
                  style: textTheme.bodyLarge,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: AppSpacing.base),
                Text(
                  '"${widget.word.exampleSentence}"',
                  style: textTheme.bodyMedium?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                    fontStyle: FontStyle.italic,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

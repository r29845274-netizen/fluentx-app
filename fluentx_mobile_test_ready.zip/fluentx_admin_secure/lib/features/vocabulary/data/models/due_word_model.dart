import '../../domain/entities/due_word.dart';

extension DueWordMapper on Map<String, dynamic> {
  DueWord toDueWord() {
    return DueWord(
      wordId: this['word_id'] as String,
      word: this['word'] as String,
      definition: this['definition'] as String,
      exampleSentence: this['example_sentence'] as String,
      category: this['category'] as String,
      repetition: (this['repetition'] as num).toInt(),
      easeFactor: (this['ease_factor'] as num).toDouble(),
      intervalDays: (this['interval_days'] as num).toInt(),
      dueDate: DateTime.parse(this['due_date'] as String),
    );
  }
}

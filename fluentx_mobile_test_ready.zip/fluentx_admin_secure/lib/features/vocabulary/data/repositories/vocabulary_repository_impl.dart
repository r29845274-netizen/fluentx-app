import 'package:fpdart/fpdart.dart';

import '../../../../core/error/exceptions.dart';
import '../../../../core/error/failures.dart';
import '../../domain/entities/due_word.dart';
import '../../domain/repositories/vocabulary_repository.dart';
import '../datasources/vocabulary_remote_datasource.dart';

class VocabularyRepositoryImpl implements VocabularyRepository {
  VocabularyRepositoryImpl(this._remoteDataSource);

  final VocabularyRemoteDataSource _remoteDataSource;

  @override
  Future<Either<Failure, List<DueWord>>> getDueWords({
    required String userId,
    int limit = 10,
  }) async {
    try {
      final words = await _remoteDataSource.getDueWords(userId: userId, limit: limit);
      return right(words);
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }

  @override
  Future<Either<Failure, Unit>> submitReview({
    required String userId,
    required DueWord word,
    required ReviewQuality quality,
  }) async {
    try {
      await _remoteDataSource.submitReview(userId: userId, word: word, quality: quality);
      return right(unit);
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }
}

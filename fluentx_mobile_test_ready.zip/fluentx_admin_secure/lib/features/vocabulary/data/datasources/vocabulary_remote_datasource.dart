import 'package:supabase_flutter/supabase_flutter.dart' as supabase;

import '../../../../core/error/exceptions.dart';
import '../../domain/entities/due_word.dart';
import '../../domain/services/sm2_scheduler.dart';
import '../models/due_word_model.dart';

abstract class VocabularyRemoteDataSource {
  Future<List<DueWord>> getDueWords({required String userId, int limit = 10});

  Future<void> submitReview({
    required String userId,
    required DueWord word,
    required ReviewQuality quality,
  });
}

class VocabularyRemoteDataSourceImpl implements VocabularyRemoteDataSource {
  VocabularyRemoteDataSourceImpl(this._client);

  final supabase.SupabaseClient _client;

  @override
  Future<List<DueWord>> getDueWords({required String userId, int limit = 10}) async {
    try {
      final rows = await _client.rpc<List<dynamic>>(
        'get_due_vocabulary_words',
        params: {'p_user_id': userId, 'p_limit': limit},
      );
      return rows.map((row) => (row as Map<String, dynamic>).toDueWord()).toList();
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<void> submitReview({
    required String userId,
    required DueWord word,
    required ReviewQuality quality,
  }) async {
    try {
      final now = DateTime.now();
      final result = Sm2Scheduler.schedule(
        currentRepetition: word.repetition,
        currentEaseFactor: word.easeFactor,
        quality: quality,
        reviewedAt: now,
      );

      await _client.from('user_vocabulary_progress').upsert({
        'user_id': userId,
        'word_id': word.wordId,
        'repetition': result.repetition,
        'ease_factor': result.easeFactor,
        'interval_days': result.intervalDays,
        'due_date': result.dueDate.toIso8601String().split('T').first,
        'last_reviewed_at': now.toIso8601String(),
      });
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }
}

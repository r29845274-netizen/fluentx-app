import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/due_word.dart';

abstract class VocabularyRepository {
  Future<Either<Failure, List<DueWord>>> getDueWords({
    required String userId,
    int limit = 10,
  });

  Future<Either<Failure, Unit>> submitReview({
    required String userId,
    required DueWord word,
    required ReviewQuality quality,
  });
}

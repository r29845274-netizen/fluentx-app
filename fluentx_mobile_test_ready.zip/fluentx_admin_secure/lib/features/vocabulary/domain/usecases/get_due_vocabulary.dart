import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/due_word.dart';
import '../repositories/vocabulary_repository.dart';

class GetDueVocabulary {
  const GetDueVocabulary(this._repository);

  final VocabularyRepository _repository;

  Future<Either<Failure, List<DueWord>>> call(String userId, {int limit = 10}) {
    return _repository.getDueWords(userId: userId, limit: limit);
  }
}

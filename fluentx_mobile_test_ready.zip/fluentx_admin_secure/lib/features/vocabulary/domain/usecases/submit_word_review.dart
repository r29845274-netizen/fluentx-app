import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/due_word.dart';
import '../repositories/vocabulary_repository.dart';

class SubmitWordReview {
  const SubmitWordReview(this._repository);

  final VocabularyRepository _repository;

  Future<Either<Failure, Unit>> call({
    required String userId,
    required DueWord word,
    required ReviewQuality quality,
  }) {
    return _repository.submitReview(userId: userId, word: word, quality: quality);
  }
}

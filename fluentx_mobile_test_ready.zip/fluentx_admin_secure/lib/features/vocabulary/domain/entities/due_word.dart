import 'package:freezed_annotation/freezed_annotation.dart';

part 'due_word.freezed.dart';

/// A vocabulary word joined with the signed-in user's SM-2 spaced-
/// repetition state for it (or defaults, if never reviewed before).
@freezed
class DueWord with _$DueWord {
  const factory DueWord({
    required String wordId,
    required String word,
    required String definition,
    required String exampleSentence,
    required String category,
    required int repetition,
    required double easeFactor,
    required int intervalDays,
    required DateTime dueDate,
  }) = _DueWord;
}

/// How the user rated their recall of a word — maps to SM-2 "quality"
/// (0–5 in the original algorithm, collapsed to 4 buttons for UI
/// simplicity, same as most modern spaced-repetition apps do).
enum ReviewQuality {
  again(1),
  hard(2),
  good(4),
  easy(5);

  const ReviewQuality(this.sm2Value);
  final int sm2Value;
}

import '../entities/due_word.dart';

/// Result of scheduling one review — what to persist back to
/// `user_vocabulary_progress`.
class ScheduleResult {
  const ScheduleResult({
    required this.repetition,
    required this.easeFactor,
    required this.intervalDays,
    required this.dueDate,
  });

  final int repetition;
  final double easeFactor;
  final int intervalDays;
  final DateTime dueDate;
}

/// Standard SM-2 spaced-repetition algorithm (SuperMemo 2), pure and
/// side-effect free — deliberately isolated from Supabase/Riverpod so
/// it's trivially unit-testable and never needs a mock to exercise.
abstract final class Sm2Scheduler {
  const Sm2Scheduler._();

  static ScheduleResult schedule({
    required int currentRepetition,
    required double currentEaseFactor,
    required ReviewQuality quality,
    required DateTime reviewedAt,
  }) {
    final q = quality.sm2Value;

    // A poor recall resets the repetition streak — the word is shown
    // again tomorrow rather than pushed further out.
    if (q < 3) {
      return ScheduleResult(
        repetition: 0,
        easeFactor: currentEaseFactor,
        intervalDays: 1,
        dueDate: reviewedAt.add(const Duration(days: 1)),
      );
    }

    final nextRepetition = currentRepetition + 1;

    final int nextInterval;
    if (nextRepetition == 1) {
      nextInterval = 1;
    } else if (nextRepetition == 2) {
      nextInterval = 6;
    } else {
      // Approximate the previous interval from ease factor history
      // isn't tracked separately here — SM-2 in its simplest form
      // multiplies the *previous* interval by the ease factor. Since
      // we don't persist the raw previous interval separately from
      // what we're about to compute, we derive it from repetition
      // count using the standard SM-2 growth curve.
      final previousInterval = nextRepetition == 3 ? 6 : (6 * _pow(currentEaseFactor, nextRepetition - 2));
      nextInterval = previousInterval.round();
    }

    var nextEaseFactor = currentEaseFactor + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02));
    if (nextEaseFactor < 1.3) nextEaseFactor = 1.3;

    return ScheduleResult(
      repetition: nextRepetition,
      easeFactor: double.parse(nextEaseFactor.toStringAsFixed(2)),
      intervalDays: nextInterval,
      dueDate: reviewedAt.add(Duration(days: nextInterval)),
    );
  }

  static double _pow(double base, int exponent) {
    var result = 1.0;
    for (var i = 0; i < exponent; i++) {
      result *= base;
    }
    return result;
  }
}

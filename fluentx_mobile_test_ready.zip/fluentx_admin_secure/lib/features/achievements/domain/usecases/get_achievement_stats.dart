import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/achievement_stats.dart';
import '../repositories/achievements_repository.dart';

class GetAchievementStats {
  const GetAchievementStats(this._repository);
  final AchievementsRepository _repository;

  Future<Either<Failure, AchievementStats>> call(String userId) => _repository.getStats(userId);
}

import 'package:freezed_annotation/freezed_annotation.dart';

part 'achievement_stats.freezed.dart';

@freezed
class AchievementStats with _$AchievementStats {
  const factory AchievementStats({
    required int streakDays,
    required int aiSessionCount,
    required int totalPracticeMinutes,
    required int vocabularyMasteredCount,
  }) = _AchievementStats;
}

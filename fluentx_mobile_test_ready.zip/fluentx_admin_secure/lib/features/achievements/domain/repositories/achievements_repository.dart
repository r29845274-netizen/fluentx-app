import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/achievement_stats.dart';

abstract class AchievementsRepository {
  Future<Either<Failure, AchievementStats>> getStats(String userId);
}

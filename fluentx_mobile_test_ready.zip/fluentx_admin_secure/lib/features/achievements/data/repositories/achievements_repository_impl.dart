import 'package:fpdart/fpdart.dart';

import '../../../../core/error/exceptions.dart';
import '../../../../core/error/failures.dart';
import '../../domain/entities/achievement_stats.dart';
import '../../domain/repositories/achievements_repository.dart';
import '../datasources/achievements_remote_datasource.dart';

class AchievementsRepositoryImpl implements AchievementsRepository {
  AchievementsRepositoryImpl(this._remoteDataSource);
  final AchievementsRemoteDataSource _remoteDataSource;

  @override
  Future<Either<Failure, AchievementStats>> getStats(String userId) async {
    try {
      return right(await _remoteDataSource.getStats(userId));
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }
}

import '../../domain/entities/achievement_stats.dart';

extension AchievementStatsMapper on Map<String, dynamic> {
  AchievementStats toAchievementStats() {
    return AchievementStats(
      streakDays: (this['streak_days'] as num).toInt(),
      aiSessionCount: (this['ai_session_count'] as num).toInt(),
      totalPracticeMinutes: (this['total_practice_minutes'] as num).toInt(),
      vocabularyMasteredCount: (this['vocabulary_mastered_count'] as num).toInt(),
    );
  }
}

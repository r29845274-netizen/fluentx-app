import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/supabase_provider.dart';
import '../../../authentication/application/providers/auth_providers.dart';
import '../../data/datasources/achievements_remote_datasource.dart';
import '../../data/repositories/achievements_repository_impl.dart';
import '../../domain/entities/achievement_stats.dart';
import '../../domain/repositories/achievements_repository.dart';
import '../../domain/usecases/get_achievement_stats.dart';

final achievementsRemoteDataSourceProvider = Provider<AchievementsRemoteDataSource>((ref) {
  return AchievementsRemoteDataSourceImpl(ref.watch(supabaseClientProvider));
});

final achievementsRepositoryProvider = Provider<AchievementsRepository>((ref) {
  return AchievementsRepositoryImpl(ref.watch(achievementsRemoteDataSourceProvider));
});

final getAchievementStatsUseCaseProvider = Provider<GetAchievementStats>((ref) {
  return GetAchievementStats(ref.watch(achievementsRepositoryProvider));
});

final achievementStatsProvider = FutureProvider.autoDispose<AchievementStats>((ref) async {
  final user = ref.watch(authStateChangesProvider).value;
  if (user == null) throw StateError('achievementStatsProvider read while signed out');

  final result = await ref.watch(getAchievementStatsUseCaseProvider).call(user.id);
  return result.match((failure) => throw failure, (stats) => stats);
});

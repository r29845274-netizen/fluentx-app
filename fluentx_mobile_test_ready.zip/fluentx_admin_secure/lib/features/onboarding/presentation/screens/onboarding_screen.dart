import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../../../shared/widgets/widgets.dart';
import '../../application/providers/onboarding_providers.dart';
import '../../domain/entities/onboarding_goal.dart';
import '../widgets/goal_option_card.dart';
import '../widgets/onboarding_progress_dots.dart';

class _DiagnosticQuestion {
  const _DiagnosticQuestion(this.text, this.options, this.correctIndex);
  final String text;
  final List<String> options;
  final int correctIndex;
}

/// Hardcoded, deliberately short diagnostic — 3 quick grammar
/// questions to give the user an immediate "starting point" feeling.
/// Distinct from Grammar's real lesson question bank (Sprint 3): this
/// is a one-time first-impression touch, not spaced-repetition
/// content, so it isn't fetched from Supabase.
///
/// NOTE: the result is shown for encouragement only — it does not yet
/// feed into Communication DNA's Grammar score. Wiring a real baseline
/// into that formula is a reasonable future enhancement once there's
/// value in weighting "day-1 diagnostic" differently from ongoing quiz
/// performance.
const _diagnosticQuestions = [
  _DiagnosticQuestion(
    'She ___ to the office every day.',
    ['go', 'goes', 'going', 'gone'],
    1,
  ),
  _DiagnosticQuestion(
    'I have been working here ___ three years.',
    ['since', 'for', 'from', 'during'],
    1,
  ),
  _DiagnosticQuestion(
    'Could you tell me ___ the meeting starts?',
    ['when does', 'when', 'what time does', 'time'],
    1,
  ),
];

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final _pageController = PageController();
  int _pageIndex = 0;
  OnboardingGoal? _selectedGoal;
  int _diagnosticIndex = 0;
  int? _selectedOption;
  int _correctCount = 0;

  static const _totalPages = 3;

  void _goToPage(int index) {
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
    );
    setState(() => _pageIndex = index);
  }

  Future<void> _finish() async {
    await ref.read(onboardingControllerProvider.notifier).completeOnboarding(_selectedGoal);
    // No manual navigation — router redirect reacts to
    // onboardingCompleteProvider flipping true and sends the user home.
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isSubmitting = ref.watch(onboardingControllerProvider).isLoading;
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: AppSpacing.base),
            OnboardingProgressDots(count: _totalPages, currentIndex: _pageIndex),
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                onPageChanged: (index) => setState(() => _pageIndex = index),
                children: [
                  _WelcomePage(onNext: () => _goToPage(1)),
                  _GoalPage(
                    selectedGoal: _selectedGoal,
                    onSelect: (goal) => setState(() => _selectedGoal = goal),
                    onNext: () => _goToPage(2),
                    onSkip: _finish,
                  ),
                  _DiagnosticPage(
                    questionIndex: _diagnosticIndex,
                    selectedOption: _selectedOption,
                    correctCount: _correctCount,
                    isSubmitting: isSubmitting,
                    onSelectOption: (index) {
                      setState(() {
                        _selectedOption = index;
                        if (index == _diagnosticQuestions[_diagnosticIndex].correctIndex) {
                          _correctCount++;
                        }
                      });
                    },
                    onNextQuestion: () {
                      setState(() {
                        _diagnosticIndex++;
                        _selectedOption = null;
                      });
                    },
                    onFinish: _finish,
                    onSkip: _finish,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WelcomePage extends StatelessWidget {
  const _WelcomePage({required this.onNext});
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.all(AppSpacing.xl),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 96,
            height: 96,
            decoration: BoxDecoration(color: colorScheme.primary, borderRadius: AppRadius.lgAll),
            child: Icon(LucideIcons.messageSquare, color: colorScheme.onPrimary, size: 44),
          ),
          const SizedBox(height: AppSpacing.xl),
          Text(
            'AI-Powered\nEnglish Learning',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.displayLarge,
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            'Practice real conversations, get instant feedback, and '
            'improve every day.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: AppSpacing.xxl),
          PrimaryButton(label: 'Get Started', onPressed: onNext),
        ],
      ),
    );
  }
}

class _GoalPage extends StatelessWidget {
  const _GoalPage({
    required this.selectedGoal,
    required this.onSelect,
    required this.onNext,
    required this.onSkip,
  });

  final OnboardingGoal? selectedGoal;
  final ValueChanged<OnboardingGoal> onSelect;
  final VoidCallback onNext;
  final VoidCallback onSkip;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(AppSpacing.base),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("What's your goal?", style: Theme.of(context).textTheme.displayLarge),
          const SizedBox(height: AppSpacing.xs),
          Text(
            "We'll personalize your practice around this.",
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: AppSpacing.lg),
          Expanded(
            child: ListView.separated(
              itemCount: OnboardingGoal.values.length,
              separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
              itemBuilder: (context, index) {
                final goal = OnboardingGoal.values[index];
                return GoalOptionCard(
                  goal: goal,
                  isSelected: selectedGoal == goal,
                  onTap: () => onSelect(goal),
                );
              },
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          PrimaryButton(
            label: 'Continue',
            isEnabled: selectedGoal != null,
            onPressed: selectedGoal == null ? null : onNext,
          ),
          const SizedBox(height: AppSpacing.xs),
          Center(
            child: TextButton(onPressed: onSkip, child: const Text('Skip for now')),
          ),
        ],
      ),
    );
  }
}

class _DiagnosticPage extends StatelessWidget {
  const _DiagnosticPage({
    required this.questionIndex,
    required this.selectedOption,
    required this.correctCount,
    required this.isSubmitting,
    required this.onSelectOption,
    required this.onNextQuestion,
    required this.onFinish,
    required this.onSkip,
  });

  final int questionIndex;
  final int? selectedOption;
  final int correctCount;
  final bool isSubmitting;
  final ValueChanged<int> onSelectOption;
  final VoidCallback onNextQuestion;
  final VoidCallback onFinish;
  final VoidCallback onSkip;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    if (questionIndex >= _diagnosticQuestions.length) {
      return Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(LucideIcons.partyPopper, size: 56, color: colorScheme.primary),
            const SizedBox(height: AppSpacing.base),
            Text("You're all set!", style: Theme.of(context).textTheme.displayLarge),
            const SizedBox(height: AppSpacing.sm),
            Text(
              'You got $correctCount of ${_diagnosticQuestions.length} right — a solid '
              'starting point. Your Communication DNA will refine as you practice.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                  ),
            ),
            const SizedBox(height: AppSpacing.xxl),
            PrimaryButton(label: 'Start Learning', isLoading: isSubmitting, onPressed: onFinish),
          ],
        ),
      );
    }

    final question = _diagnosticQuestions[questionIndex];

    return Padding(
      padding: const EdgeInsets.all(AppSpacing.base),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Quick check ${questionIndex + 1} of ${_diagnosticQuestions.length}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(question.text, style: Theme.of(context).textTheme.headlineLarge),
          const SizedBox(height: AppSpacing.lg),
          for (var i = 0; i < question.options.length; i++) ...[
            InkWell(
              onTap: selectedOption == null ? () => onSelectOption(i) : null,
              borderRadius: AppRadius.mdAll,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppSpacing.md),
                decoration: BoxDecoration(
                  borderRadius: AppRadius.mdAll,
                  border: Border.all(
                    color: selectedOption == null
                        ? colorScheme.outline
                        : i == question.correctIndex
                            ? colorScheme.primary
                            : i == selectedOption
                                ? colorScheme.error
                                : colorScheme.outline,
                    width: 1.5,
                  ),
                ),
                child: Text(question.options[i]),
              ),
            ),
            const SizedBox(height: AppSpacing.sm),
          ],
          const Spacer(),
          if (selectedOption != null)
            PrimaryButton(label: 'Next', onPressed: onNextQuestion)
          else
            Center(child: TextButton(onPressed: onSkip, child: const Text('Skip for now'))),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/constants/app_spacing.dart';
import '../../../../core/network/supabase_provider.dart';
import '../../../../shared/widgets/widgets.dart';

class AdminConsoleScreen extends ConsumerStatefulWidget {
  const AdminConsoleScreen({super.key});

  @override
  ConsumerState<AdminConsoleScreen> createState() => _AdminConsoleScreenState();
}

class _AdminConsoleScreenState extends ConsumerState<AdminConsoleScreen> {
  bool _loading = true;
  bool _isAdmin = false;
  bool _mfaVerified = false;
  String? _role;
  String? _error;
  Map<String, dynamic>? _overview;
  List<Map<String, dynamic>> _users = const [];
  String? _enrollmentFactorId;
  String? _enrollmentQrCode;
  String? _enrollmentSecret;
  final _mfaCodeController = TextEditingController();
  final _searchController = TextEditingController();

  SupabaseClient get _client => ref.read(supabaseClientProvider);

  @override
  void initState() {
    super.initState();
    _loadStatus();
  }

  @override
  void dispose() {
    _mfaCodeController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>> _invoke(Map<String, dynamic> body) async {
    final response = await _client.functions.invoke('admin-console', body: body);
    final data = response.data;
    if (response.status < 200 || response.status >= 300) {
      final message = data is Map ? data['error']?.toString() : null;
      throw Exception(message ?? 'Admin request failed');
    }
    return Map<String, dynamic>.from(data as Map);
  }

  Future<void> _loadStatus() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final data = await _invoke({'action': 'status'});
      _isAdmin = data['is_admin'] == true;
      _mfaVerified = data['mfa_verified'] == true;
      _role = data['role']?.toString();
      if (_mfaVerified) await _loadDashboard();
    } catch (e) {
      _isAdmin = false;
      _error = 'Admin access is not enabled for this account.';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadDashboard({String? search}) async {
    final results = await Future.wait([
      _invoke({'action': 'overview'}),
      _invoke({'action': 'list_users', 'page': 1, 'per_page': 50, if (search != null) 'search': search}),
    ]);
    _overview = results[0];
    final rows = (results[1]['users'] as List? ?? const []);
    _users = rows.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    if (mounted) setState(() {});
  }

  Future<void> _startEnrollment() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final factors = await _client.auth.mfa.listFactors();
      if (factors.totp.isNotEmpty) {
        _enrollmentFactorId = null;
        _enrollmentQrCode = null;
        _enrollmentSecret = null;
        _error = 'Authenticator is already enrolled. Enter the current 6-digit code below.';
      } else {
        final enrollment = await _client.auth.mfa.enroll(
          factorType: FactorType.totp,
          friendlyName: 'FluentX Admin',
        );
        _enrollmentFactorId = enrollment.id;
        _enrollmentQrCode = enrollment.totp.qrCode;
        _enrollmentSecret = enrollment.totp.secret;
      }
    } on AuthException catch (e) {
      _error = e.message;
    } catch (_) {
      _error = 'Could not start admin MFA setup.';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _verifyMfa() async {
    final code = _mfaCodeController.text.trim();
    if (code.length != 6) {
      setState(() => _error = 'Enter the 6-digit authenticator code.');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      String factorId;
      if (_enrollmentFactorId != null) {
        factorId = _enrollmentFactorId!;
      } else {
        final factors = await _client.auth.mfa.listFactors();
        if (factors.totp.isEmpty) throw AuthException('No authenticator factor found.');
        factorId = factors.totp.first.id;
      }
      await _client.auth.mfa.challengeAndVerify(factorId: factorId, code: code);
      await _client.auth.refreshSession();
      _mfaCodeController.clear();
      _enrollmentFactorId = null;
      _enrollmentQrCode = null;
      _enrollmentSecret = null;
      await _loadStatus();
    } on AuthException catch (e) {
      _error = e.message;
    } catch (_) {
      _error = 'MFA verification failed.';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _showUser(Map<String, dynamic> user) async {
    setState(() => _loading = true);
    try {
      final detail = await _invoke({'action': 'user_detail', 'user_id': user['id']});
      if (!mounted) return;
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) => _UserDetailSheet(
          detail: detail,
          canReadPrivate: _role != 'support',
          onPrivateContent: () => _requestPrivateContent(user['id'].toString()),
        ),
      );
    } catch (_) {
      if (mounted) setState(() => _error = 'Could not load this user.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _requestPrivateContent(String userId) async {
    Navigator.of(context).pop();
    final controller = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sensitive data access'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('This access is permanently recorded in the admin audit log. Enter a valid support/security reason.'),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              minLines: 2,
              maxLines: 4,
              decoration: const InputDecoration(labelText: 'Reason', hintText: 'Minimum 10 characters'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Continue')),
        ],
      ),
    );
    controller.dispose();
    if (reason == null || reason.length < 10) return;

    setState(() => _loading = true);
    try {
      final data = await _invoke({'action': 'user_private_content', 'user_id': userId, 'reason': reason});
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Private learning content'),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(child: SelectableText(_prettyPrivate(data))),
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
        ),
      );
    } catch (_) {
      if (mounted) setState(() => _error = 'Sensitive content access was denied or failed.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _prettyPrivate(Map<String, dynamic> data) {
    final writing = data['writing'] as List? ?? const [];
    final sessions = data['ai_sessions'] as List? ?? const [];
    final buffer = StringBuffer();
    buffer.writeln('WRITING (${writing.length})');
    for (final row in writing.take(20)) {
      final map = Map<String, dynamic>.from(row as Map);
      buffer.writeln('\n${map['created_at'] ?? ''}\n${map['content'] ?? ''}\nFeedback: ${map['ai_feedback'] ?? '-'}');
    }
    buffer.writeln('\n\nAI PRACTICE (${sessions.length})');
    for (final row in sessions.take(20)) {
      final map = Map<String, dynamic>.from(row as Map);
      buffer.writeln('\n${map['started_at'] ?? ''}\n${map['transcript'] ?? ''}');
    }
    return buffer.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Secure Admin Console')),
      body: Stack(
        children: [
          SafeArea(top: false, child: _buildBody()),
          if (_loading) const Positioned.fill(child: ColoredBox(color: Color(0x33000000), child: Center(child: CircularProgressIndicator()))),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (!_isAdmin) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.xl),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.admin_panel_settings_outlined, size: 56),
              const SizedBox(height: 16),
              const Text('Admin access denied', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(_error ?? 'This account is not an authorized FluentX administrator.', textAlign: TextAlign.center),
            ],
          ),
        ),
      );
    }

    if (!_mfaVerified) return _buildMfaGate();
    return _buildDashboard();
  }

  Widget _buildMfaGate() {
    final hasEnrollment = _enrollmentFactorId != null && _enrollmentQrCode != null && _enrollmentSecret != null;
    return ListView(
      padding: const EdgeInsets.all(AppSpacing.base),
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(children: [Icon(Icons.security), SizedBox(width: 8), Text('Admin MFA required', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700))]),
              const SizedBox(height: 12),
              const Text('Admin data is locked until a second factor from an authenticator app is verified.'),
              const SizedBox(height: 16),
              if (!hasEnrollment)
                FilledButton.icon(onPressed: _startEnrollment, icon: const Icon(Icons.phonelink_lock), label: const Text('Set up / verify authenticator')),
              if (hasEnrollment) ...[
                Center(child: SvgPicture.string(_enrollmentQrCode!, width: 190, height: 190)),
                const SizedBox(height: 12),
                const Text('Scan in Google Authenticator/Authy/1Password, or copy this secret:'),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: SelectableText(_enrollmentSecret!, style: const TextStyle(fontWeight: FontWeight.w700))),
                    IconButton(
                      icon: const Icon(Icons.copy),
                      onPressed: () => Clipboard.setData(ClipboardData(text: _enrollmentSecret!)),
                    ),
                  ],
                ),
              ],
              const SizedBox(height: 16),
              TextField(
                controller: _mfaCodeController,
                keyboardType: TextInputType.number,
                maxLength: 6,
                obscureText: true,
                decoration: const InputDecoration(labelText: '6-digit authenticator code', counterText: ''),
              ),
              const SizedBox(height: 12),
              FilledButton(onPressed: _verifyMfa, child: const Text('Verify & unlock admin console')),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDashboard() {
    final o = _overview ?? const <String, dynamic>{};
    return RefreshIndicator(
      onRefresh: () => _loadDashboard(search: _searchController.text.trim()),
      child: ListView(
        padding: const EdgeInsets.all(AppSpacing.base),
        children: [
          Row(
            children: [
              Expanded(child: _MetricCard(label: 'Users', value: '${o['total_users'] ?? 0}')),
              const SizedBox(width: 8),
              Expanded(child: _MetricCard(label: 'AI Sessions', value: '${o['ai_sessions'] ?? 0}')),
              const SizedBox(width: 8),
              Expanded(child: _MetricCard(label: 'Writing', value: '${o['writing_submissions'] ?? 0}')),
            ],
          ),
          const SizedBox(height: 16),
          AppCard(
            child: Row(
              children: [
                const Icon(Icons.verified_user),
                const SizedBox(width: 10),
                Expanded(child: Text('Role: ${_role ?? 'admin'} • MFA verified • all admin reads are audited')),
              ],
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _searchController,
            decoration: InputDecoration(
              labelText: 'Search users',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(icon: const Icon(Icons.arrow_forward), onPressed: () => _loadDashboard(search: _searchController.text.trim())),
            ),
            onSubmitted: (value) => _loadDashboard(search: value.trim()),
          ),
          const SizedBox(height: 16),
          if (_error != null) Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ..._users.map((user) {
            final stats = user['stats'] is Map ? Map<String, dynamic>.from(user['stats'] as Map) : const <String, dynamic>{};
            return Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                title: Text(user['full_name']?.toString() ?? user['email']?.toString() ?? 'User'),
                subtitle: Text('${user['email'] ?? ''}\nXP ${stats['xp_earned'] ?? 0} • Streak ${stats['streak_days'] ?? 0}'),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showUser(user),
              ),
            );
          }),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => AppCard(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            Text(label, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      );
}

class _UserDetailSheet extends StatelessWidget {
  const _UserDetailSheet({required this.detail, required this.canReadPrivate, required this.onPrivateContent});
  final Map<String, dynamic> detail;
  final bool canReadPrivate;
  final VoidCallback onPrivateContent;

  @override
  Widget build(BuildContext context) {
    final user = Map<String, dynamic>.from(detail['user'] as Map? ?? const {});
    final learning = Map<String, dynamic>.from(detail['learning'] as Map? ?? const {});
    final home = Map<String, dynamic>.from(learning['home'] as Map? ?? const {});
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(left: 20, right: 20, bottom: MediaQuery.of(context).viewInsets.bottom + 24),
        child: ListView(
          shrinkWrap: true,
          children: [
            Text(user['full_name']?.toString() ?? user['email']?.toString() ?? 'User', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            SelectableText(user['email']?.toString() ?? ''),
            const Divider(height: 28),
            Text('Account created: ${user['created_at'] ?? '-'}'),
            Text('Last sign in: ${user['last_sign_in_at'] ?? '-'}'),
            Text('XP: ${home['xp_earned'] ?? 0}'),
            Text('Streak: ${home['streak_days'] ?? 0}'),
            Text('Vocabulary reviews: ${learning['vocabulary_reviews'] ?? 0}'),
            Text('Grammar mistakes: ${learning['grammar_mistakes'] ?? 0}'),
            Text('Listening avg: ${learning['average_listening_score'] ?? '-'}'),
            const SizedBox(height: 20),
            if (canReadPrivate)
              FilledButton.tonalIcon(
                onPressed: onPrivateContent,
                icon: const Icon(Icons.visibility_lock),
                label: const Text('View private learning content (audited)'),
              ),
            const SizedBox(height: 8),
            const Text('Passwords, OTPs, refresh tokens, API keys and authentication secrets are never displayed here.'),
          ],
        ),
      ),
    );
  }
}

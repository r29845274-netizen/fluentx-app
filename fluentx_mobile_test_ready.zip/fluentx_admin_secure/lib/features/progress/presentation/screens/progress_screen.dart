import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_spacing.dart';
import '../../../../routes/route_paths.dart';
import '../../../../shared/widgets/widgets.dart';
import '../../../communication_dna/application/providers/communication_dna_providers.dart';

class ProgressScreen extends ConsumerWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dnaAsync = ref.watch(communicationDnaProvider);
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Progress')),
      body: SafeArea(
        top: false,
        child: ListView(
          padding: const EdgeInsets.all(AppSpacing.base),
          children: [
            Text('Communication DNA™', style: textTheme.headlineSmall),
            const SizedBox(height: AppSpacing.sm),
            dnaAsync.when(
              data: (dna) => AppCard(
                onTap: () => context.push(RoutePaths.communicationDna),
                child: Column(
                  children: [
                    Row(
                      children: [
                        SizedBox(
                          width: 72,
                          height: 72,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              CircularProgressIndicator(
                                value: dna.overallScore / 100,
                                strokeWidth: 7,
                                backgroundColor: colorScheme.outline,
                                valueColor: AlwaysStoppedAnimation<Color>(colorScheme.primary),
                              ),
                              Text('${dna.overallScore}%', style: textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                        const SizedBox(width: AppSpacing.md),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(dna.levelLabel, style: textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600)),
                              const SizedBox(height: 2),
                              Text('Strong in ${dna.strengths.join(' & ')}', style: textTheme.bodySmall),
                            ],
                          ),
                        ),
                        Icon(LucideIcons.chevronRight, color: colorScheme.onSurfaceVariant),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    for (final entry in dna.componentsByLabel.entries) ...[
                      _SkillBar(label: entry.key, value: entry.value),
                      if (entry.key != dna.componentsByLabel.keys.last)
                        const SizedBox(height: AppSpacing.sm),
                    ],
                  ],
                ),
              ),
              loading: () => const LoadingCardSkeleton(lines: 5),
              error: (_, __) => ErrorStateWidget(
                onRetry: () => ref.invalidate(communicationDnaProvider),
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            Text('Achievements', style: textTheme.headlineSmall),
            const SizedBox(height: AppSpacing.sm),
            AppCard(
              onTap: () => context.push(RoutePaths.achievements),
              child: Row(
                children: [
                  const Icon(LucideIcons.award, color: Color(0xFFD97706)),
                  const SizedBox(width: AppSpacing.md),
                  const Expanded(child: Text('View your badges and milestones')),
                  Icon(LucideIcons.chevronRight, color: colorScheme.onSurfaceVariant),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SkillBar extends StatelessWidget {
  const _SkillBar({required this.label, required this.value});

  final String label;
  final int value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(width: 96, child: Text(label, style: Theme.of(context).textTheme.bodySmall)),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(100),
            child: LinearProgressIndicator(value: value / 100, minHeight: 7),
          ),
        ),
        const SizedBox(width: AppSpacing.sm),
        SizedBox(width: 34, child: Text('$value%', textAlign: TextAlign.right, style: Theme.of(context).textTheme.bodySmall)),
      ],
    );
  }
}

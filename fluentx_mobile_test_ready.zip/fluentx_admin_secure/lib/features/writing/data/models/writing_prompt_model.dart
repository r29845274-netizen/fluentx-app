import '../../domain/entities/writing_prompt.dart';

extension WritingPromptMapper on Map<String, dynamic> {
  WritingPrompt toWritingPrompt() {
    return WritingPrompt(
      id: this['id'] as String,
      title: this['title'] as String,
      category: this['category'] as String,
      instructions: this['instructions'] as String,
    );
  }

  WritingSubmission toWritingSubmission() {
    return WritingSubmission(
      id: this['id'] as String,
      promptId: this['prompt_id'] as String,
      content: this['content'] as String,
      grammarScore: (this['grammar_score'] as num?)?.toInt(),
      clarityScore: (this['clarity_score'] as num?)?.toInt(),
      structureScore: (this['structure_score'] as num?)?.toInt(),
      toneScore: (this['tone_score'] as num?)?.toInt(),
      aiFeedback: this['ai_feedback'] as String?,
    );
  }
}

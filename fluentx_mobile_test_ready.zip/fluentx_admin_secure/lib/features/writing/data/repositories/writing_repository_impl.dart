import 'package:fpdart/fpdart.dart';

import '../../../../core/error/exceptions.dart';
import '../../../../core/error/failures.dart';
import '../../domain/entities/writing_prompt.dart';
import '../../domain/repositories/writing_repository.dart';
import '../datasources/writing_remote_datasource.dart';

class WritingRepositoryImpl implements WritingRepository {
  WritingRepositoryImpl(this._remoteDataSource);

  final WritingRemoteDataSource _remoteDataSource;

  @override
  Future<Either<Failure, List<WritingPrompt>>> getPrompts() async {
    try {
      return right(await _remoteDataSource.getPrompts());
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }

  @override
  Future<Either<Failure, WritingSubmission>> submitDraft({
    required String userId,
    required String promptId,
    required String content,
  }) async {
    try {
      final submission = await _remoteDataSource.submitDraft(
        userId: userId,
        promptId: promptId,
        content: content,
      );
      return right(submission);
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }

  @override
  Future<Either<Failure, WritingSubmission>> scoreSubmission(String submissionId) async {
    try {
      return right(await _remoteDataSource.scoreSubmission(submissionId));
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }
}

import 'package:supabase_flutter/supabase_flutter.dart' as supabase;

import '../../../../core/error/exceptions.dart';
import '../../domain/entities/writing_prompt.dart';
import '../models/writing_prompt_model.dart';

abstract class WritingRemoteDataSource {
  Future<List<WritingPrompt>> getPrompts();

  Future<WritingSubmission> submitDraft({
    required String userId,
    required String promptId,
    required String content,
  });

  Future<WritingSubmission> scoreSubmission(String submissionId);
}

/// The `scoreSubmission` call is the ONLY place in the client that
/// touches AI scoring — it invokes the `score-writing` Supabase Edge
/// Function (see `supabase/functions/score-writing/index.ts`), which
/// holds the OpenAI key server-side. No AI key ever ships in the app
/// binary.
class WritingRemoteDataSourceImpl implements WritingRemoteDataSource {
  WritingRemoteDataSourceImpl(this._client);

  final supabase.SupabaseClient _client;

  @override
  Future<List<WritingPrompt>> getPrompts() async {
    try {
      final rows = await _client.from('writing_prompts').select().order('created_at');
      return (rows as List)
          .map((row) => (row as Map<String, dynamic>).toWritingPrompt())
          .toList();
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<WritingSubmission> submitDraft({
    required String userId,
    required String promptId,
    required String content,
  }) async {
    try {
      final row = await _client
          .from('writing_submissions')
          .insert({'user_id': userId, 'prompt_id': promptId, 'content': content})
          .select()
          .single();
      return row.toWritingSubmission();
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<WritingSubmission> scoreSubmission(String submissionId) async {
    try {
      final response = await _client.functions.invoke(
        'score-writing',
        body: {'submission_id': submissionId},
      );

      if (response.status != 200) {
        throw ServerException('Scoring failed (status ${response.status}). Please try again.');
      }

      return (response.data as Map<String, dynamic>).toWritingSubmission();
    } on supabase.FunctionException catch (e) {
      throw ServerException(e.details?.toString() ?? 'Scoring is temporarily unavailable.');
    } catch (e) {
      throw ServerException(e.toString());
    }
  }
}

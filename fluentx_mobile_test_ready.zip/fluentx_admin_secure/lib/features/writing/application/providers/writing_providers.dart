import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/supabase_provider.dart';
import '../../../authentication/application/providers/auth_providers.dart';
import '../../data/datasources/writing_remote_datasource.dart';
import '../../data/repositories/writing_repository_impl.dart';
import '../../domain/entities/writing_prompt.dart';
import '../../domain/repositories/writing_repository.dart';
import '../../domain/usecases/get_writing_prompts.dart';
import '../../domain/usecases/score_writing_submission.dart';
import '../../domain/usecases/submit_writing_draft.dart';

final writingRemoteDataSourceProvider = Provider<WritingRemoteDataSource>((ref) {
  return WritingRemoteDataSourceImpl(ref.watch(supabaseClientProvider));
});

final writingRepositoryProvider = Provider<WritingRepository>((ref) {
  return WritingRepositoryImpl(ref.watch(writingRemoteDataSourceProvider));
});

final getWritingPromptsUseCaseProvider = Provider<GetWritingPrompts>((ref) {
  return GetWritingPrompts(ref.watch(writingRepositoryProvider));
});

final submitWritingDraftUseCaseProvider = Provider<SubmitWritingDraft>((ref) {
  return SubmitWritingDraft(ref.watch(writingRepositoryProvider));
});

final scoreWritingSubmissionUseCaseProvider = Provider<ScoreWritingSubmission>((ref) {
  return ScoreWritingSubmission(ref.watch(writingRepositoryProvider));
});

final writingPromptsProvider = FutureProvider.autoDispose<List<WritingPrompt>>((ref) async {
  final result = await ref.watch(getWritingPromptsUseCaseProvider).call();
  return result.match((failure) => throw failure, (prompts) => prompts);
});

/// Drives the editor's submit flow: save the draft, then request AI
/// scoring. Two network calls, one loading state — the editor UI only
/// needs to know "idle / working / scored / failed", not which of the
/// two calls is in flight.
class WritingController extends AutoDisposeAsyncNotifier<WritingSubmission?> {
  @override
  Future<WritingSubmission?> build() async => null;

  Future<void> submitAndScore({required String promptId, required String content}) async {
    state = const AsyncLoading();

    final userId = ref.read(authStateChangesProvider).value?.id;
    if (userId == null) {
      state = AsyncError<WritingSubmission?>(
        StateError('Not signed in'),
        StackTrace.current,
      );
      return;
    }

    final draftResult = await ref
        .read(submitWritingDraftUseCaseProvider)
        .call(userId: userId, promptId: promptId, content: content);

    await draftResult.match(
      (failure) async {
        state = AsyncError<WritingSubmission?>(failure, StackTrace.current);
      },
      (draft) async {
        final scoreResult = await ref.read(scoreWritingSubmissionUseCaseProvider).call(draft.id);
        state = scoreResult.match(
          (failure) => AsyncError<WritingSubmission?>(failure, StackTrace.current),
          (scored) => AsyncData(scored),
        );
      },
    );
  }
}

final writingControllerProvider =
    AutoDisposeAsyncNotifierProvider<WritingController, WritingSubmission?>(
  WritingController.new,
);

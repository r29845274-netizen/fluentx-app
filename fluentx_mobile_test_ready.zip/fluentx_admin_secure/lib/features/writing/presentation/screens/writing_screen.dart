import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../../../shared/widgets/widgets.dart';
import '../../application/providers/writing_providers.dart';
import '../../domain/entities/writing_prompt.dart';
import '../widgets/writing_editor_sheet.dart';

class WritingScreen extends ConsumerWidget {
  const WritingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final promptsAsync = ref.watch(writingPromptsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Writing')),
      body: SafeArea(
        top: false,
        child: promptsAsync.when(
          data: (prompts) {
            if (prompts.isEmpty) {
              return const EmptyStateWidget(title: 'No prompts available yet');
            }
            return ListView.separated(
              padding: const EdgeInsets.all(AppSpacing.base),
              itemCount: prompts.length,
              separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.md),
              itemBuilder: (context, index) => _PromptCard(prompt: prompts[index]),
            );
          },
          loading: () => const LoadingWidget(),
          error: (_, __) => ErrorStateWidget(
            onRetry: () => ref.invalidate(writingPromptsProvider),
          ),
        ),
      ),
    );
  }
}

class _PromptCard extends StatelessWidget {
  const _PromptCard({required this.prompt});

  final WritingPrompt prompt;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return AppCard(
      onTap: () => AppBottomSheet.show(
        context,
        title: prompt.title,
        child: WritingEditorSheet(prompt: prompt),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFFDB2777).withValues(alpha: 0.12),
              borderRadius: AppRadius.mdAll,
            ),
            child: const Icon(LucideIcons.penLine, color: Color(0xFFDB2777), size: 20),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  prompt.title,
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                const SizedBox(height: 2),
                Text(
                  prompt.category,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                      ),
                ),
              ],
            ),
          ),
          Icon(LucideIcons.chevronRight, size: 20, color: colorScheme.onSurfaceVariant),
        ],
      ),
    );
  }
}

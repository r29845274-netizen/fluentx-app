import 'package:freezed_annotation/freezed_annotation.dart';

part 'writing_prompt.freezed.dart';

@freezed
class WritingPrompt with _$WritingPrompt {
  const factory WritingPrompt({
    required String id,
    required String title,
    required String category,
    required String instructions,
  }) = _WritingPrompt;
}

/// Scores are nullable until the `score-writing` Edge Function has run
/// — a freshly-submitted draft legitimately has no scores yet, which
/// is different from a zero score.
@freezed
class WritingSubmission with _$WritingSubmission {
  const factory WritingSubmission({
    required String id,
    required String promptId,
    required String content,
    int? grammarScore,
    int? clarityScore,
    int? structureScore,
    int? toneScore,
    String? aiFeedback,
  }) = _WritingSubmission;

  const WritingSubmission._();

  bool get isScored => grammarScore != null;
}

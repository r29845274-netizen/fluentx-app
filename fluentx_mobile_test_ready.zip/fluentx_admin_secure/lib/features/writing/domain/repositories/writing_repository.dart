import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/writing_prompt.dart';

abstract class WritingRepository {
  Future<Either<Failure, List<WritingPrompt>>> getPrompts();

  /// Saves the draft and returns the created submission (unscored).
  Future<Either<Failure, WritingSubmission>> submitDraft({
    required String userId,
    required String promptId,
    required String content,
  });

  /// Invokes the `score-writing` Edge Function for an existing
  /// submission and returns it with scores + feedback populated.
  Future<Either<Failure, WritingSubmission>> scoreSubmission(String submissionId);
}

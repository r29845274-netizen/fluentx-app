import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/writing_prompt.dart';
import '../repositories/writing_repository.dart';

class SubmitWritingDraft {
  const SubmitWritingDraft(this._repository);
  final WritingRepository _repository;

  Future<Either<Failure, WritingSubmission>> call({
    required String userId,
    required String promptId,
    required String content,
  }) {
    return _repository.submitDraft(userId: userId, promptId: promptId, content: content);
  }
}

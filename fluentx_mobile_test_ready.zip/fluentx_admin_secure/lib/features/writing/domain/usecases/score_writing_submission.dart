import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/writing_prompt.dart';
import '../repositories/writing_repository.dart';

class ScoreWritingSubmission {
  const ScoreWritingSubmission(this._repository);
  final WritingRepository _repository;

  Future<Either<Failure, WritingSubmission>> call(String submissionId) {
    return _repository.scoreSubmission(submissionId);
  }
}

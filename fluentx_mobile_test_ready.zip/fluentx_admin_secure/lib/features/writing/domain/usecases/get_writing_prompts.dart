import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/writing_prompt.dart';
import '../repositories/writing_repository.dart';

class GetWritingPrompts {
  const GetWritingPrompts(this._repository);
  final WritingRepository _repository;

  Future<Either<Failure, List<WritingPrompt>>> call() => _repository.getPrompts();
}

import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/listening_clip.dart';

abstract class ListeningRepository {
  Future<Either<Failure, List<ListeningClip>>> getClips();

  Future<Either<Failure, List<ListeningQuestion>>> getQuestions(String clipId);

  Future<Either<Failure, Unit>> submitProgress({
    required String userId,
    required String clipId,
    required double score,
  });
}

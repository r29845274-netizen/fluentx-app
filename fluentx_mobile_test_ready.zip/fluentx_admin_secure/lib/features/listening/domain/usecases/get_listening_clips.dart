import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/listening_clip.dart';
import '../repositories/listening_repository.dart';

class GetListeningClips {
  const GetListeningClips(this._repository);
  final ListeningRepository _repository;

  Future<Either<Failure, List<ListeningClip>>> call() => _repository.getClips();
}

import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../repositories/listening_repository.dart';

class SubmitListeningProgress {
  const SubmitListeningProgress(this._repository);
  final ListeningRepository _repository;

  Future<Either<Failure, Unit>> call({
    required String userId,
    required String clipId,
    required double score,
  }) {
    return _repository.submitProgress(userId: userId, clipId: clipId, score: score);
  }
}

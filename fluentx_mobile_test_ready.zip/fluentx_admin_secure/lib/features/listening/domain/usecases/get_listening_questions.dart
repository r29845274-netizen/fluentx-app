import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/listening_clip.dart';
import '../repositories/listening_repository.dart';

class GetListeningQuestions {
  const GetListeningQuestions(this._repository);
  final ListeningRepository _repository;

  Future<Either<Failure, List<ListeningQuestion>>> call(String clipId) {
    return _repository.getQuestions(clipId);
  }
}

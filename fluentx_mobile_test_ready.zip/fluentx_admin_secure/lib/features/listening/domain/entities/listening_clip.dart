import 'package:freezed_annotation/freezed_annotation.dart';

part 'listening_clip.freezed.dart';

@freezed
class ListeningClip with _$ListeningClip {
  const factory ListeningClip({
    required String id,
    required String title,
    required String category,
    required String transcript,
  }) = _ListeningClip;
}

@freezed
class ListeningQuestion with _$ListeningQuestion {
  const factory ListeningQuestion({
    required String id,
    required String clipId,
    required String questionText,
    required List<String> options,
    required int correctIndex,
  }) = _ListeningQuestion;
}

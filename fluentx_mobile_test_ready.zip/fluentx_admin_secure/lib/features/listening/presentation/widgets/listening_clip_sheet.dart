import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../../../shared/widgets/widgets.dart';
import '../../../authentication/application/providers/auth_providers.dart';
import '../../application/providers/listening_providers.dart';
import '../../domain/entities/listening_clip.dart';
import 'listening_player_controls.dart';

class ListeningClipSheet extends ConsumerStatefulWidget {
  const ListeningClipSheet({required this.clip, super.key});

  final ListeningClip clip;

  @override
  ConsumerState<ListeningClipSheet> createState() => _ListeningClipSheetState();
}

class _ListeningClipSheetState extends ConsumerState<ListeningClipSheet> {
  bool _showTranscript = false;
  bool _showQuiz = false;
  int _questionIndex = 0;
  int? _selectedOption;
  int _correctCount = 0;

  Future<void> _selectOption(int index, ListeningQuestion question) async {
    if (_selectedOption != null) return;
    setState(() => _selectedOption = index);
    if (index == question.correctIndex) _correctCount++;
  }

  Future<void> _finishQuiz(int total) async {
    final userId = ref.read(authStateChangesProvider).value?.id;
    if (userId != null) {
      await ref.read(submitListeningProgressUseCaseProvider).call(
            userId: userId,
            clipId: widget.clip.id,
            score: (_correctCount / total) * 100,
          );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_showQuiz) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListeningPlayerControls(transcript: widget.clip.transcript),
          const SizedBox(height: AppSpacing.base),
          TextButton.icon(
            onPressed: () => setState(() => _showTranscript = !_showTranscript),
            icon: Icon(_showTranscript ? Icons.visibility_off : Icons.visibility),
            label: Text(_showTranscript ? 'Hide transcript' : 'Show transcript'),
          ),
          if (_showTranscript)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(AppSpacing.base),
              margin: const EdgeInsets.only(bottom: AppSpacing.base),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: AppRadius.mdAll,
              ),
              child: Text(widget.clip.transcript, style: Theme.of(context).textTheme.bodyMedium),
            ),
          PrimaryButton(
            label: 'Take Comprehension Quiz',
            onPressed: () => setState(() => _showQuiz = true),
          ),
        ],
      );
    }

    final questionsAsync = ref.watch(listeningQuestionsProvider(widget.clip.id));

    return questionsAsync.when(
      data: (questions) {
        if (questions.isEmpty) {
          return const EmptyStateWidget(title: 'No quiz for this clip yet');
        }
        if (_questionIndex >= questions.length) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Nice work! 🎧', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: AppSpacing.sm),
              Text(
                'You got $_correctCount of ${questions.length} correct.',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              const SizedBox(height: AppSpacing.lg),
              PrimaryButton(
                label: 'Done',
                onPressed: () async {
                  await _finishQuiz(questions.length);
                  if (context.mounted) Navigator.of(context).pop();
                },
              ),
            ],
          );
        }

        final question = questions[_questionIndex];
        final colorScheme = Theme.of(context).colorScheme;

        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Question ${_questionIndex + 1} of ${questions.length}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(question.questionText, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: AppSpacing.base),
            for (var i = 0; i < question.options.length; i++) ...[
              InkWell(
                onTap: _selectedOption == null ? () => _selectOption(i, question) : null,
                borderRadius: AppRadius.mdAll,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(
                    borderRadius: AppRadius.mdAll,
                    border: Border.all(
                      color: _selectedOption == null
                          ? colorScheme.outline
                          : i == question.correctIndex
                              ? colorScheme.primary
                              : i == _selectedOption
                                  ? colorScheme.error
                                  : colorScheme.outline,
                      width: 1.5,
                    ),
                  ),
                  child: Text(question.options[i]),
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
            ],
            if (_selectedOption != null) ...[
              const SizedBox(height: AppSpacing.sm),
              PrimaryButton(
                label: _questionIndex + 1 >= questions.length ? 'See Results' : 'Next',
                onPressed: () => setState(() {
                  _questionIndex++;
                  _selectedOption = null;
                }),
              ),
            ],
          ],
        );
      },
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: AppSpacing.xxl),
        child: LoadingWidget(),
      ),
      error: (_, __) => ErrorStateWidget(
        onRetry: () => ref.invalidate(listeningQuestionsProvider(widget.clip.id)),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_spacing.dart';
import '../../application/providers/listening_providers.dart';

enum _PlaybackSpeed { normal, slow }

/// Play/pause + speed toggle for a clip's transcript, synthesized live
/// via on-device TTS (see `listening_providers.dart` for why — no
/// hosted audio files needed for this MVP).
class ListeningPlayerControls extends ConsumerStatefulWidget {
  const ListeningPlayerControls({required this.transcript, super.key});

  final String transcript;

  @override
  ConsumerState<ListeningPlayerControls> createState() => _ListeningPlayerControlsState();
}

class _ListeningPlayerControlsState extends ConsumerState<ListeningPlayerControls> {
  _PlaybackSpeed _speed = _PlaybackSpeed.normal;
  bool _isPlaying = false;

  FlutterTts get _tts => ref.read(flutterTtsProvider);

  @override
  void initState() {
    super.initState();
    _tts.setCompletionHandler(() {
      if (mounted) setState(() => _isPlaying = false);
    });
  }

  Future<void> _togglePlay() async {
    if (_isPlaying) {
      await _tts.stop();
      setState(() => _isPlaying = false);
      return;
    }

    await _tts.setSpeechRate(_speed == _PlaybackSpeed.slow ? 0.32 : 0.5);
    await _tts.setLanguage('en-US');
    setState(() => _isPlaying = true);
    await _tts.speak(widget.transcript);
  }

  Future<void> _setSpeed(_PlaybackSpeed speed) async {
    setState(() => _speed = speed);
    if (_isPlaying) {
      await _tts.stop();
      await _togglePlay();
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Row(
      children: [
        InkWell(
          onTap: _togglePlay,
          borderRadius: BorderRadius.circular(32),
          child: Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(color: colorScheme.primary, shape: BoxShape.circle),
            child: Icon(
              _isPlaying ? LucideIcons.pause : LucideIcons.play,
              color: colorScheme.onPrimary,
              size: 26,
            ),
          ),
        ),
        const SizedBox(width: AppSpacing.md),
        Expanded(
          child: SegmentedButton<_PlaybackSpeed>(
            segments: const [
              ButtonSegment(value: _PlaybackSpeed.normal, label: Text('Normal')),
              ButtonSegment(value: _PlaybackSpeed.slow, label: Text('Slow')),
            ],
            selected: {_speed},
            onSelectionChanged: (s) => _setSpeed(s.first),
          ),
        ),
      ],
    );
  }
}

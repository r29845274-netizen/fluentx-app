import 'package:fpdart/fpdart.dart';

import '../../../../core/error/exceptions.dart';
import '../../../../core/error/failures.dart';
import '../../domain/entities/listening_clip.dart';
import '../../domain/repositories/listening_repository.dart';
import '../datasources/listening_remote_datasource.dart';

class ListeningRepositoryImpl implements ListeningRepository {
  ListeningRepositoryImpl(this._remoteDataSource);

  final ListeningRemoteDataSource _remoteDataSource;

  @override
  Future<Either<Failure, List<ListeningClip>>> getClips() async {
    try {
      return right(await _remoteDataSource.getClips());
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }

  @override
  Future<Either<Failure, List<ListeningQuestion>>> getQuestions(String clipId) async {
    try {
      return right(await _remoteDataSource.getQuestions(clipId));
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }

  @override
  Future<Either<Failure, Unit>> submitProgress({
    required String userId,
    required String clipId,
    required double score,
  }) async {
    try {
      await _remoteDataSource.submitProgress(userId: userId, clipId: clipId, score: score);
      return right(unit);
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }
}

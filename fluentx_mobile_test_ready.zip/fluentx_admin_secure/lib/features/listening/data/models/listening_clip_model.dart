import '../../domain/entities/listening_clip.dart';

extension ListeningClipMapper on Map<String, dynamic> {
  ListeningClip toListeningClip() {
    return ListeningClip(
      id: this['id'] as String,
      title: this['title'] as String,
      category: this['category'] as String,
      transcript: this['transcript'] as String,
    );
  }

  ListeningQuestion toListeningQuestion() {
    return ListeningQuestion(
      id: this['id'] as String,
      clipId: this['clip_id'] as String,
      questionText: this['question_text'] as String,
      options: List<String>.from(this['options'] as List),
      correctIndex: (this['correct_index'] as num).toInt(),
    );
  }
}

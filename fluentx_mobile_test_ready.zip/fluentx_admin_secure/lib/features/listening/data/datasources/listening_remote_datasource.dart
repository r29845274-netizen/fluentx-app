import 'package:supabase_flutter/supabase_flutter.dart' as supabase;

import '../../../../core/error/exceptions.dart';
import '../../domain/entities/listening_clip.dart';
import '../models/listening_clip_model.dart';

abstract class ListeningRemoteDataSource {
  Future<List<ListeningClip>> getClips();
  Future<List<ListeningQuestion>> getQuestions(String clipId);
  Future<void> submitProgress({
    required String userId,
    required String clipId,
    required double score,
  });
}

class ListeningRemoteDataSourceImpl implements ListeningRemoteDataSource {
  ListeningRemoteDataSourceImpl(this._client);

  final supabase.SupabaseClient _client;

  @override
  Future<List<ListeningClip>> getClips() async {
    try {
      final rows = await _client.from('listening_clips').select().order('created_at');
      return (rows as List)
          .map((row) => (row as Map<String, dynamic>).toListeningClip())
          .toList();
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<List<ListeningQuestion>> getQuestions(String clipId) async {
    try {
      final rows = await _client
          .from('listening_questions')
          .select()
          .eq('clip_id', clipId);
      return (rows as List)
          .map((row) => (row as Map<String, dynamic>).toListeningQuestion())
          .toList();
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<void> submitProgress({
    required String userId,
    required String clipId,
    required double score,
  }) async {
    try {
      await _client.from('user_listening_progress').upsert({
        'user_id': userId,
        'clip_id': clipId,
        'score': score,
        'completed_at': DateTime.now().toIso8601String(),
      });
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }
}

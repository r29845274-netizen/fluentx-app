import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_tts/flutter_tts.dart';

import '../../../../core/network/supabase_provider.dart';
import '../../../authentication/application/providers/auth_providers.dart';
import '../../data/datasources/listening_remote_datasource.dart';
import '../../data/repositories/listening_repository_impl.dart';
import '../../domain/entities/listening_clip.dart';
import '../../domain/repositories/listening_repository.dart';
import '../../domain/usecases/get_listening_clips.dart';
import '../../domain/usecases/get_listening_questions.dart';
import '../../domain/usecases/submit_listening_progress.dart';

final listeningRemoteDataSourceProvider = Provider<ListeningRemoteDataSource>((ref) {
  return ListeningRemoteDataSourceImpl(ref.watch(supabaseClientProvider));
});

final listeningRepositoryProvider = Provider<ListeningRepository>((ref) {
  return ListeningRepositoryImpl(ref.watch(listeningRemoteDataSourceProvider));
});

final getListeningClipsUseCaseProvider = Provider<GetListeningClips>((ref) {
  return GetListeningClips(ref.watch(listeningRepositoryProvider));
});

final getListeningQuestionsUseCaseProvider = Provider<GetListeningQuestions>((ref) {
  return GetListeningQuestions(ref.watch(listeningRepositoryProvider));
});

final submitListeningProgressUseCaseProvider = Provider<SubmitListeningProgress>((ref) {
  return SubmitListeningProgress(ref.watch(listeningRepositoryProvider));
});

final listeningClipsProvider = FutureProvider.autoDispose<List<ListeningClip>>((ref) async {
  final result = await ref.watch(getListeningClipsUseCaseProvider).call();
  return result.match((failure) => throw failure, (clips) => clips);
});

final listeningQuestionsProvider =
    FutureProvider.autoDispose.family<List<ListeningQuestion>, String>((ref, clipId) async {
  final result = await ref.watch(getListeningQuestionsUseCaseProvider).call(clipId);
  return result.match((failure) => throw failure, (questions) => questions);
});

/// Shared `FlutterTts` instance for the Listening feature — one engine
/// instance avoids re-initializing the platform TTS channel per widget.
final flutterTtsProvider = Provider<FlutterTts>((ref) {
  final tts = FlutterTts();
  ref.onDispose(tts.stop);
  return tts;
});

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/supabase_provider.dart';
import '../../../authentication/application/providers/auth_providers.dart';
import '../../data/datasources/home_remote_datasource.dart';
import '../../data/repositories/home_repository_impl.dart';
import '../../domain/entities/home_summary.dart';
import '../../domain/repositories/home_repository.dart';
import '../../domain/usecases/get_home_summary.dart';

final homeRemoteDataSourceProvider = Provider<HomeRemoteDataSource>((ref) {
  return HomeRemoteDataSourceImpl(ref.watch(supabaseClientProvider));
});

final homeRepositoryProvider = Provider<HomeRepository>((ref) {
  return HomeRepositoryImpl(ref.watch(homeRemoteDataSourceProvider));
});

final getHomeSummaryUseCaseProvider = Provider<GetHomeSummary>((ref) {
  return GetHomeSummary(ref.watch(homeRepositoryProvider));
});

/// Fetches the signed-in user's [HomeSummary]. Depends on
/// [authStateChangesProvider] so it automatically refetches (and
/// clears) when the signed-in user changes.
final homeSummaryProvider = FutureProvider.autoDispose<HomeSummary>((ref) async {
  final user = ref.watch(authStateChangesProvider).value;
  if (user == null) {
    throw StateError('homeSummaryProvider read while signed out');
  }

  final result = await ref.watch(getHomeSummaryUseCaseProvider).call(user.id);

  return result.match(
    (failure) => throw failure,
    (summary) => summary,
  );
});

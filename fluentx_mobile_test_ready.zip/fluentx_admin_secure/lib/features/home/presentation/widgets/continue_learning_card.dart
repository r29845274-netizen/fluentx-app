import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_spacing.dart';
import '../../../../shared/widgets/widgets.dart';
import '../../domain/entities/home_summary.dart';

/// "Continue Learning" card — resumes the user's most recent
/// in-progress module.
class ContinueLearningCard extends StatelessWidget {
  const ContinueLearningCard({required this.item, required this.onTap, super.key});

  final ContinueLearningItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return AppCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: colorScheme.primary,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(LucideIcons.playCircle, color: colorScheme.onPrimary, size: 24),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: LinearProgressIndicator(
                          value: item.progressPercent,
                          minHeight: 5,
                          backgroundColor: colorScheme.outline,
                          valueColor: AlwaysStoppedAnimation<Color>(colorScheme.primary),
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Text(
                      '${(item.progressPercent * 100).round()}%',
                      style: textTheme.labelSmall,
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(item.levelLabel, style: textTheme.labelSmall),
              ],
            ),
          ),
          Icon(LucideIcons.chevronRight, color: colorScheme.onSurfaceVariant, size: 20),
        ],
      ),
    );
  }
}

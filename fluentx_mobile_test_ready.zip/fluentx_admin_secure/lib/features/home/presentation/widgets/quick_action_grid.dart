import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../../../routes/route_paths.dart';

/// Static navigation shortcut — this is UI configuration (which icon,
/// gradient, and route each tile links to), not domain data, so it's
/// intentionally a plain const list rather than something fetched.
class _QuickAction {
  const _QuickAction({
    required this.label,
    required this.icon,
    required this.gradient,
    required this.route,
  });

  final String label;
  final IconData icon;
  final List<Color> gradient;
  final String route;
}

/// The 6-tile quick-launch grid on Home (AI Practice, Vocabulary,
/// Grammar, Listening, Writing, Roleplay) — matches the gradient icon
/// tile style from the product reference design.
class QuickActionGrid extends StatelessWidget {
  const QuickActionGrid({super.key});

  static const _actions = [
    _QuickAction(
      label: 'AI Practice',
      icon: LucideIcons.mic,
      gradient: [Color(0xFF2563EB), Color(0xFF60A5FA)],
      route: RoutePaths.aiPractice,
    ),
    _QuickAction(
      label: 'Vocabulary',
      icon: LucideIcons.bookOpen,
      gradient: [Color(0xFF16A34A), Color(0xFF4ADE80)],
      route: RoutePaths.vocabulary,
    ),
    _QuickAction(
      label: 'Grammar',
      icon: LucideIcons.spellCheck,
      gradient: [Color(0xFF9333EA), Color(0xFFC084FC)],
      route: RoutePaths.grammar,
    ),
    _QuickAction(
      label: 'Listening',
      icon: LucideIcons.headphones,
      gradient: [Color(0xFFEA580C), Color(0xFFFB923C)],
      route: RoutePaths.listening,
    ),
    _QuickAction(
      label: 'Writing',
      icon: LucideIcons.penLine,
      gradient: [Color(0xFFDB2777), Color(0xFFF472B6)],
      route: RoutePaths.writing,
    ),
    _QuickAction(
      label: 'Roleplay',
      icon: LucideIcons.users,
      gradient: [Color(0xFF0891B2), Color(0xFF67E8F9)],
      // Roleplay scenarios live under Interview Skills for now — a
      // dedicated free-form roleplay route can split off from this
      // once that flow is designed in Sprint 5.
      route: RoutePaths.interviewPrep,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _actions.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: AppSpacing.sm,
        crossAxisSpacing: AppSpacing.sm,
        childAspectRatio: 0.85,
      ),
      itemBuilder: (context, index) {
        final action = _actions[index];
        return _QuickActionTile(action: action);
      },
    );
  }
}

class _QuickActionTile extends StatelessWidget {
  const _QuickActionTile({required this.action});

  final _QuickAction action;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: AppRadius.lgAll,
      onTap: () => context.push(action.route),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: action.gradient,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: AppRadius.mdAll,
            ),
            child: Icon(action.icon, color: Colors.white, size: 24),
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            action.label,
            style: Theme.of(context).textTheme.labelSmall,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

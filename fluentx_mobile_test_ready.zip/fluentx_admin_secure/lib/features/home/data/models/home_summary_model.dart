import '../../domain/entities/home_summary.dart';

/// Maps a `user_home_stats` Supabase row into the domain [HomeSummary].
///
/// [greetingName] comes from the auth user's profile (not this table —
/// see datasource), so it's passed in separately rather than stored
/// twice.
extension HomeSummaryMapper on Map<String, dynamic> {
  HomeSummary toHomeSummary({required String greetingName}) {
    final continueTitle = this['continue_title'] as String?;

    return HomeSummary(
      greetingName: greetingName,
      streakDays: (this['streak_days'] as num?)?.toInt() ?? 0,
      xpEarned: (this['xp_earned'] as num?)?.toInt() ?? 0,
      dailyGoalTargetMinutes: (this['daily_goal_target_minutes'] as num?)?.toInt() ?? 10,
      dailyGoalProgressMinutes: (this['daily_goal_progress_minutes'] as num?)?.toInt() ?? 0,
      continueLearning: (continueTitle == null || continueTitle.isEmpty)
          ? null
          : ContinueLearningItem(
              title: continueTitle,
              levelLabel: this['continue_level_label'] as String? ?? '',
              progressPercent:
                  ((this['continue_progress_percent'] as num?)?.toDouble() ?? 0) / 100,
            ),
    );
  }
}

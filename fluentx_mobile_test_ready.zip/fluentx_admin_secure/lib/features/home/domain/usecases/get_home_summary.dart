import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/home_summary.dart';
import '../repositories/home_repository.dart';

class GetHomeSummary {
  const GetHomeSummary(this._repository);

  final HomeRepository _repository;

  Future<Either<Failure, HomeSummary>> call(String userId) {
    return _repository.getHomeSummary(userId);
  }
}

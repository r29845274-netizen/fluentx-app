import 'package:freezed_annotation/freezed_annotation.dart';

part 'home_summary.freezed.dart';

/// Everything the Home screen needs to render — greeting, streak/XP
/// stats, daily goal progress, and the "continue learning" prompt.
///
/// Deliberately one aggregate entity (rather than 4 separate providers)
/// because these values are fetched together in a single Supabase
/// query and always render together — splitting them would just add
/// provider-wiring overhead with no real benefit.
@freezed
class HomeSummary with _$HomeSummary {
  const factory HomeSummary({
    required String greetingName,
    required int streakDays,
    required int xpEarned,
    required int dailyGoalTargetMinutes,
    required int dailyGoalProgressMinutes,
    ContinueLearningItem? continueLearning,
  }) = _HomeSummary;

  const HomeSummary._();

  double get dailyGoalProgress => dailyGoalTargetMinutes == 0
      ? 0
      : (dailyGoalProgressMinutes / dailyGoalTargetMinutes).clamp(0, 1);
}

/// The "pick up where you left off" module shown on Home. Nullable on
/// [HomeSummary] since a brand-new user has nothing to continue yet.
@freezed
class ContinueLearningItem with _$ContinueLearningItem {
  const factory ContinueLearningItem({
    required String title,
    required String levelLabel,

    /// 0.0–1.0
    required double progressPercent,
  }) = _ContinueLearningItem;
}

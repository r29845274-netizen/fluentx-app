import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/home_summary.dart';

abstract class HomeRepository {
  /// Fetches (and lazily creates, on a brand-new account) the
  /// signed-in user's home summary row.
  Future<Either<Failure, HomeSummary>> getHomeSummary(String userId);
}

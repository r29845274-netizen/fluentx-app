import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../../../routes/route_paths.dart';
import '../../../../shared/widgets/widgets.dart';

class _LearnModule {
  const _LearnModule({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.route,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final String route;
}

/// Six learning modules matching the reference Learn screen.
class LearnHubScreen extends StatelessWidget {
  const LearnHubScreen({super.key});

  static const _modules = [
    _LearnModule(
      title: 'Vocabulary',
      subtitle: '10,000+ words',
      icon: LucideIcons.bookOpen,
      color: Color(0xFFF59E0B),
      route: RoutePaths.vocabulary,
    ),
    _LearnModule(
      title: 'Grammar',
      subtitle: '100+ lessons',
      icon: LucideIcons.spellCheck,
      color: Color(0xFF10B981),
      route: RoutePaths.grammar,
    ),
    _LearnModule(
      title: 'Listening',
      subtitle: 'Real-life audio',
      icon: LucideIcons.headphones,
      color: Color(0xFF2563EB),
      route: RoutePaths.listening,
    ),
    _LearnModule(
      title: 'Writing',
      subtitle: 'AI writing coach',
      icon: LucideIcons.penLine,
      color: Color(0xFF0EA5E9),
      route: RoutePaths.writing,
    ),
    _LearnModule(
      title: 'Idioms & Phrases',
      subtitle: 'Speak like a native',
      icon: LucideIcons.messageCircle,
      color: Color(0xFFA855F7),
      route: RoutePaths.idiomsPhrases,
    ),
    _LearnModule(
      title: 'Business English',
      subtitle: 'Workplace communication',
      icon: LucideIcons.briefcase,
      color: Color(0xFF8B5CF6),
      route: RoutePaths.businessEnglish,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Learn')),
      body: SafeArea(
        top: false,
        child: ListView.separated(
          padding: const EdgeInsets.all(AppSpacing.base),
          itemCount: _modules.length,
          separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.md),
          itemBuilder: (context, index) {
            final module = _modules[index];
            return AppCard(
              onTap: () => context.push(module.route),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: module.color.withValues(alpha: 0.12),
                      borderRadius: AppRadius.mdAll,
                    ),
                    child: Icon(module.icon, color: module.color, size: 22),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          module.title,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                        ),
                        const SizedBox(height: 2),
                        Text(module.subtitle, style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                  Icon(
                    LucideIcons.chevronRight,
                    size: 20,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

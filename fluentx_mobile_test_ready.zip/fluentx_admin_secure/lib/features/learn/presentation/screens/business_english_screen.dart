import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_spacing.dart';
import '../../../../shared/widgets/widgets.dart';

class BusinessEnglishScreen extends StatelessWidget {
  const BusinessEnglishScreen({super.key});

  static const _lessons = [
    ('Meetings', 'Open, contribute and close meetings confidently.', ['Let’s get started.', 'I’d like to add one point.', 'To summarize, our next step is…']),
    ('Presentations', 'Use clear transitions and professional delivery.', ['Today I’ll cover three points.', 'Let’s move to the next section.', 'I’m happy to take questions.']),
    ('Email & Chat', 'Write concise, polite workplace messages.', ['Could you please confirm…', 'Just following up on…', 'Thanks for the quick update.']),
    ('Negotiation', 'Disagree, clarify and negotiate professionally.', ['I understand your position.', 'Could we explore another option?', 'That works for us if…']),
    ('Client Calls', 'Handle introductions, updates and objections.', ['Thanks for joining the call.', 'Here’s the current status.', 'Let me clarify that point.']),
    ('Networking', 'Introduce yourself and continue conversations naturally.', ['What kind of work do you do?', 'That sounds interesting.', 'It was great speaking with you.']),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Business English')),
      body: ListView.separated(
        padding: const EdgeInsets.all(AppSpacing.base),
        itemCount: _lessons.length,
        separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
        itemBuilder: (context, index) {
          final lesson = _lessons[index];
          return AppCard(
            child: ExpansionTile(
              tilePadding: EdgeInsets.zero,
              childrenPadding: const EdgeInsets.only(top: AppSpacing.sm),
              leading: Icon(LucideIcons.briefcase, color: Theme.of(context).colorScheme.primary),
              title: Text(lesson.$1, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600)),
              subtitle: Text(lesson.$2),
              children: [
                for (final line in lesson.$3)
                  Padding(
                    padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(LucideIcons.checkCircle2, size: 16),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(child: Text(line)),
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

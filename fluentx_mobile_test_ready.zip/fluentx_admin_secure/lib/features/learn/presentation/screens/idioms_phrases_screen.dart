import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_spacing.dart';
import '../../../../shared/widgets/widgets.dart';

class IdiomsPhrasesScreen extends StatelessWidget {
  const IdiomsPhrasesScreen({super.key});

  static const _items = [
    ('Break the ice', 'Start a friendly conversation in an awkward or new situation.', 'I asked about the event to break the ice.'),
    ('On the same page', 'Share the same understanding or goal.', 'Let’s confirm the plan so we are on the same page.'),
    ('Call it a day', 'Stop working on something for now.', 'We finished the report, so let’s call it a day.'),
    ('Get the ball rolling', 'Start an activity or process.', 'I’ll send the first draft to get the ball rolling.'),
    ('Hit the nail on the head', 'Describe the exact problem or answer.', 'Your feedback hit the nail on the head.'),
    ('Think outside the box', 'Use a creative or unusual approach.', 'We need to think outside the box for this campaign.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Idioms & Phrases')),
      body: ListView.separated(
        padding: const EdgeInsets.all(AppSpacing.base),
        itemCount: _items.length,
        separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
        itemBuilder: (context, index) {
          final item = _items[index];
          return AppCard(
            child: ExpansionTile(
              tilePadding: EdgeInsets.zero,
              childrenPadding: const EdgeInsets.only(top: AppSpacing.sm),
              leading: Icon(LucideIcons.messageCircle, color: Theme.of(context).colorScheme.primary),
              title: Text(item.$1, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600)),
              subtitle: const Text('Tap for meaning & example'),
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(item.$2),
                ),
                const SizedBox(height: AppSpacing.sm),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Example: ${item.$3}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/communication_dna.dart';
import '../repositories/communication_dna_repository.dart';

class GetCommunicationDna {
  const GetCommunicationDna(this._repository);
  final CommunicationDnaRepository _repository;

  Future<Either<Failure, CommunicationDna>> call(String userId) => _repository.getDna(userId);
}

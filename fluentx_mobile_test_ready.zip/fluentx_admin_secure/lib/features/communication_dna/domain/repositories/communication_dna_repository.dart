import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/communication_dna.dart';

abstract class CommunicationDnaRepository {
  Future<Either<Failure, CommunicationDna>> getDna(String userId);
}

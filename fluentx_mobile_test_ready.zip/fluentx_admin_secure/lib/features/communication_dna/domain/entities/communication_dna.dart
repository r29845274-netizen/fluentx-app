import 'package:freezed_annotation/freezed_annotation.dart';

part 'communication_dna.freezed.dart';

/// The 5 weighted components (Fluency 25%, Vocabulary 20%, Grammar 20%,
/// Pronunciation 20%, Confidence 15%) computed server-side by the
/// `get_communication_dna` Postgres function — see that migration's
/// comment block for the v1 heuristics behind each score.
@freezed
class CommunicationDna with _$CommunicationDna {
  const factory CommunicationDna({
    required int fluencyScore,
    required int vocabularyScore,
    required int grammarScore,
    required int pronunciationScore,
    required int confidenceScore,
    required int overallScore,
  }) = _CommunicationDna;

  const CommunicationDna._();

  String get levelLabel {
    if (overallScore >= 80) return 'Advanced';
    if (overallScore >= 50) return 'Intermediate';
    return 'Beginner';
  }

  Map<String, int> get componentsByLabel => {
        'Fluency': fluencyScore,
        'Vocabulary': vocabularyScore,
        'Grammar': grammarScore,
        'Pronunciation': pronunciationScore,
        'Confidence': confidenceScore,
      };

  List<MapEntry<String, int>> get _sortedComponents =>
      componentsByLabel.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

  List<String> get strengths => _sortedComponents.take(2).map((e) => e.key).toList();

  List<String> get focusAreas =>
      _sortedComponents.reversed.take(2).map((e) => e.key).toList();
}

import '../../domain/entities/communication_dna.dart';

extension CommunicationDnaMapper on Map<String, dynamic> {
  CommunicationDna toCommunicationDna() {
    return CommunicationDna(
      fluencyScore: (this['fluency_score'] as num).toInt(),
      vocabularyScore: (this['vocabulary_score'] as num).toInt(),
      grammarScore: (this['grammar_score'] as num).toInt(),
      pronunciationScore: (this['pronunciation_score'] as num).toInt(),
      confidenceScore: (this['confidence_score'] as num).toInt(),
      overallScore: (this['overall_score'] as num).toInt(),
    );
  }
}

import 'package:fpdart/fpdart.dart';

import '../../../../core/error/exceptions.dart';
import '../../../../core/error/failures.dart';
import '../../domain/entities/communication_dna.dart';
import '../../domain/repositories/communication_dna_repository.dart';
import '../datasources/communication_dna_remote_datasource.dart';

class CommunicationDnaRepositoryImpl implements CommunicationDnaRepository {
  CommunicationDnaRepositoryImpl(this._remoteDataSource);
  final CommunicationDnaRemoteDataSource _remoteDataSource;

  @override
  Future<Either<Failure, CommunicationDna>> getDna(String userId) async {
    try {
      return right(await _remoteDataSource.getDna(userId));
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }
}

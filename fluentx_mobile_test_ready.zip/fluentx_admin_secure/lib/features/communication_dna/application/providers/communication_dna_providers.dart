import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/supabase_provider.dart';
import '../../../authentication/application/providers/auth_providers.dart';
import '../../data/datasources/communication_dna_remote_datasource.dart';
import '../../data/repositories/communication_dna_repository_impl.dart';
import '../../domain/entities/communication_dna.dart';
import '../../domain/repositories/communication_dna_repository.dart';
import '../../domain/usecases/get_communication_dna.dart';

final communicationDnaRemoteDataSourceProvider =
    Provider<CommunicationDnaRemoteDataSource>((ref) {
  return CommunicationDnaRemoteDataSourceImpl(ref.watch(supabaseClientProvider));
});

final communicationDnaRepositoryProvider = Provider<CommunicationDnaRepository>((ref) {
  return CommunicationDnaRepositoryImpl(ref.watch(communicationDnaRemoteDataSourceProvider));
});

final getCommunicationDnaUseCaseProvider = Provider<GetCommunicationDna>((ref) {
  return GetCommunicationDna(ref.watch(communicationDnaRepositoryProvider));
});

final communicationDnaProvider = FutureProvider.autoDispose<CommunicationDna>((ref) async {
  final user = ref.watch(authStateChangesProvider).value;
  if (user == null) throw StateError('communicationDnaProvider read while signed out');

  final result = await ref.watch(getCommunicationDnaUseCaseProvider).call(user.id);
  return result.match((failure) => throw failure, (dna) => dna);
});

import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_spacing.dart';
import '../../domain/level_progress.dart';

/// Avatar + name + level/XP header at the top of Profile.
class ProfileHeader extends StatelessWidget {
  const ProfileHeader({
    required this.fullName,
    required this.email,
    required this.levelProgress,
    required this.isPremium,
    super.key,
    this.avatarUrl,
  });

  final String fullName;
  final String email;
  final String? avatarUrl;
  final LevelProgress levelProgress;
  final bool isPremium;

  String get _initials {
    final parts = fullName.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts.first.substring(0, 1) + parts.last.substring(0, 1)).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Column(
      children: [
        Stack(
          children: [
            CircleAvatar(
              radius: 44,
              backgroundColor: colorScheme.primary.withValues(alpha: 0.12),
              backgroundImage: avatarUrl != null ? NetworkImage(avatarUrl!) : null,
              child: avatarUrl == null
                  ? Text(
                      _initials,
                      style: textTheme.headlineMedium?.copyWith(color: colorScheme.primary),
                    )
                  : null,
            ),
            if (isPremium)
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD97706),
                    shape: BoxShape.circle,
                    border: Border.all(color: colorScheme.surface, width: 2),
                  ),
                  child: const Icon(LucideIcons.crown, size: 14, color: Colors.white),
                ),
              ),
          ],
        ),
        const SizedBox(height: AppSpacing.md),
        Text(fullName, style: textTheme.headlineSmall),
        const SizedBox(height: 2),
        Text(
          email,
          style: textTheme.bodySmall?.copyWith(color: colorScheme.onSurfaceVariant),
        ),
        if (isPremium) ...[
          const SizedBox(height: AppSpacing.xs),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: 2),
            decoration: BoxDecoration(
              color: const Color(0xFFD97706).withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(100),
            ),
            child: Text(
              'Premium Member',
              style: textTheme.labelSmall?.copyWith(
                color: const Color(0xFFD97706),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
        const SizedBox(height: AppSpacing.base),
        Row(
          children: [
            Text('Level ${levelProgress.level}', style: textTheme.bodySmall),
            const Spacer(),
            Text(
              '${levelProgress.currentLevelXp} / ${levelProgress.xpForNextLevel} XP',
              style: textTheme.bodySmall,
            ),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(100),
          child: LinearProgressIndicator(
            value: levelProgress.progress,
            minHeight: 6,
            backgroundColor: colorScheme.outline,
            valueColor: AlwaysStoppedAnimation<Color>(colorScheme.primary),
          ),
        ),
      ],
    );
  }
}

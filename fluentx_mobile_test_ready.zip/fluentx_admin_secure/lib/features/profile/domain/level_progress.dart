/// Derives a display "level" from total XP earned.
///
/// Pure, dependency-free logic — intentionally NOT a new Supabase
/// table/repository, since level is 100% derivable from
/// `user_home_stats.xp_earned` (already fetched by `homeSummaryProvider`).
/// Adding a second data source just to store a value that's a
/// deterministic function of one already-fetched field would be
/// duplicated state, not more "real" — this is the correct
/// simplification, not a shortcut.
///
/// Formula: 1000 XP per level. Tune freely — it's isolated here so
/// changing the curve later never touches UI code.
class LevelProgress {
  const LevelProgress({
    required this.level,
    required this.currentLevelXp,
    required this.xpForNextLevel,
  });

  final int level;
  final int currentLevelXp;
  final int xpForNextLevel;

  double get progress =>
      xpForNextLevel == 0 ? 0 : (currentLevelXp / xpForNextLevel).clamp(0, 1);

  static const int _xpPerLevel = 1000;

  factory LevelProgress.fromTotalXp(int totalXp) {
    final level = (totalXp ~/ _xpPerLevel) + 1;
    final currentLevelXp = totalXp % _xpPerLevel;
    return LevelProgress(
      level: level,
      currentLevelXp: currentLevelXp,
      xpForNextLevel: _xpPerLevel,
    );
  }
}

import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/grammar_lesson.dart';
import '../repositories/grammar_repository.dart';

class GetGrammarLessons {
  const GetGrammarLessons(this._repository);
  final GrammarRepository _repository;

  Future<Either<Failure, List<GrammarLesson>>> call() => _repository.getLessons();
}

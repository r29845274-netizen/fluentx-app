import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/grammar_lesson.dart';
import '../repositories/grammar_repository.dart';

class GetGrammarQuestions {
  const GetGrammarQuestions(this._repository);
  final GrammarRepository _repository;

  Future<Either<Failure, List<GrammarQuestion>>> call(String lessonId) {
    return _repository.getQuestions(lessonId);
  }
}

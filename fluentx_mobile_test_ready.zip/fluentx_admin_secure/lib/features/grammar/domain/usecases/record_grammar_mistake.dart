import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../repositories/grammar_repository.dart';

class RecordGrammarMistake {
  const RecordGrammarMistake(this._repository);
  final GrammarRepository _repository;

  Future<Either<Failure, Unit>> call({required String userId, required String category}) {
    return _repository.recordMistake(userId: userId, category: category);
  }
}

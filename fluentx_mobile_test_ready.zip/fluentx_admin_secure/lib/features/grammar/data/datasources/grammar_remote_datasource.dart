import 'package:supabase_flutter/supabase_flutter.dart' as supabase;

import '../../../../core/error/exceptions.dart';
import '../../domain/entities/grammar_lesson.dart';
import '../models/grammar_lesson_model.dart';

abstract class GrammarRemoteDataSource {
  Future<List<GrammarLesson>> getLessons();
  Future<List<GrammarQuestion>> getQuestions(String lessonId);
  Future<void> recordMistake({required String userId, required String category});
}

class GrammarRemoteDataSourceImpl implements GrammarRemoteDataSource {
  GrammarRemoteDataSourceImpl(this._client);

  final supabase.SupabaseClient _client;

  @override
  Future<List<GrammarLesson>> getLessons() async {
    try {
      final rows = await _client
          .from('grammar_lessons')
          .select()
          .order('order_index');
      return (rows as List)
          .map((row) => (row as Map<String, dynamic>).toGrammarLesson())
          .toList();
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<List<GrammarQuestion>> getQuestions(String lessonId) async {
    try {
      final rows = await _client
          .from('grammar_questions')
          .select()
          .eq('lesson_id', lessonId);
      return (rows as List)
          .map((row) => (row as Map<String, dynamic>).toGrammarQuestion())
          .toList();
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<void> recordMistake({required String userId, required String category}) async {
    try {
      await _client.rpc<void>(
        'increment_grammar_mistake',
        params: {'p_user_id': userId, 'p_category': category},
      );
    } on supabase.PostgrestException catch (e) {
      throw ServerException(e.message);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }
}

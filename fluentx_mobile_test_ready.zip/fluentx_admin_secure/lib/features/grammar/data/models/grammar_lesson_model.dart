import '../../domain/entities/grammar_lesson.dart';

extension GrammarLessonMapper on Map<String, dynamic> {
  GrammarLesson toGrammarLesson() {
    return GrammarLesson(
      id: this['id'] as String,
      title: this['title'] as String,
      explanation: this['explanation'] as String,
      category: this['category'] as String,
    );
  }

  GrammarQuestion toGrammarQuestion() {
    return GrammarQuestion(
      id: this['id'] as String,
      lessonId: this['lesson_id'] as String,
      questionText: this['question_text'] as String,
      options: List<String>.from(this['options'] as List),
      correctIndex: (this['correct_index'] as num).toInt(),
    );
  }
}

import 'package:fpdart/fpdart.dart';

import '../../../../core/error/exceptions.dart';
import '../../../../core/error/failures.dart';
import '../../domain/entities/grammar_lesson.dart';
import '../../domain/repositories/grammar_repository.dart';
import '../datasources/grammar_remote_datasource.dart';

class GrammarRepositoryImpl implements GrammarRepository {
  GrammarRepositoryImpl(this._remoteDataSource);

  final GrammarRemoteDataSource _remoteDataSource;

  @override
  Future<Either<Failure, List<GrammarLesson>>> getLessons() async {
    try {
      return right(await _remoteDataSource.getLessons());
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }

  @override
  Future<Either<Failure, List<GrammarQuestion>>> getQuestions(String lessonId) async {
    try {
      return right(await _remoteDataSource.getQuestions(lessonId));
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }

  @override
  Future<Either<Failure, Unit>> recordMistake({
    required String userId,
    required String category,
  }) async {
    try {
      await _remoteDataSource.recordMistake(userId: userId, category: category);
      return right(unit);
    } on ServerException catch (e) {
      return left(Failure.server(message: e.message));
    } catch (e) {
      return left(const Failure.unexpected());
    }
  }
}

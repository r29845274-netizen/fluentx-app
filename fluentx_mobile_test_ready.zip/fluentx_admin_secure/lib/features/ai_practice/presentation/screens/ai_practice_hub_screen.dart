import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../../../shared/widgets/widgets.dart';
import '../../application/providers/ai_practice_providers.dart';
import '../../domain/entities/practice_scenario.dart';
import '../widgets/chat_bubble.dart';
import '../widgets/practice_mic_button.dart';
import '../widgets/practice_summary_view.dart';

class AiPracticeHubScreen extends ConsumerStatefulWidget {
  const AiPracticeHubScreen({super.key});

  @override
  ConsumerState<AiPracticeHubScreen> createState() => _AiPracticeHubScreenState();
}

class _AiPracticeHubScreenState extends ConsumerState<AiPracticeHubScreen> {
  PracticeScenario? _activeScenario;
  final _scrollController = ScrollController();

  Future<void> _startScenario(PracticeScenario scenario) async {
    setState(() => _activeScenario = scenario);
    await ref.read(aiPracticeSessionControllerProvider.notifier).startSession(scenario.id);
  }

  void _exitToList() {
    ref.read(aiPracticeSessionControllerProvider.notifier).reset();
    setState(() => _activeScenario = null);
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final sessionState = ref.watch(aiPracticeSessionControllerProvider);

    if (_activeScenario != null && sessionState.summary != null) {
      return Scaffold(
        body: PracticeSummaryView(
          summary: sessionState.summary!,
          onDone: _exitToList,
        ),
      );
    }

    if (_activeScenario != null) {
      ref.listen(aiPracticeSessionControllerProvider, (previous, next) {
        if (next.messages.length != previous?.messages.length) _scrollToBottom();
      });

      return Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(LucideIcons.x),
            onPressed: _exitToList,
          ),
          title: Text(_activeScenario!.title),
          actions: [
            TextButton(
              onPressed: sessionState.sessionId == null || sessionState.messages.isEmpty
                  ? null
                  : () => ref.read(aiPracticeSessionControllerProvider.notifier).endSession(),
              child: const Text('End Session'),
            ),
          ],
        ),
        body: SafeArea(
          top: false,
          child: Column(
            children: [
              Expanded(
                child: sessionState.messages.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(AppSpacing.xl),
                          child: Text(
                            'Tap the mic and start speaking — ${_activeScenario!.description}',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                                ),
                          ),
                        ),
                      )
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.all(AppSpacing.base),
                        itemCount: sessionState.messages.length,
                        itemBuilder: (context, index) =>
                            ChatBubble(message: sessionState.messages[index]),
                      ),
              ),
              if (sessionState.error != null)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.base),
                  child: Text(
                    sessionState.error!.uiMessage,
                    style: TextStyle(color: Theme.of(context).colorScheme.error),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.all(AppSpacing.base),
                child: sessionState.isSending
                    ? const LoadingWidget(message: 'AI coach is thinking…')
                    : PracticeMicButton(
                        enabled: sessionState.sessionId != null,
                        onResult: (text) => ref
                            .read(aiPracticeSessionControllerProvider.notifier)
                            .sendUserMessage(text),
                      ),
              ),
            ],
          ),
        ),
      );
    }

    // ---- Scenario list ----
    final scenariosAsync = ref.watch(practiceScenariosProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('AI Practice')),
      body: SafeArea(
        top: false,
        child: scenariosAsync.when(
          data: (scenarios) {
            if (scenarios.isEmpty) {
              return const EmptyStateWidget(title: 'No scenarios available yet');
            }
            return ListView.separated(
              padding: const EdgeInsets.all(AppSpacing.base),
              itemCount: scenarios.length,
              separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.md),
              itemBuilder: (context, index) {
                final scenario = scenarios[index];
                return AppCard(
                  onTap: () => _startScenario(scenario),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
                          borderRadius: AppRadius.mdAll,
                        ),
                        child: Icon(
                          LucideIcons.mic,
                          color: Theme.of(context).colorScheme.primary,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: AppSpacing.md),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              scenario.title,
                              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                            const SizedBox(height: 2),
                            Text(scenario.description, style: Theme.of(context).textTheme.bodySmall),
                          ],
                        ),
                      ),
                      Icon(
                        LucideIcons.chevronRight,
                        size: 20,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ],
                  ),
                );
              },
            );
          },
          loading: () => const LoadingWidget(),
          error: (_, __) => ErrorStateWidget(
            onRetry: () => ref.invalidate(practiceScenariosProvider),
          ),
        ),
      ),
    );
  }
}

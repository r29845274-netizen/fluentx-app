import 'package:flutter/material.dart';

import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../domain/entities/practice_scenario.dart';

class ChatBubble extends StatelessWidget {
  const ChatBubble({required this.message, super.key});

  final PracticeMessage message;

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == PracticeMessageRole.user;
    final colorScheme = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md,
            vertical: AppSpacing.sm,
          ),
          decoration: BoxDecoration(
            color: isUser ? colorScheme.primary : colorScheme.surfaceContainerHighest,
            borderRadius: AppRadius.mdAll,
          ),
          child: Text(
            message.text,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: isUser ? colorScheme.onPrimary : colorScheme.onSurface,
                ),
          ),
        ),
        if (message.correction != null) ...[
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xs),
            child: Text(
              '💡 ${message.correction}',
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: const Color(0xFFD97706),
                    fontStyle: FontStyle.italic,
                  ),
            ),
          ),
        ],
        const SizedBox(height: AppSpacing.sm),
      ],
    );
  }
}

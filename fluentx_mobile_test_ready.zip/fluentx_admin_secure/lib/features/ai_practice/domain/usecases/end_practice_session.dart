import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/practice_scenario.dart';
import '../repositories/ai_practice_repository.dart';

class EndPracticeSession {
  const EndPracticeSession(this._repository);
  final AiPracticeRepository _repository;

  Future<Either<Failure, PracticeSessionSummary>> call(String sessionId) {
    return _repository.endSession(sessionId);
  }
}

import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/practice_scenario.dart';
import '../repositories/ai_practice_repository.dart';

class GetPracticeScenarios {
  const GetPracticeScenarios(this._repository);
  final AiPracticeRepository _repository;

  Future<Either<Failure, List<PracticeScenario>>> call() => _repository.getScenarios();
}

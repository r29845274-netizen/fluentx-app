import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../repositories/ai_practice_repository.dart';

class StartPracticeSession {
  const StartPracticeSession(this._repository);
  final AiPracticeRepository _repository;

  Future<Either<Failure, String>> call({required String userId, required String scenarioId}) {
    return _repository.startSession(userId: userId, scenarioId: scenarioId);
  }
}

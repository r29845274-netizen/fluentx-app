import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/practice_scenario.dart';
import '../repositories/ai_practice_repository.dart';

class SendPracticeMessage {
  const SendPracticeMessage(this._repository);
  final AiPracticeRepository _repository;

  Future<Either<Failure, PracticeMessage>> call({
    required String sessionId,
    required String userMessage,
  }) {
    return _repository.sendMessage(sessionId: sessionId, userMessage: userMessage);
  }
}

import 'package:fpdart/fpdart.dart';

import '../../../../core/error/failures.dart';
import '../entities/practice_scenario.dart';

abstract class AiPracticeRepository {
  Future<Either<Failure, List<PracticeScenario>>> getScenarios();

  Future<Either<Failure, String>> startSession({
    required String userId,
    required String scenarioId,
  });

  /// Sends the user's transcribed speech for [sessionId] and returns
  /// the AI's reply (plus an optional inline correction).
  Future<Either<Failure, PracticeMessage>> sendMessage({
    required String sessionId,
    required String userMessage,
  });

  Future<Either<Failure, PracticeSessionSummary>> endSession(String sessionId);
}

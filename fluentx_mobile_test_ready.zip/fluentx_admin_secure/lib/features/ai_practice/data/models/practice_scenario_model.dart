import '../../domain/entities/practice_scenario.dart';

extension PracticeScenarioMapper on Map<String, dynamic> {
  PracticeScenario toPracticeScenario() {
    return PracticeScenario(
      id: this['id'] as String,
      title: this['title'] as String,
      category: this['category'] as String,
      description: this['description'] as String,
    );
  }
}

extension PracticeMessageMapper on Map<String, dynamic> {
  PracticeMessage toPracticeMessage() {
    return PracticeMessage(
      role: PracticeMessageRole.assistant,
      text: this['reply'] as String,
      correction: this['correction'] as String?,
    );
  }
}

extension PracticeSessionSummaryMapper on Map<String, dynamic> {
  PracticeSessionSummary toPracticeSessionSummary() {
    final sentences = (this['corrected_sentences'] as List? ?? [])
        .map(
          (e) => CorrectedSentence(
            original: (e as Map<String, dynamic>)['original'] as String,
            corrected: e['corrected'] as String,
          ),
        )
        .toList();

    return PracticeSessionSummary(
      accuracyScore: (this['accuracy_score'] as num?)?.toInt() ?? 0,
      fluencyNotes: this['fluency_notes'] as String? ?? '',
      correctedSentences: sentences,
    );
  }
}

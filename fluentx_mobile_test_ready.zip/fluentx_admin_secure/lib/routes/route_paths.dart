/// Centralized route path constants.
///
/// Never hardcode a path string at a call site (`context.go('/home')`)
/// — always reference these constants so renaming a route is a
/// single-file change instead of a project-wide search-and-replace.
abstract final class RoutePaths {
  const RoutePaths._();

  // ---- Pre-auth ----
  static const String splash = '/splash';
  static const String onboarding = '/onboarding';
  static const String login = '/login';
  static const String signup = '/signup';
  static const String forgotPassword = '/forgot-password';
  static const String verifyEmailOtp = '/verify-email-otp';

  // ---- Bottom nav tabs (StatefulShellRoute branches) ----
  static const String home = '/home';
  static const String aiPractice = '/practice';
  static const String learn = '/learn';
  static const String progress = '/progress';
  static const String profile = '/profile';

  // ---- Pushed on top of the shell ----
  static const String vocabulary = '/vocabulary';
  static const String grammar = '/grammar';
  static const String listening = '/listening';
  static const String writing = '/writing';
  static const String idiomsPhrases = '/idioms-phrases';
  static const String businessEnglish = '/business-english';
  static const String interviewPrep = '/interview-prep';
  static const String communicationDna = '/communication-dna';
  static const String achievements = '/achievements';
  static const String premium = '/premium';
  static const String settings = '/settings';
  static const String dailyGoals = '/daily-goals';
  static const String helpSupport = '/help-support';
  static const String editProfile = '/edit-profile';
  static const String privacyPolicy = '/privacy-policy';
  static const String termsOfService = '/terms-of-service';
  static const String adminConsole = '/admin-console';
}

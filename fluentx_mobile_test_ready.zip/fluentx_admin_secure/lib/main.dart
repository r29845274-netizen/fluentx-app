import 'dart:ui';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timezone/data/latest.dart' as tz_data;

import 'app/app.dart';
import 'core/config/env_config.dart';
import 'core/theme/theme_mode_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();
  await Hive.openBox(kSettingsBoxName);

  tz_data.initializeTimeZones();

  assert(
    EnvConfig.isConfigured,
    'SUPABASE_URL and SUPABASE_ANON_KEY must be provided via --dart-define. '
    'See lib/core/config/env_config.dart for the exact run command.',
  );

  await Supabase.initialize(
    url: EnvConfig.supabaseUrl,
    anonKey: EnvConfig.supabaseAnonKey,
    authOptions: const FlutterAuthClientOptions(authFlowType: AuthFlowType.pkce),
  );

  // Firebase: requires platform config files (google-services.json /
  // GoogleService-Info.plist) from your Firebase project — see
  // SPRINT_6_PAYMENTS_NOTIFICATIONS_README.md. Guarded so local dev
  // without those files doesn't hard-crash on startup.
  try {
    await Firebase.initializeApp();
    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
    PlatformDispatcher.instance.onError = (error, stack) {
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
      return true;
    };
  } catch (e) {
    debugPrint('Firebase initialization skipped/failed: $e');
  }

  if (EnvConfig.revenueCatApiKey.isNotEmpty) {
    await Purchases.setLogLevel(LogLevel.info);
    await Purchases.configure(PurchasesConfiguration(EnvConfig.revenueCatApiKey));
  }

  runApp(const ProviderScope(child: FluentXApp()));
}

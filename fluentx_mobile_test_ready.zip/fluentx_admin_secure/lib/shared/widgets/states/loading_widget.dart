import 'package:flutter/material.dart';

import '../../../core/constants/app_radius.dart';

/// Skeleton-loader shimmer block.
///
/// A plain [CircularProgressIndicator] reads as generic and
/// "unfinished". Shimmer skeletons that mirror the shape of the
/// content about to load feel deliberate and premium — this is a
/// lightweight, dependency-free implementation (no `shimmer` package)
/// built on a looping [AnimationController] + [ShaderMask].
class ShimmerBox extends StatefulWidget {
  const ShimmerBox({
    super.key,
    this.width = double.infinity,
    this.height = 16,
    this.borderRadius,
  });

  final double width;
  final double height;
  final BorderRadius? borderRadius;

  @override
  State<ShimmerBox> createState() => _ShimmerBoxState();
}

class _ShimmerBoxState extends State<ShimmerBox> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final baseColor = Theme.of(context).colorScheme.surfaceContainerHighest;
    final highlightColor = Theme.of(context).colorScheme.outline.withValues(alpha: 0.3);

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return ShaderMask(
          blendMode: BlendMode.srcATop,
          shaderCallback: (bounds) {
            final slide = _controller.value;
            return LinearGradient(
              colors: [baseColor, highlightColor, baseColor],
              stops: const [0.35, 0.5, 0.65],
              begin: Alignment(-1 - slide * 3, 0),
              end: Alignment(1 - slide * 3 + 1, 0),
            ).createShader(bounds);
          },
          child: Container(
            width: widget.width,
            height: widget.height,
            decoration: BoxDecoration(
              color: baseColor,
              borderRadius: widget.borderRadius ?? AppRadius.smAll,
            ),
          ),
        );
      },
    );
  }
}

/// A composed skeleton for a card-shaped loading placeholder — reused
/// across Home, Vocabulary, and Progress list loading states.
class LoadingCardSkeleton extends StatelessWidget {
  const LoadingCardSkeleton({super.key, this.lines = 2});

  final int lines;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: AppRadius.lgAll,
        border: Border.all(color: Theme.of(context).colorScheme.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const ShimmerBox(width: 120, height: 14),
          const SizedBox(height: 12),
          for (int i = 0; i < lines; i++) ...[
            ShimmerBox(width: i.isEven ? double.infinity : 200, height: 12),
            if (i != lines - 1) const SizedBox(height: 8),
          ],
        ],
      ),
    );
  }
}

/// Full-screen loading state — used for initial route/data loads where
/// no content shape exists yet to skeleton.
class LoadingWidget extends StatelessWidget {
  const LoadingWidget({super.key, this.message});

  final String? message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(strokeWidth: 3),
          if (message != null) ...[
            const SizedBox(height: 16),
            Text(message!, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../../core/constants/app_durations.dart';
import '../../../core/constants/app_radius.dart';
import '../../../core/constants/app_spacing.dart';

/// FluentX's standard content card.
///
/// Wraps [Card] (which already pulls its shape/color from
/// [CardThemeData]) and adds an optional tap ripple with a subtle
/// press-scale animation, used throughout Home, Vocabulary, Progress,
/// and Profile for consistent, tactile-feeling containers.
class AppCard extends StatefulWidget {
  const AppCard({
    required this.child,
    super.key,
    this.onTap,
    this.padding = const EdgeInsets.all(AppSpacing.base),
  });

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;

  @override
  State<AppCard> createState() => _AppCardState();
}

class _AppCardState extends State<AppCard> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (widget.onTap == null) return;
    setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    final card = Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: widget.onTap,
        onTapDown: (_) => _setPressed(true),
        onTapCancel: () => _setPressed(false),
        onTapUp: (_) => _setPressed(false),
        borderRadius: AppRadius.lgAll,
        child: Padding(
          padding: widget.padding,
          child: widget.child,
        ),
      ),
    );

    return AnimatedScale(
      scale: _pressed ? 0.98 : 1.0,
      duration: AppDurations.fast,
      curve: AppDurations.standardCurve,
      child: card,
    );
  }
}

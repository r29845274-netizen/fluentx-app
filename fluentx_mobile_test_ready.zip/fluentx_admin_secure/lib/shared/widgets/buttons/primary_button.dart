import 'package:flutter/material.dart';

import '../../../core/constants/app_spacing.dart';

/// FluentX's primary call-to-action button.
///
/// Handles its own loading state so call sites never need to wrap it in
/// a `Stack` or swap it for a spinner manually — pass [isLoading] and
/// the button disables itself and shows an inline indicator.
class PrimaryButton extends StatelessWidget {
  const PrimaryButton({
    required this.label,
    required this.onPressed,
    super.key,
    this.isLoading = false,
    this.isEnabled = true,
    this.icon,
    this.fullWidth = true,
  });

  final String label;

  /// Null [onPressed] combined with [isEnabled]=true is treated as
  /// "not ready yet" and disables the button — this avoids accidental
  /// crashes from a missing callback.
  final VoidCallback? onPressed;
  final bool isLoading;
  final bool isEnabled;
  final IconData? icon;
  final bool fullWidth;

  @override
  Widget build(BuildContext context) {
    final canPress = isEnabled && !isLoading && onPressed != null;

    final child = isLoading
        ? SizedBox(
            height: 20,
            width: 20,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              valueColor: AlwaysStoppedAnimation<Color>(
                Theme.of(context).colorScheme.onPrimary,
              ),
            ),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 20),
                const SizedBox(width: AppSpacing.sm),
              ],
              Text(label),
            ],
          );

    final button = ElevatedButton(
      onPressed: canPress ? onPressed : null,
      child: child,
    );

    return fullWidth ? SizedBox(width: double.infinity, child: button) : button;
  }
}

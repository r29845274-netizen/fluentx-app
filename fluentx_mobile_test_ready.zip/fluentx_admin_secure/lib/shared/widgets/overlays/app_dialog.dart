import 'package:flutter/material.dart';

import '../../../core/constants/app_spacing.dart';
import '../buttons/primary_button.dart';
import '../buttons/secondary_button.dart';

/// Static helpers for showing FluentX-styled dialogs.
///
/// Centralizing dialog construction here means every confirmation
/// (delete account, discard draft, end session early, etc.) looks and
/// behaves identically without each feature reimplementing
/// `showDialog` + button rows.
abstract final class AppDialog {
  const AppDialog._();

  /// Shows a two-button confirmation dialog and returns `true` if the
  /// user confirmed, `false` if dismissed/cancelled.
  static Future<bool> confirm(
    BuildContext context, {
    required String title,
    required String message,
    String confirmLabel = 'Confirm',
    String cancelLabel = 'Cancel',
    bool isDestructive = false,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        final colorScheme = Theme.of(dialogContext).colorScheme;

        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actionsPadding: const EdgeInsets.fromLTRB(
            AppSpacing.lg,
            0,
            AppSpacing.lg,
            AppSpacing.lg,
          ),
          actions: [
            Expanded(
              child: SecondaryButton(
                label: cancelLabel,
                onPressed: () => Navigator.of(dialogContext).pop(false),
              ),
            ),
            const SizedBox(width: AppSpacing.sm),
            Expanded(
              child: isDestructive
                  ? ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: colorScheme.error,
                        foregroundColor: colorScheme.onError,
                      ),
                      onPressed: () => Navigator.of(dialogContext).pop(true),
                      child: Text(confirmLabel),
                    )
                  : PrimaryButton(
                      label: confirmLabel,
                      onPressed: () => Navigator.of(dialogContext).pop(true),
                    ),
            ),
          ],
        );
      },
    );

    return result ?? false;
  }

  /// Shows a single-button informational dialog (e.g. error explanation,
  /// success confirmation with no further action needed).
  static Future<void> info(
    BuildContext context, {
    required String title,
    required String message,
    String buttonLabel = 'Got it',
  }) {
    return showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actionsPadding: const EdgeInsets.fromLTRB(
            AppSpacing.lg,
            0,
            AppSpacing.lg,
            AppSpacing.lg,
          ),
          actions: [
            SizedBox(
              width: double.infinity,
              child: PrimaryButton(
                label: buttonLabel,
                onPressed: () => Navigator.of(dialogContext).pop(),
              ),
            ),
          ],
        );
      },
    );
  }
}

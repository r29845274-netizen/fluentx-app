import 'package:flutter/material.dart';

import '../../../core/constants/app_spacing.dart';

/// Static helper for showing FluentX-styled bottom sheets.
///
/// Wraps [showModalBottomSheet] with the app's standard shape (already
/// set globally via [BottomSheetThemeData]), safe-area handling, and
/// keyboard-avoidance so every sheet — filter pickers, session
/// summaries, action menus — behaves consistently.
abstract final class AppBottomSheet {
  const AppBottomSheet._();

  static Future<T?> show<T>(
    BuildContext context, {
    required Widget child,
    String? title,
    bool isScrollControlled = true,
  }) {
    return showModalBottomSheet<T>(
      context: context,
      isScrollControlled: isScrollControlled,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: EdgeInsets.only(
              left: AppSpacing.base,
              right: AppSpacing.base,
              top: AppSpacing.lg,
              bottom: MediaQuery.of(sheetContext).viewInsets.bottom + AppSpacing.base,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (title != null) ...[
                  Text(title, style: Theme.of(sheetContext).textTheme.headlineSmall),
                  const SizedBox(height: AppSpacing.base),
                ],
                child,
              ],
            ),
          ),
        );
      },
    );
  }
}

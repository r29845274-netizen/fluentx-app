import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';

import 'app_bottom_nav_bar.dart';

/// Wraps GoRouter's [StatefulNavigationShell] with FluentX's bottom
/// navigation bar.
///
/// Using `goBranch` (rather than `go`) preserves each tab's own
/// navigation stack and scroll position when switching tabs — e.g.
/// drilling into a vocabulary deck, switching to Profile, then back to
/// AI Practice returns you to where you left off instead of resetting
/// to that tab's root.
class AppShell extends StatelessWidget {
  const AppShell({required this.navigationShell, super.key});

  final StatefulNavigationShell navigationShell;

  static const _items = [
    AppNavItem(icon: LucideIcons.home, activeIcon: LucideIcons.home, label: 'Home'),
    AppNavItem(icon: LucideIcons.mic, activeIcon: LucideIcons.mic, label: 'Practice'),
    AppNavItem(icon: LucideIcons.bookOpen, activeIcon: LucideIcons.bookOpen, label: 'Learn'),
    AppNavItem(
      icon: LucideIcons.barChart2,
      activeIcon: LucideIcons.barChart2,
      label: 'Progress',
    ),
    AppNavItem(icon: LucideIcons.user, activeIcon: LucideIcons.user, label: 'Profile'),
  ];

  void _onTap(int index) {
    navigationShell.goBranch(
      index,
      // Tapping the already-active tab pops it back to its root.
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: AppBottomNavBar(
        items: _items,
        currentIndex: navigationShell.currentIndex,
        onTap: _onTap,
      ),
    );
  }
}

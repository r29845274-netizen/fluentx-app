# FluentX — deployment-ready handoff

## Reference gaps closed
- Fixed the broken Communication DNA radar-chart import.
- Added the missing Flutter router import required by `GlobalKey<NavigatorState>`.
- Added the missing social-login icon assets and declared asset directories now exist.
- Learn now contains all six reference modules: Vocabulary, Grammar, Listening, Writing, Idioms & Phrases, Business English.
- Interview/Roleplay is now an interactive practice flow instead of a placeholder.
- Progress now shows the Communication DNA overall score plus individual skill bars and Achievements.
- Daily Goals and Help & Support now open real screens.
- Settings now has working profile editing, notification control, language selection, local Privacy/Terms screens, and real account-deletion wiring.
- Added an authenticated `delete-account` Supabase Edge Function.
- Hardened AI Practice and Writing Edge Functions so a caller can only access their own session/submission.
- Added Android bootstrap automation so the previously missing `android/` project is created and patched consistently in CI.
- Added a source preflight check to Codemagic before analyze/test/build.

## Local/CI build
```bash
bash scripts/bootstrap_android.sh
flutter pub get
dart run build_runner build --delete-conflicting-outputs
python3 scripts/preflight_check.py
flutter analyze
flutter test
flutter build appbundle --release \
  --dart-define=SUPABASE_URL="$SUPABASE_URL" \
  --dart-define=SUPABASE_ANON_KEY="$SUPABASE_ANON_KEY" \
  --dart-define=REVENUECAT_API_KEY="$REVENUECAT_API_KEY" \
  --dart-define=FLAVOR=prod
```

## Backend deployment
Apply Supabase migrations in numeric order, then deploy:
```bash
supabase functions deploy ai-practice-chat
supabase functions deploy score-writing
supabase functions deploy delete-account
supabase secrets set OPENAI_API_KEY="<server-side OpenAI API key>"
```

## Codemagic secrets expected
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `REVENUECAT_API_KEY` (optional if premium is disabled)
- Android signing config named `fluentx_keystore`
- `GCLOUD_SERVICE_ACCOUNT_CREDENTIALS` for Google Play internal publishing

The source preflight passes in this handoff. A full Flutter compile was not run in the handoff container because the Flutter/Dart SDK is not installed there; Codemagic is configured to run codegen, analyze, tests, build and publish.

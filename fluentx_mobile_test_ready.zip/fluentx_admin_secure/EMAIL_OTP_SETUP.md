# FluentX Email OTP setup (required once in Supabase)

The Flutter app now contains the complete OTP request / verify / resend flow for email login and email signup.

To make Gmail/email receive a **6-digit code** instead of a clickable magic link, configure the Supabase project once:

1. Supabase Dashboard -> Authentication -> Sign In / Providers -> Email
   - Email provider: ON
   - Confirm email: ON (required for signup verification)
2. Authentication -> Email Templates
   - **Confirm signup** template must contain `{{ .Token }}`
   - **Magic Link / OTP** template must contain `{{ .Token }}`
   Example body: `<h2>Your FluentX verification code</h2><p>Enter this code in the app: <strong>{{ .Token }}</strong></p>`
3. Keep the default 60-second resend rate limit or set the app cooldown to match your project setting.
4. Configure production SMTP in Supabase for reliable delivery before Play Store release.

Google OAuth remains available as before.

# FluentX — Sprint 2, Part 1: Home Screen + 5-Tab Navigation Update

## Navigation change (from Sprint 1 Part 3)

Bottom nav is now **5 tabs**, matching the reference design:
`Home → Practice → Learn → Progress → Profile`

Files touched:
```
lib/routes/route_paths.dart                  (added RoutePaths.learn, aiPractice path → /practice)
lib/routes/app_router.dart                    (added Learn StatefulShellBranch)
lib/shared/widgets/navigation/app_shell.dart  (5 nav items)
lib/features/learn/presentation/screens/learn_hub_screen.dart  (new stub — real hub in Sprint 3)
```

Vocabulary/Grammar/Listening/Writing remain pushed full-screen routes
(unchanged) — they'll be linked from the Learn hub's cards once that's
built.

## Home feature (full Clean Architecture)

```
lib/features/home/
  domain/entities/home_summary.dart              (Freezed — needs codegen)
  domain/repositories/home_repository.dart
  domain/usecases/get_home_summary.dart
  data/models/home_summary_model.dart
  data/datasources/home_remote_datasource.dart
  data/repositories/home_repository_impl.dart
  application/providers/home_providers.dart
  presentation/screens/home_screen.dart           (replaces stub)
  presentation/widgets/daily_goal_card.dart
  presentation/widgets/stat_chip.dart
  presentation/widgets/continue_learning_card.dart
  presentation/widgets/quick_action_grid.dart

supabase/migrations/0001_user_home_stats.sql       (NEW — run this)
```

## ⚠️ Required: run the SQL migration

Home screen reads/writes a real `user_home_stats` table — not mock
data. Before testing, run
`supabase/migrations/0001_user_home_stats.sql` in your Supabase
project's SQL Editor (or via the Supabase CLI if you're using
migrations there). It creates the table, an `updated_at` trigger, and
RLS policies scoping every row to `auth.uid()`.

Also re-run codegen (new Freezed class added):
```bash
dart run build_runner build --delete-conflicting-outputs
```

## Design decisions worth flagging

- **First-time users get a lazily-created row**, not an error state —
  `HomeRemoteDataSourceImpl` inserts a default row (`streak_days: 0`,
  `daily_goal_target_minutes: 10`, etc.) the first time a signed-in
  user's Home loads. This is real logic, not a fake placeholder — it's
  the standard "upsert on first read" pattern for per-user settings
  rows.
- **"Continue Learning" only renders when a module is in progress** —
  a brand-new account correctly shows no continue-learning card
  (`continueLearning` is `null`) rather than a fake entry.
- **Continue Learning's tap target goes to `/learn`** (not a specific
  module) since Vocabulary/Grammar/etc. don't have per-lesson deep
  links yet — that arrives with Sprint 3. Flagged in code comments so
  it's easy to find and upgrade later.
- **Quick Actions grid is static UI config**, not fetched data — the
  6 tiles (icons, gradients, routes) are product decisions, not
  per-user state, so hardcoding them in `quick_action_grid.dart` is
  correct, not a shortcut.
- **Gradient icon tiles** (unlike the flat single-color icons
  elsewhere in the app) are a deliberate match to the reference
  image's "Featured Modules" style — used only for these 6 quick-action
  tiles, not spread across the whole design system, to keep it a
  distinctive accent rather than diluting the clean/minimal base look.

## Testing this part

1. Run the SQL migration + `build_runner build`.
2. Sign in (Part 4 auth) → router lands you on `/onboarding` (still a
   stub) → for now, manually navigate to `/home` in dev, or wait for
   Onboarding to be built to flow through naturally.
3. Home should show: greeting with your account's first name, a Daily
   Goal card at 0/10 minutes, Day Streak + XP chips at 0, no Continue
   Learning card yet, and the 6-tile Quick Actions grid — tapping any
   tile pushes to its (currently stub) destination screen.

---

**Next:** confirm this, then I'll continue Sprint 2 with **Profile**
and **Settings** — same pattern (Clean Architecture + real Supabase
table + UI matching the reference image).
